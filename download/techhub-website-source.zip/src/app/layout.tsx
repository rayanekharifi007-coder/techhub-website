import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { ServiceWorkerRegister } from "@/components/sw-register";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "TechHub EMSI Fès — Where Tech Meets Ideas",
  description:
    "TechHub EMSI Fès is a technology club founded by engineering students at EMSI Fès. We build projects, host hackathons, teach engineering, and ship real software.",
  keywords: [
    "TechHub",
    "EMSI",
    "Fès",
    "engineering",
    "technology club",
    "hackathon",
    "Morocco tech",
    "student developers",
    "computer engineering",
  ],
  authors: [{ name: "TechHub EMSI Fès" }],
  manifest: "/manifest.json",
  applicationName: "TechHub EMSI Fès",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "TechHub EMSI Fès",
  },
  formatDetection: {
    telephone: false,
  },
  icons: {
    icon: [
      { url: "/icon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-128.png", sizes: "128x128", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  openGraph: {
    title: "TechHub EMSI Fès — Where Tech Meets Ideas",
    description:
      "A technology laboratory for engineering students. Projects, hackathons, learning, and community.",
    siteName: "TechHub EMSI Fès",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "TechHub EMSI Fès",
    description: "Where Tech Meets Ideas.",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0f1e" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground font-sans`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <Sonner position="top-right" richColors closeButton />
          <ServiceWorkerRegister />
        </ThemeProvider>
      </body>
    </html>
  );
}
