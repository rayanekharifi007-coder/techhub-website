import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get("slug");
  if (slug) {
    const tutorial = await db.tutorial.findUnique({
      where: { slug },
      select: {
        id: true, title: true, slug: true, summary: true, content: true,
        category: true, difficulty: true, minutes: true, createdAt: true,
        author: { select: { name: true } },
      },
    });
    if (!tutorial) return NextResponse.json({ error: "Not found." }, { status: 404 });
    return NextResponse.json({ tutorial });
  }
  const url2 = new URL(req.url);
  const category = url2.searchParams.get("category");
  const difficulty = url2.searchParams.get("difficulty");
  const where: Record<string, unknown> = { published: true };
  if (category && category !== "ALL") where.category = category;
  if (difficulty && difficulty !== "ALL") where.difficulty = difficulty;

  const tutorials = await db.tutorial.findMany({
    where,
    orderBy: { createdAt: "desc" },
    select: {
      id: true, title: true, slug: true, summary: true, category: true,
      difficulty: true, minutes: true, createdAt: true,
      author: { select: { name: true } },
    },
  });
  return NextResponse.json({ tutorials });
}

export async function POST(req: Request) {
  const session = await readServerSession();
  if (!session) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  const body = await req.json().catch(() => null);
  return NextResponse.json({ ok: true, tutorialId: body?.tutorialId ?? null });
}
