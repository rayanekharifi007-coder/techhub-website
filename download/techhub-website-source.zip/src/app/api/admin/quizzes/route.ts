import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function GET() {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const quizzes = await db.quiz.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json({
    quizzes: quizzes.map((q) => ({ ...q, questions: safe(q.questions, []) })),
  });
}

export async function POST(req: Request) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
  if (!Array.isArray(body.questions) || body.questions.length === 0) {
    return NextResponse.json({ error: "A quiz needs at least one question." }, { status: 400 });
  }
  const created = await db.quiz.create({
    data: {
      title: body.title,
      slug: body.slug || slugify(body.title),
      category: body.category || "GENERAL",
      questions: JSON.stringify(body.questions),
    },
  });
  return NextResponse.json({ quiz: created });
}

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
