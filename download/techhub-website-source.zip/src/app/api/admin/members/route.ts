import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";

export async function GET() {
  try {
    await requireAdmin();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const members = await db.user.findMany({
    orderBy: [{ role: "asc" }, { createdAt: "asc" }],
    select: {
      id: true, name: true, email: true, role: true, specialty: true,
      github: true, createdAt: true, bio: true,
    },
    take: 200,
  });
  return NextResponse.json({ members });
}

export async function PUT(req: Request) {
  // Bulk-update a member role via body {id, role}
  try {
    await requireAdmin();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  if (!body?.id) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  const role = ["ADMIN", "LEAD", "MEMBER"].includes(body.role) ? body.role : "MEMBER";
  const updated = await db.user.update({
    where: { id: body.id },
    data: { role },
    select: { id: true, name: true, email: true, role: true },
  });
  return NextResponse.json({ user: updated });
}
