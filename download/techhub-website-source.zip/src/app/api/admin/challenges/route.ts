import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function GET() {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const challenges = await db.codingChallenge.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json({
    challenges: challenges.map((c) => ({
      ...c,
      tests: safe(c.tests, []),
    })),
  });
}

export async function POST(req: Request) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
  const created = await db.codingChallenge.create({
    data: {
      title: body.title,
      slug: body.slug || slugify(body.title),
      description: body.description || "",
      difficulty: body.difficulty || "EASY",
      category: body.category || "ALGORITHMS",
      starterCode: body.starterCode || "",
      solution: body.solution || "",
      tests: JSON.stringify(body.tests || []),
    },
  });
  return NextResponse.json({ challenge: created });
}

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
