import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
  const updated = await db.project.update({
    where: { id },
    data: {
      ...(body.title !== undefined && { title: body.title }),
      ...(body.slug !== undefined && { slug: body.slug }),
      ...(body.summary !== undefined && { summary: body.summary }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.category !== undefined && { category: body.category }),
      ...(body.techStack !== undefined && { techStack: JSON.stringify(body.techStack) }),
      ...(body.githubUrl !== undefined && { githubUrl: body.githubUrl || null }),
      ...(body.demoUrl !== undefined && { demoUrl: body.demoUrl || null }),
      ...(body.status !== undefined && { status: body.status }),
      ...(body.featured !== undefined && { featured: !!body.featured }),
      ...(body.contributors !== undefined && { contributors: JSON.stringify(body.contributors) }),
      ...(body.coverColor !== undefined && { coverColor: body.coverColor || null }),
    },
  });
  return NextResponse.json({ project: updated });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const { id } = await params;
  await db.project.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
