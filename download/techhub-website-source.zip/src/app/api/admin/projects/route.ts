import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function GET() {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const projects = await db.project.findMany({
    orderBy: { createdAt: "desc" },
    include: { author: { select: { name: true } } },
    take: 200,
  });
  return NextResponse.json({
    projects: projects.map((p) => ({
      ...p,
      techStack: safe(p.techStack, []),
      contributors: safe(p.contributors, []),
    })),
  });
}

export async function POST(req: Request) {
  try {
    const session = await requireLeadOrAbove();
    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
    const created = await db.project.create({
      data: {
        title: body.title,
        slug: body.slug || slugify(body.title),
        summary: body.summary || "",
        description: body.description || "",
        category: body.category || "WEB",
        techStack: JSON.stringify(body.techStack || []),
        githubUrl: body.githubUrl || null,
        demoUrl: body.demoUrl || null,
        status: body.status || "IN_PROGRESS",
        featured: !!body.featured,
        authorId: session.userId,
        contributors: JSON.stringify(body.contributors || []),
        coverColor: body.coverColor || null,
      },
    });
    return NextResponse.json({ project: created });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
}

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
