import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function GET() {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const announcements = await db.announcement.findMany({
    orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
    include: { author: { select: { name: true } } },
    take: 200,
  });
  return NextResponse.json({ announcements });
}

export async function POST(req: Request) {
  try {
    const session = await requireLeadOrAbove();
    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
    const created = await db.announcement.create({
      data: {
        title: body.title,
        body: body.body || "",
        category: body.category || "CLUB",
        pinned: !!body.pinned,
        authorId: session.userId,
      },
    });
    return NextResponse.json({ announcement: created });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
}
