import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function PUT(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const { id } = await params;
  const updated = await db.contactMessage.update({
    where: { id },
    data: { handled: true },
  });
  return NextResponse.json({ message: updated });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const { id } = await params;
  await db.contactMessage.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
