import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function GET() {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const tutorials = await db.tutorial.findMany({
    orderBy: { createdAt: "desc" },
    include: { author: { select: { name: true } } },
    take: 200,
  });
  return NextResponse.json({ tutorials });
}

export async function POST(req: Request) {
  try {
    const session = await requireLeadOrAbove();
    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
    const created = await db.tutorial.create({
      data: {
        title: body.title,
        slug: body.slug || slugify(body.title),
        summary: body.summary || "",
        content: body.content || "",
        category: body.category || "FRONTEND",
        difficulty: body.difficulty || "BEGINNER",
        minutes: Number(body.minutes) || 10,
        authorId: session.userId,
        published: body.published !== false,
      },
    });
    return NextResponse.json({ tutorial: created });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
}

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
