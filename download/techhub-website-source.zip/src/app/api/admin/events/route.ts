import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

export async function GET() {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const events = await db.event.findMany({
    orderBy: { startDate: "desc" },
    include: { _count: { select: { registrations: true } } },
    take: 200,
  });
  return NextResponse.json({
    events: events.map((e) => ({
      ...e,
      schedule: safe(e.schedule, []),
      registered: e._count.registrations,
    })),
  });
}

export async function POST(req: Request) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid body." }, { status: 400 });
  const created = await db.event.create({
    data: {
      title: body.title,
      slug: body.slug || slugify(body.title),
      description: body.description || "",
      type: body.type || "WORKSHOP",
      startDate: new Date(body.startDate),
      endDate: new Date(body.endDate),
      location: body.location || "EMSI Fès",
      capacity: Number(body.capacity) || 30,
      status: body.status || "UPCOMING",
      schedule: JSON.stringify(body.schedule || []),
      coverColor: body.coverColor || null,
    },
  });
  return NextResponse.json({ event: created });
}

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
