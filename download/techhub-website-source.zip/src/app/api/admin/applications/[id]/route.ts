import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireLeadOrAbove } from "@/lib/session";

// Approve / reject an application
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireLeadOrAbove();
    const { id } = await params;
    const body = await req.json().catch(() => ({}));
    const status = body.status === "APPROVED" || body.status === "REJECTED" ? body.status : "PENDING";
    const updated = await db.memberApplication.update({
      where: { id },
      data: {
        status,
        reviewedBy: session.userId,
        note: typeof body.note === "string" ? body.note : null,
      },
    });
    return NextResponse.json({ application: updated });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireLeadOrAbove();
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 401 });
  }
  const { id } = await params;
  await db.memberApplication.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
