import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const search = url.searchParams.get("q")?.toLowerCase() ?? "";
  const category = url.searchParams.get("category");
  const status = url.searchParams.get("status");
  const featured = url.searchParams.get("featured");

  const where: Record<string, unknown> = {};
  if (category && category !== "ALL") where.category = category;
  if (status && status !== "ALL") where.status = status;
  if (featured === "true") where.featured = true;
  if (search) {
    where.OR = [
      { title: { contains: search } },
      { summary: { contains: search } },
      { description: { contains: search } },
    ];
  }

  const projects = await db.project.findMany({
    where,
    orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
    take: 100,
  });

  return NextResponse.json({
    projects: projects.map((p) => ({
      ...p,
      techStack: safe(p.techStack, []),
      contributors: safe(p.contributors, []),
    })),
  });
}

function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
