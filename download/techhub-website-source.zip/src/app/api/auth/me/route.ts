import { NextResponse } from "next/server";
import { readServerSession } from "@/lib/session";

export async function GET() {
  const session = await readServerSession();
  return NextResponse.json({ user: session });
}
