import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// Public members listing — only public profile fields
export async function GET() {
  const users = await db.user.findMany({
    where: { role: { in: ["ADMIN", "LEAD", "MEMBER"] } },
    orderBy: [{ role: "asc" }, { createdAt: "asc" }],
    select: {
      id: true,
      name: true,
      role: true,
      bio: true,
      github: true,
      linkedin: true,
      specialty: true,
      avatarUrl: true,
      skills: true,
      createdAt: true,
    },
    take: 60,
  });

  // Attach contribution counts
  const ids = users.map((u) => u.id);
  const [projectCounts, regCounts] = await Promise.all([
    db.project.groupBy({ by: ["authorId"], where: { authorId: { in: ids } }, _count: true }),
    db.eventRegistration.groupBy({ by: ["userId"], where: { userId: { in: ids } }, _count: true }),
  ]);
  const pMap = Object.fromEntries(projectCounts.map((p) => [p.authorId, p._count]));
  const rMap = Object.fromEntries(regCounts.map((r) => [r.userId, r._count]));

  return NextResponse.json({
    members: users.map((u) => ({
      ...u,
      skills: safe(u.skills, []),
      projects: pMap[u.id] ?? 0,
      eventsAttended: rMap[u.id] ?? 0,
    })),
  });
}

function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
