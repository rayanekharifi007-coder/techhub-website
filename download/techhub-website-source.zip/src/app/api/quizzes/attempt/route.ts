import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get("slug");
  if (!slug) return NextResponse.json({ error: "Missing slug." }, { status: 400 });
  const quiz = await db.quiz.findUnique({
    where: { slug },
    select: {
      id: true, title: true, slug: true, category: true,
      questions: true,
    },
  });
  if (!quiz) return NextResponse.json({ error: "Quiz not found." }, { status: 404 });
  const questions = safe(quiz.questions, []).map((q: { id: string; prompt: string; options: string[]; answer: number }) => ({
    id: q.id,
    prompt: q.prompt,
    options: q.options,
  }));
  return NextResponse.json({ quiz: { ...quiz, questions } });
}

export async function POST(req: Request) {
  const session = await readServerSession();
  if (!session) return NextResponse.json({ error: "Sign in to submit a quiz." }, { status: 401 });
  const body = await req.json().catch(() => null);
  const { slug, answers } = body || {};
  if (!slug || !Array.isArray(answers)) {
    return NextResponse.json({ error: "Invalid submission." }, { status: 400 });
  }
  const quiz = await db.quiz.findUnique({
    where: { slug },
    select: { id: true, questions: true },
  });
  if (!quiz) return NextResponse.json({ error: "Quiz not found." }, { status: 404 });
  const questions = safe(quiz.questions, []);
  let score = 0;
  const graded = questions.map((q: { id: string; answer: number }, i: number) => {
    const userAnswer = answers[i];
    const correct = userAnswer === q.answer;
    if (correct) score++;
    return { id: q.id, correct, userAnswer, correctAnswer: q.answer };
  });
  const total = questions.length;
  await db.quizAttempt.create({
    data: { quizId: quiz.id, userId: session.userId, score, total },
  });
  return NextResponse.json({ score, total, graded });
}

function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
