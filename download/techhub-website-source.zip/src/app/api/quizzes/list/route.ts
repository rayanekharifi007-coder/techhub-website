import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

export async function GET() {
  const quizzes = await db.quiz.findMany({
    orderBy: { createdAt: "asc" },
    select: {
      id: true, title: true, slug: true, category: true, createdAt: true,
    },
  });
  return NextResponse.json({ quizzes });
}
