import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { sendEmail, CLUB_EMAIL } from "@/lib/email";

const schema = z.object({
  fullName: z.string().min(2).max(80),
  email: z.string().email(),
  phone: z.string().max(40).optional().or(z.literal("")),
  specialty: z.string().min(2).max(80),
  year: z.string().min(1).max(40),
  motivation: z.string().min(40).max(2000),
  skills: z.array(z.string()).default([]),
  experience: z.string().max(2000).optional().or(z.literal("")),
  portfolio: z.string().url().optional().or(z.literal("")),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid input.", issues: parsed.error.flatten() },
      { status: 400 }
    );
  }
  const data = parsed.data;

  // 1. Store in database
  const application = await db.memberApplication.create({
    data: {
      fullName: data.fullName,
      email: data.email.toLowerCase(),
      phone: data.phone || null,
      specialty: data.specialty,
      year: data.year,
      motivation: data.motivation,
      skills: JSON.stringify(data.skills),
      experience: data.experience || null,
      portfolio: data.portfolio || null,
      status: "PENDING",
    },
  });

  // 2. Send email to the club
  const skillsList = data.skills.length > 0 ? data.skills.join(", ") : "None listed";
  const emailResult = await sendEmail({
    to: CLUB_EMAIL,
    subject: `[TechHub Application] ${data.fullName} — ${data.specialty}`,
    text: `New membership application:\n\nName: ${data.fullName}\nEmail: ${data.email}\nPhone: ${data.phone || "N/A"}\nSpecialty: ${data.specialty}\nYear: ${data.year}\nSkills: ${skillsList}\nPortfolio: ${data.portfolio || "N/A"}\n\nMotivation:\n${data.motivation}\n\nExperience:\n${data.experience || "N/A"}\n\n---\nApplication ID: ${application.id}\nSubmitted at: ${new Date().toISOString()}`,
    html: `
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1f3a8a; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
          <h2 style="margin: 0;">New Membership Application</h2>
          <p style="margin: 5px 0 0; opacity: 0.8;">TechHub EMSI Fès — Fall Cohort</p>
        </div>
        <div style="background: #f8fafc; padding: 20px; border: 1px solid #e2e8f0; border-radius: 0 0 8px 8px;">
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 6px 0; font-weight: bold; width: 100px;">Name:</td><td style="padding: 6px 0;">${data.fullName}</td></tr>
            <tr><td style="padding: 6px 0; font-weight: bold;">Email:</td><td style="padding: 6px 0;"><a href="mailto:${data.email}" style="color: #1f3a8a;">${data.email}</a></td></tr>
            <tr><td style="padding: 6px 0; font-weight: bold;">Phone:</td><td style="padding: 6px 0;">${data.phone || "N/A"}</td></tr>
            <tr><td style="padding: 6px 0; font-weight: bold;">Specialty:</td><td style="padding: 6px 0;">${data.specialty}</td></tr>
            <tr><td style="padding: 6px 0; font-weight: bold;">Year:</td><td style="padding: 6px 0;">${data.year}</td></tr>
            <tr><td style="padding: 6px 0; font-weight: bold;">Skills:</td><td style="padding: 6px 0;">${skillsList}</td></tr>
            <tr><td style="padding: 6px 0; font-weight: bold;">Portfolio:</td><td style="padding: 6px 0;">${data.portfolio ? `<a href="${data.portfolio}" style="color: #1f3a8a;">${data.portfolio}</a>` : "N/A"}</td></tr>
          </table>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;">
          <p style="margin: 0 0 8px; font-weight: bold;">Motivation:</p>
          <div style="background: white; padding: 16px; border-radius: 6px; border: 1px solid #e2e8f0; white-space: pre-wrap;">${data.motivation}</div>
          ${data.experience ? `<p style="margin: 16px 0 8px; font-weight: bold;">Experience:</p><div style="background: white; padding: 16px; border-radius: 6px; border: 1px solid #e2e8f0; white-space: pre-wrap;">${data.experience}</div>` : ""}
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;">
          <p style="margin: 0; font-size: 12px; color: #64748b;">Application ID: ${application.id}</p>
          <p style="margin: 4px 0 0; font-size: 12px; color: #64748b;">Submitted at: ${new Date().toISOString()}</p>
        </div>
      </div>
    `,
    replyTo: data.email,
  });

  return NextResponse.json({
    application,
    emailSent: emailResult.success,
    previewUrl: emailResult.previewUrl,
  });
}

export async function GET() {
  const applications = await db.memberApplication.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return NextResponse.json({ applications });
}
