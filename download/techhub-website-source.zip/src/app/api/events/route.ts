import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const status = url.searchParams.get("status");

  const where: Record<string, unknown> = {};
  if (type && type !== "ALL") where.type = type;
  if (status && status !== "ALL") where.status = status;

  const events = await db.event.findMany({
    where,
    orderBy: { startDate: "asc" },
    include: { _count: { select: { registrations: true } } },
  });

  return NextResponse.json({
    events: events.map((e) => ({
      ...e,
      schedule: safe(e.schedule, []),
      registered: e._count.registrations,
    })),
  });
}

function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
