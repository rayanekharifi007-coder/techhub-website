import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

// Register the current user for an event
export async function POST(req: Request) {
  const session = await readServerSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in to register." }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  const eventId = body?.eventId;
  if (!eventId) return NextResponse.json({ error: "Missing eventId." }, { status: 400 });

  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { _count: { select: { registrations: true } } },
  });
  if (!event) return NextResponse.json({ error: "Event not found." }, { status: 404 });
  if (event.status === "CANCELLED") {
    return NextResponse.json({ error: "Event has been cancelled." }, { status: 400 });
  }
  if (event.status === "COMPLETED") {
    return NextResponse.json({ error: "Event has already completed." }, { status: 400 });
  }

  const existing = await db.eventRegistration.findUnique({
    where: { eventId_userId: { eventId, userId: session.userId } },
  });
  if (existing && existing.status === "CONFIRMED") {
    return NextResponse.json({ error: "You are already registered." }, { status: 409 });
  }

  const confirmedCount = await db.eventRegistration.count({
    where: { eventId, status: "CONFIRMED" },
  });
  const status = confirmedCount >= event.capacity ? "WAITLIST" : "CONFIRMED";

  const reg = await db.eventRegistration.upsert({
    where: { eventId_userId: { eventId, userId: session.userId } },
    update: { status },
    create: { eventId, userId: session.userId, status },
  });

  return NextResponse.json({ registration: reg });
}

// Cancel registration
export async function DELETE(req: Request) {
  const session = await readServerSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in to cancel." }, { status: 401 });
  }
  const url = new URL(req.url);
  const eventId = url.searchParams.get("eventId");
  if (!eventId) return NextResponse.json({ error: "Missing eventId." }, { status: 400 });

  await db.eventRegistration.deleteMany({
    where: { eventId, userId: session.userId },
  });
  return NextResponse.json({ ok: true });
}
