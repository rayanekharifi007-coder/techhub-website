import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const announcements = await db.announcement.findMany({
    orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
    take: 30,
    select: {
      id: true, title: true, body: true, category: true, pinned: true, createdAt: true,
      author: { select: { name: true } },
    },
  });
  return NextResponse.json({ announcements });
}
