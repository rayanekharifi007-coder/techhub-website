import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

export async function GET() {
  const session = await readServerSession();
  if (!session) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });

  const [user, projects, registrations, challengeProgress, quizAttempts] = await Promise.all([
    db.user.findUnique({
      where: { id: session.userId },
      select: {
        id: true, name: true, email: true, role: true, bio: true, github: true,
        linkedin: true, specialty: true, skills: true, avatarUrl: true,
        graduationYear: true, createdAt: true,
      },
    }),
    db.project.findMany({
      where: { authorId: session.userId },
      orderBy: { createdAt: "desc" },
      take: 30,
      select: {
        id: true, title: true, slug: true, category: true, status: true,
        featured: true, githubUrl: true, demoUrl: true, createdAt: true,
      },
    }),
    db.eventRegistration.findMany({
      where: { userId: session.userId },
      include: { event: { select: { id: true, title: true, slug: true, startDate: true, endDate: true, location: true, type: true, status: true } } },
      orderBy: { event: { startDate: "asc" } },
      take: 30,
    }),
    db.challengeProgress.findMany({
      where: { userId: session.userId },
      include: { challenge: { select: { id: true, title: true, slug: true, difficulty: true, category: true } } },
    }),
    db.quizAttempt.findMany({
      where: { userId: session.userId },
      include: { quiz: { select: { id: true, title: true, slug: true, category: true } } },
      orderBy: { createdAt: "desc" },
      take: 30,
    }),
  ]);

  if (!user) return NextResponse.json({ error: "Not found." }, { status: 404 });

  return NextResponse.json({
    user: { ...user, skills: safe(user.skills, []) },
    projects: projects.map((p) => ({ ...p })),
    registrations: registrations.map((r) => ({ id: r.id, status: r.status, createdAt: r.createdAt, event: r.event })),
    challengeProgress: challengeProgress.map((p) => ({ id: p.id, status: p.status, attempts: p.attempts, challenge: p.challenge })),
    quizAttempts: quizAttempts.map((a) => ({ id: a.id, score: a.score, total: a.total, createdAt: a.createdAt, quiz: a.quiz })),
    stats: {
      projects: projects.length,
      eventsRegistered: registrations.length,
      challengesSolved: challengeProgress.filter((p) => p.status === "SOLVED").length,
      quizzesTaken: quizAttempts.length,
      avgQuizScore: quizAttempts.length
        ? Math.round(
            (quizAttempts.reduce((acc, a) => acc + (a.total ? a.score / a.total : 0), 0) / quizAttempts.length) * 100
          )
        : 0,
    },
  });
}

function safe<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
