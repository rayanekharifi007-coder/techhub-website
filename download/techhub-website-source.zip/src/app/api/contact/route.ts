import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { sendEmail, CLUB_EMAIL } from "@/lib/email";

const schema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
  subject: z.string().min(2).max(120),
  body: z.string().min(10).max(4000),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input.", issues: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  // 1. Store in database
  const message = await db.contactMessage.create({
    data: {
      name: data.name,
      email: data.email.toLowerCase(),
      subject: data.subject,
      body: data.body,
    },
  });

  // 2. Send email to the club
  const emailResult = await sendEmail({
    to: CLUB_EMAIL,
    subject: `[TechHub Contact] ${data.subject}`,
    text: `New contact form submission:\n\nName: ${data.name}\nEmail: ${data.email}\nSubject: ${data.subject}\n\nMessage:\n${data.body}\n\n---\nSubmitted at: ${new Date().toISOString()}\nMessage ID: ${message.id}`,
    html: `
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1f3a8a; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
          <h2 style="margin: 0;">New Contact Form Submission</h2>
          <p style="margin: 5px 0 0; opacity: 0.8;">TechHub EMSI Fès</p>
        </div>
        <div style="background: #f8fafc; padding: 20px; border: 1px solid #e2e8f0; border-radius: 0 0 8px 8px;">
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px 0; font-weight: bold; width: 100px;">Name:</td><td style="padding: 8px 0;">${data.name}</td></tr>
            <tr><td style="padding: 8px 0; font-weight: bold;">Email:</td><td style="padding: 8px 0;"><a href="mailto:${data.email}" style="color: #1f3a8a;">${data.email}</a></td></tr>
            <tr><td style="padding: 8px 0; font-weight: bold;">Subject:</td><td style="padding: 8px 0;">${data.subject}</td></tr>
          </table>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;">
          <p style="margin: 0 0 8px; font-weight: bold;">Message:</p>
          <div style="background: white; padding: 16px; border-radius: 6px; border: 1px solid #e2e8f0; white-space: pre-wrap;">${data.body}</div>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;">
          <p style="margin: 0; font-size: 12px; color: #64748b;">Submitted at: ${new Date().toISOString()}</p>
          <p style="margin: 4px 0 0; font-size: 12px; color: #64748b;">Message ID: ${message.id}</p>
        </div>
      </div>
    `,
    replyTo: data.email,
  });

  return NextResponse.json({
    ok: true,
    emailSent: emailResult.success,
    previewUrl: emailResult.previewUrl,
  });
}

export async function GET() {
  const messages = await db.contactMessage.findMany({
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  return NextResponse.json({ messages });
}
