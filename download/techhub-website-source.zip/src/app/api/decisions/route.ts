import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

// GET — list all proposals (public, but vote count is included)
export async function GET() {
  const session = await readServerSession();
  const proposals = await db.proposal.findMany({
    orderBy: [{ status: "asc" }, { deadline: "asc" }, { createdAt: "desc" }],
    include: {
      author: { select: { name: true, specialty: true } },
      _count: { select: { votes: true } },
    },
    take: 100,
  });

  // If the user is signed in, mark which proposals they've voted on
  let votedIds: Set<string> = new Set();
  if (session) {
    const votes = await db.vote.findMany({
      where: { userId: session.userId },
      select: { proposalId: true },
    });
    votedIds = new Set(votes.map((v) => v.proposalId));
  }

  // Auto-close proposals past their deadline
  const now = new Date();
  const toClose = proposals.filter((p) => p.status === "ACTIVE" && p.deadline < now);
  if (toClose.length > 0) {
    await db.proposal.updateMany({
      where: { id: { in: toClose.map((p) => p.id) } },
      data: { status: "CLOSED" },
    });
  }

  return NextResponse.json({
    proposals: proposals.map((p) => ({
      ...p,
      voteCount: p._count.votes,
      hasVoted: votedIds.has(p.id),
      isClosed: p.status === "CLOSED" || p.deadline < now,
    })),
  });
}

// POST — create a new proposal (requires auth)
const schema = z.object({
  title: z.string().min(3).max(120),
  description: z.string().min(10).max(2000),
  category: z.enum(["WORKSHOP", "TALK", "PROJECT", "EVENT"]),
  deadline: z.string(), // ISO date string
});

export async function POST(req: Request) {
  const session = await readServerSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in to propose an idea." }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input.", issues: parsed.error.flatten() }, { status: 400 });
  }
  const { title, description, category, deadline } = parsed.data;
  const deadlineDate = new Date(deadline);
  if (deadlineDate <= new Date()) {
    return NextResponse.json({ error: "Deadline must be in the future." }, { status: 400 });
  }

  const proposal = await db.proposal.create({
    data: {
      title,
      description,
      category,
      authorId: session.userId,
      deadline: deadlineDate,
      status: "ACTIVE",
    },
  });
  return NextResponse.json({ proposal });
}
