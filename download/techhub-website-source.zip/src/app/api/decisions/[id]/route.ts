import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

// DELETE — delete a proposal (only the author or admin/lead)
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await readServerSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in to delete a proposal." }, { status: 401 });
  }
  const { id } = await params;
  const proposal = await db.proposal.findUnique({ where: { id } });
  if (!proposal) {
    return NextResponse.json({ error: "Proposal not found." }, { status: 404 });
  }
  if (proposal.authorId !== session.userId && session.role !== "ADMIN" && session.role !== "LEAD") {
    return NextResponse.json({ error: "You can only delete your own proposals." }, { status: 403 });
  }
  await db.proposal.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}

// PUT — mark a proposal as winner (admin/lead only)
export async function PUT(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await readServerSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in." }, { status: 401 });
  }
  if (session.role !== "ADMIN" && session.role !== "LEAD") {
    return NextResponse.json({ error: "Only leads and admins can select winners." }, { status: 403 });
  }
  const { id } = await params;
  const proposal = await db.proposal.findUnique({ where: { id } });
  if (!proposal) {
    return NextResponse.json({ error: "Proposal not found." }, { status: 404 });
  }
  // Toggle winner status and close the proposal
  const updated = await db.proposal.update({
    where: { id },
    data: {
      winner: !proposal.winner,
      status: "CLOSED",
    },
  });
  return NextResponse.json({ proposal: updated });
}
