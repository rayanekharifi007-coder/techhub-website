import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

// Vote on a proposal (toggle — vote if not voted, unvote if already voted)
export async function POST(req: Request) {
  const session = await readServerSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in to vote." }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  const proposalId = body?.proposalId;
  if (!proposalId) {
    return NextResponse.json({ error: "Missing proposalId." }, { status: 400 });
  }

  const proposal = await db.proposal.findUnique({ where: { id: proposalId } });
  if (!proposal) {
    return NextResponse.json({ error: "Proposal not found." }, { status: 404 });
  }
  if (proposal.status === "CLOSED" || proposal.deadline < new Date()) {
    return NextResponse.json({ error: "Voting is closed for this proposal." }, { status: 400 });
  }

  const existing = await db.vote.findUnique({
    where: { proposalId_userId: { proposalId, userId: session.userId } },
  });

  if (existing) {
    // Unvote
    await db.vote.delete({ where: { id: existing.id } });
    const count = await db.vote.count({ where: { proposalId } });
    return NextResponse.json({ voted: false, voteCount: count });
  } else {
    // Vote
    await db.vote.create({ data: { proposalId, userId: session.userId } });
    const count = await db.vote.count({ where: { proposalId } });
    return NextResponse.json({ voted: true, voteCount: count });
  }
}
