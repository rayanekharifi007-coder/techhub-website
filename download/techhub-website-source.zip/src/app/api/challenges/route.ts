import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readServerSession } from "@/lib/session";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get("slug");
  const session = await readServerSession();

  if (slug) {
    const challenge = await db.codingChallenge.findUnique({
      where: { slug },
      select: {
        id: true, title: true, slug: true, description: true, difficulty: true,
        category: true, starterCode: true, tests: true,
      },
    });
    if (!challenge) return NextResponse.json({ error: "Not found." }, { status: 404 });
    let progress: { status: string; attempts: number } | null = null;
    if (session) {
      progress = await db.challengeProgress.findUnique({
        where: { challengeId_userId: { challengeId: challenge.id, userId: session.userId } },
        select: { status: true, attempts: true },
      });
    }
    return NextResponse.json({
      challenge: {
        ...challenge,
        tests: safeParse(challenge.tests, []),
      },
      progress: progress ?? { status: "NOT_STARTED", attempts: 0 },
    });
  }

  const challenges = await db.codingChallenge.findMany({
    orderBy: [{ difficulty: "asc" }, { createdAt: "asc" }],
    select: {
      id: true, title: true, slug: true, description: true,
      difficulty: true, category: true, createdAt: true,
    },
  });
  // Attach per-user progress
  let progressMap: Record<string, { status: string; attempts: number }> = {};
  if (session) {
    const rows = await db.challengeProgress.findMany({
      where: { userId: session.userId },
      select: { challengeId: true, status: true, attempts: true },
    });
    progressMap = Object.fromEntries(rows.map((r) => [r.challengeId, { status: r.status, attempts: r.attempts }]));
  }
  return NextResponse.json({
    challenges: challenges.map((c) => ({
      ...c,
      progress: progressMap[c.id] ?? { status: "NOT_STARTED", attempts: 0 },
    })),
  });
}

// Submit a solution — run the tests server-side
export async function POST(req: Request) {
  const session = await readServerSession();
  if (!session) return NextResponse.json({ error: "Sign in to submit." }, { status: 401 });
  const body = await req.json().catch(() => null);
  const { slug, code } = body || {};
  if (!slug || typeof code !== "string") {
    return NextResponse.json({ error: "Invalid submission." }, { status: 400 });
  }
  const challenge = await db.codingChallenge.findUnique({
    where: { slug },
    select: { id: true, tests: true, solution: true },
  });
  if (!challenge) return NextResponse.json({ error: "Challenge not found." }, { status: 404 });

  const tests = safeParse(challenge.tests, []);

  // Increment attempts
  await db.challengeProgress.upsert({
    where: { challengeId_userId: { challengeId: challenge.id, userId: session.userId } },
    update: { attempts: { increment: 1 } },
    create: { challengeId: challenge.id, userId: session.userId, attempts: 1 },
  });

  // Run the user code against each test
  const results = tests.map((t: { input: unknown[]; expected: unknown }) => {
    try {
      const fn = new Function(`${code}\n; return typeof ${extractFnName(code)} === 'function' ? ${extractFnName(code)} : (${code})`)();
      const got = fn(...t.input);
      const pass = JSON.stringify(got) === JSON.stringify(t.expected);
      return { pass, got: stringifySafe(got), expected: stringifySafe(t.expected) };
    } catch (e) {
      return { pass: false, got: "Runtime error: " + (e as Error).message, expected: stringifySafe(t.expected) };
    }
  });

  const allPass = results.every((r: { pass: boolean }) => r.pass);
  if (allPass) {
    await db.challengeProgress.update({
      where: { challengeId_userId: { challengeId: challenge.id, userId: session.userId } },
      data: { status: "SOLVED" },
    });
  }

  return NextResponse.json({ allPass, results });
};

function extractFnName(code: string): string {
  const m = code.match(/function\s+([A-Za-z_$][\w$]*)/);
  return m ? m[1] : "solution";
}

function stringifySafe(v: unknown): string {
  try { return JSON.stringify(v); } catch { return String(v); }
}

function safeParse<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
