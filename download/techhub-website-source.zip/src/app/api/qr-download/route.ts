import { NextResponse } from "next/server";

/**
 * QR code download proxy — fetches the QR image server-side and returns it
 * as a blob with CORS-friendly headers, so the browser can download it.
 * This avoids the "Failed to fetch" CORS error when downloading from
 * api.qrserver.com directly.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const imageUrl = url.searchParams.get("url");

  if (!imageUrl) {
    return NextResponse.json({ error: "Missing url parameter." }, { status: 400 });
  }

  // Only allow QR server URLs for security
  if (!imageUrl.startsWith("https://api.qrserver.com/")) {
    return NextResponse.json({ error: "URL not allowed." }, { status: 403 });
  }

  try {
    const res = await fetch(imageUrl);
    if (!res.ok) {
      return NextResponse.json({ error: "Failed to fetch QR image." }, { status: 502 });
    }

    const blob = await res.blob();
    return new NextResponse(blob, {
      headers: {
        "Content-Type": "image/png",
        "Content-Disposition": 'attachment; filename="qr-code.png"',
        "Cache-Control": "no-cache",
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Download failed: " + (error as Error).message },
      { status: 500 }
    );
  }
}
