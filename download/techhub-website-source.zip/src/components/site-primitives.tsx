"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

/** Engineering section header — label, title, optional description. */
export function SectionHeader({
  label,
  title,
  description,
  align = "left",
  className,
}: {
  label?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "max-w-3xl space-y-3",
        align === "center" && "mx-auto text-center",
        className
      )}
    >
      {label && <p className="label-mono">{label}</p>}
      <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-foreground leading-[1.1]">
        {title}
      </h2>
      {description && (
        <p className="text-base text-muted-foreground leading-relaxed">
          {description}
        </p>
      )}
    </div>
  );
}

/** Technical pill — monospace, restrained. */
export function TechPill({
  children,
  className,
  tone = "default",
}: {
  children: React.ReactNode;
  className?: string;
  tone?: "default" | "engineering";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center font-mono text-[10.5px] tracking-wider uppercase px-2 py-0.5 rounded-sm border",
        tone === "default"
          ? "border-border bg-secondary/60 text-muted-foreground"
          : "border-engineering/30 bg-engineering/5 text-engineering",
        className
      )}
    >
      {children}
    </span>
  );
}

/** A subtle "blueprint" SVG corner ticks frame. */
export function BlueprintFrame({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("relative", className)}>
      <span className="pointer-events-none absolute top-0 left-0 h-2 w-2 border-t border-l border-engineering/60" />
      <span className="pointer-events-none absolute top-0 right-0 h-2 w-2 border-t border-r border-engineering/60" />
      <span className="pointer-events-none absolute bottom-0 left-0 h-2 w-2 border-b border-l border-engineering/60" />
      <span className="pointer-events-none absolute bottom-0 right-0 h-2 w-2 border-b border-r border-engineering/60" />
      {children}
    </div>
  );
}

/** Reveal-on-scroll wrapper using IntersectionObserver. */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            window.setTimeout(() => setShown(true), delay);
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [delay]);
  return (
    <div
      ref={ref}
      className={cn("reveal", shown && "in", className)}
    >
      {children}
    </div>
  );
}

/** Empty state with technical styling. */
export function EmptyState({
  title,
  description,
  icon,
  action,
}: {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div className="border border-dashed border-border rounded-md p-10 text-center bg-secondary/30">
      {icon && <div className="mx-auto mb-3 text-muted-foreground">{icon}</div>}
      <p className="text-sm font-medium text-foreground">{title}</p>
      {description && (
        <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">{description}</p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/** Loading skeleton with engineering-grid pattern. */
export function LoadingState({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3" aria-busy="true" aria-live="polite">
      {Array.from({ length: rows }).map((_, i) => (
        <div
          key={i}
          className="h-12 rounded-md border border-border bg-secondary/40 animate-pulse"
        />
      ))}
    </div>
  );
}
