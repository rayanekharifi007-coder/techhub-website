"use client";

import { CombinedLogo } from "@/components/logo";
import { navigate, type Route } from "@/lib/router";
import { Mail, MapPin } from "lucide-react";
import { DiscordIcon } from "@/components/discord-icon";
import { useI18n } from "@/components/i18n-provider";

const FOOTER_SECTIONS: { titleKey: string; links: { labelKey: string; route: Route }[] }[] = [
  {
    titleKey: "footer.explore",
    links: [
      { labelKey: "nav.playground", route: "playground" },
      { labelKey: "nav.facts", route: "facts" },
      { labelKey: "nav.learning", route: "learning" },
      { labelKey: "nav.decisions", route: "decisions" },
      { labelKey: "nav.about", route: "about" },
    ],
  },
  {
    titleKey: "footer.club",
    links: [
      { labelKey: "nav.join", route: "join" },
      { labelKey: "nav.contact", route: "contact" },
    ],
  },
  {
    titleKey: "footer.account",
    links: [
      { labelKey: "nav.memberDashboard", route: "dashboard" },
      { labelKey: "nav.adminConsole", route: "admin" },
      { labelKey: "nav.signIn", route: "login" },
    ],
  },
];

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="mt-auto border-t border-border bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid gap-10 md:grid-cols-12">
          <div className="md:col-span-5 space-y-4">
            <CombinedLogo />
            <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
              {t("footer.tagline")}
            </p>
            <div className="flex items-center gap-3 text-xs text-muted-foreground font-mono">
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5" />
                EMSI Fès, Morocco
              </span>
              <a href="mailto:emsi.techhub@gmail.com" className="inline-flex items-center gap-1.5 hover:text-foreground transition-colors">
                <Mail className="h-3.5 w-3.5" />
                emsi.techhub@gmail.com
              </a>
            </div>
          </div>
          <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-8">
            {FOOTER_SECTIONS.map((s) => (
              <div key={s.titleKey} className="space-y-3">
                <p className="label-mono">{t(s.titleKey)}</p>
                <ul className="space-y-2">
                  {s.links.map((l) => (
                    <li key={l.labelKey}>
                      <button
                        onClick={() => navigate(l.route)}
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {t(l.labelKey)}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground font-mono">
            {t("footer.copyright")}
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <a
              href="https://discord.gg/xyVtPuuk"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 hover:text-foreground transition-colors"
            >
              <DiscordIcon className="h-3.5 w-3.5" />
              discord.gg/xyVtPuuk
            </a>
            <span className="font-mono">v1.0</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
