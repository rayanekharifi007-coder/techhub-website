"use client";

import * as React from "react";
import { X, Activity, GitBranch, Trophy, Mail, UserPlus, Vote, Lightbulb } from "lucide-react";

const ACTIVITIES = [
  { icon: GitBranch, text: "New project 'Atlas Routing Engine' shipped", time: "2m ago", color: "#2D9CDB" },
  { icon: Trophy, text: "Yasmine solved the Two-Sum challenge", time: "5m ago", color: "#10b981" },
  { icon: Mail, text: "Contact message from a prospective member", time: "12m ago", color: "#f59e0b" },
  { icon: UserPlus, text: "New membership application received", time: "18m ago", color: "#8b5cf6" },
  { icon: Vote, text: "Voting opened: 'Rust async runtime workshop'", time: "25m ago", color: "#ec4899" },
  { icon: Lightbulb, text: "New fact added: 'USB-C can carry 240W'", time: "1h ago", color: "#06b6d4" },
  { icon: GitBranch, text: "Zellige UI component library updated", time: "2h ago", color: "#2D9CDB" },
  { icon: Trophy, text: "Quiz completed: Web Fundamentals — 5/5", time: "3h ago", color: "#10b981" },
];

export function ActivityTicker() {
  const [visible, setVisible] = React.useState(true);
  const [index, setIndex] = React.useState(0);
  const [expanded, setExpanded] = React.useState(false);

  // Rotate through activities
  React.useEffect(() => {
    if (!visible) return;
    const interval = setInterval(() => {
      setIndex((i) => (i + 1) % ACTIVITIES.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [visible]);

  // Show after 5 seconds on the page
  const [showAfterDelay, setShowAfterDelay] = React.useState(false);
  React.useEffect(() => {
    const t = setTimeout(() => setShowAfterDelay(true), 5000);
    return () => clearTimeout(t);
  }, []);

  if (!visible || !showAfterDelay) return null;

  const current = ACTIVITIES[index];

  return (
    <div className="fixed bottom-16 left-1/2 -translate-x-1/2 z-[42] [margin-bottom:env(safe-area-inset-bottom)]">
      <div
        className="flex items-center gap-3 px-4 py-2.5 rounded-full border border-engineering/30 bg-background/90 backdrop-blur-xl shadow-[0_0_30px_-8px_rgba(45,156,219,0.4)] transition-all hover:border-engineering/50 group"
        onMouseEnter={() => setExpanded(true)}
        onMouseLeave={() => setExpanded(false)}
      >
        {/* Live indicator */}
        <span className="relative flex h-2 w-2 shrink-0">
          <span className="absolute inline-flex h-full w-full rounded-full bg-engineering/60 animate-ping" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-engineering" />
        </span>

        {/* Current activity */}
        <div className="flex items-center gap-2 overflow-hidden">
          <current.icon className="h-3.5 w-3.5 shrink-0" style={{ color: current.color }} />
          <span className="text-xs text-foreground/80 whitespace-nowrap transition-all">
            {current.text}
          </span>
          <span className="text-[10px] text-muted-foreground font-mono shrink-0 hidden sm:inline">· {current.time}</span>
        </div>

        {/* Expanded list */}
        {expanded && (
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-80 max-h-64 overflow-y-auto scrollbar-thin rounded-lg border border-border bg-background/95 backdrop-blur-xl shadow-xl">
            <div className="p-3 border-b border-border">
              <p className="label-mono flex items-center gap-1.5">
                <Activity className="h-3 w-3" />
                Live Activity
              </p>
            </div>
            <div className="p-2 space-y-1">
              {ACTIVITIES.map((a, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-2.5 px-2 py-1.5 rounded-md text-xs transition-colors ${
                    i === index ? "bg-secondary" : "hover:bg-secondary/50"
                  }`}
                >
                  <a.icon className="h-3 w-3 shrink-0" style={{ color: a.color }} />
                  <span className="text-foreground/80 flex-1 truncate">{a.text}</span>
                  <span className="text-[10px] text-muted-foreground font-mono shrink-0">{a.time}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Close button */}
        <button
          onClick={() => setVisible(false)}
          className="shrink-0 h-5 w-5 inline-flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
          aria-label="Dismiss activity ticker"
        >
          <X className="h-3 w-3" />
        </button>
      </div>
    </div>
  );
}
