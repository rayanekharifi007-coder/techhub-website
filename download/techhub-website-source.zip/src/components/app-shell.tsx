"use client";

import * as React from "react";
import { useRouterStore } from "@/lib/router";
import { Header } from "@/components/site-header";
import { Footer } from "@/components/site-footer";
import { AuthDialog } from "@/components/auth-dialog";
import { AuthProvider } from "@/components/auth-provider";
import { I18nProvider } from "@/components/i18n-provider";
import { Splash } from "@/components/splash";
import { CommandPalette } from "@/components/command-palette";
import { BackToTop } from "@/components/back-to-top";
import { UpdateNotice } from "@/components/update-notice";
import { ReadingProgress } from "@/components/reading-progress";
import { ShareButton } from "@/components/share-button";
import { KeyboardShortcuts } from "@/components/keyboard-shortcuts";
import { CursorGlow } from "@/components/cursor-glow";
import { CursorTrail } from "@/components/cursor-trail";
import { KonamiEasterEgg } from "@/components/konami-easter-egg";
import { ActivityTicker } from "@/components/activity-ticker";
import { AchievementSystem } from "@/components/achievements";

import { HomeView } from "@/components/views/home";
import { AboutView } from "@/components/views/about";
import { PlaygroundView } from "@/components/views/playground";
import { FactsView } from "@/components/views/facts";
import { LearningView } from "@/components/views/learning";
import { DecisionsView } from "@/components/views/decisions";
import { JoinView } from "@/components/views/join";
import { ContactView } from "@/components/views/contact";
import { DashboardView } from "@/components/views/dashboard";
import { AdminView } from "@/components/views/admin";

export function AppShell() {
  const { route } = useRouterStore();
  const [booted, setBooted] = React.useState(false);

  // Scroll-to-top on route change + track achievement
  React.useEffect(() => {
    if (booted && typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      // Track page visit for achievements
      window.dispatchEvent(new CustomEvent("techhub-achievement", {
        detail: { pagesVisited: new Set([route]) },
      }));
    }
  }, [route, booted]);

  return (
    <AuthProvider>
      <I18nProvider>
        <div className="min-h-screen flex flex-col bg-background">
          <Splash onDone={() => setBooted(true)} />
          {booted && (
            <>
              <UpdateNotice />
              <Header />
              <main className="flex-1 animate-[fadeInUp_0.4s_ease-out]" key={route}>
                {route === "home" && <HomeView />}
                {route === "about" && <AboutView />}
                {route === "playground" && <PlaygroundView />}
                {route === "facts" && <FactsView />}
                {route === "learning" && <LearningView />}
                {route === "decisions" && <DecisionsView />}
                {route === "join" && <JoinView />}
                {route === "contact" && <ContactView />}
                {route === "dashboard" && <DashboardView />}
                {route === "admin" && <AdminView />}
                {route === "login" && <HomeView />}
              </main>
              <Footer />
              <AuthDialog />
              <CommandPalette />
              <BackToTop />
              <ReadingProgress />
              <ShareButton />
              <KeyboardShortcuts />
              <CursorGlow />
              <CursorTrail />
              <KonamiEasterEgg />
              <ActivityTicker />
              <AchievementSystem />
            </>
          )}
        </div>
      </I18nProvider>
    </AuthProvider>
  );
}
