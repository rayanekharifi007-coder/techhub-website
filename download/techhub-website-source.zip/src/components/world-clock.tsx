"use client";

import * as React from "react";

const CLOCKS = [
  { city: "Fès", tz: "Africa/Casablanca", offset: 0 },
  { city: "London", tz: "Europe/London", offset: 0 },
  { city: "New York", tz: "America/New_York", offset: 0 },
  { city: "Tokyo", tz: "Asia/Tokyo", offset: 0 },
];

/**
 * Live world clock — shows current time in multiple timezones.
 * Updates every second. Used in the splash screen.
 */
export function WorldClock({ className }: { className?: string }) {
  const [times, setTimes] = React.useState<string[]>([]);

  React.useEffect(() => {
    const update = () => {
      const now = new Date();
      const newTimes = CLOCKS.map((c) => {
        try {
          return now.toLocaleTimeString("en-US", {
            timeZone: c.tz,
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: false,
          });
        } catch {
          return "--:--:--";
        }
      });
      setTimes(newTimes);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={className}>
      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 font-mono text-[9px] sm:text-[10px] text-white/40">
        {CLOCKS.map((c, i) => (
          <div key={c.city} className="flex justify-between items-center">
            <span className="uppercase tracking-wider">{c.city}</span>
            <span className="text-white/60 tabular-nums">{times[i] || "--:--:--"}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
