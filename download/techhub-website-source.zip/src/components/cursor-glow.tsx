"use client";

import * as React from "react";

/**
 * Cursor glow — a subtle radial gradient that follows the mouse on desktop.
 * Hidden on touch devices. Adds a premium, modern feel.
 */
export function CursorGlow() {
  const [pos, setPos] = React.useState({ x: -200, y: -200 });
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    // Only on devices with a fine pointer (mouse)
    if (typeof window === "undefined") return;
    if (!window.matchMedia("(pointer: fine)").matches) return;

    const onMove = (e: MouseEvent) => {
      setPos({ x: e.clientX, y: e.clientY });
      setVisible(true);
    };
    const onLeave = () => setVisible(false);

    window.addEventListener("mousemove", onMove);
    document.addEventListener("mouseleave", onLeave);
    return () => {
      window.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  if (!visible) return null;

  return (
    <div
      className="fixed pointer-events-none z-[35] w-[400px] h-[400px] rounded-full opacity-30 transition-opacity duration-300 mix-blend-screen hidden lg:block"
      style={{
        left: pos.x - 200,
        top: pos.y - 200,
        background: "radial-gradient(circle, rgba(45,156,219,0.12), transparent 60%)",
      }}
      aria-hidden="true"
    />
  );
}
