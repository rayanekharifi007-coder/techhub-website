import { cn } from "@/lib/utils";
import Image from "next/image";

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: number;
  variant?: "default" | "light";
}

/**
 * TechHub EMSI Fès logo — official PNG with transparent background.
 * Works on both light and dark backgrounds.
 * Source: 1670×942, aspect ratio ~1.773
 */
export function Logo({ className, size = 30 }: LogoProps) {
  const height = size;
  const width = Math.round(size * (1670 / 942));
  return (
    <div className={cn("flex items-center", className)} style={{ height, width }}>
      <Image
        src="/logo-transparent.png"
        alt="TechHub EMSI Fès"
        width={width}
        height={height}
        priority
        className="h-full w-auto"
        style={{ height, width: "auto" }}
      />
    </div>
  );
}

/**
 * Combined logo: TechHub logo + EMSI logo side by side.
 * Used in the header and splash screen.
 */
export function CombinedLogo({ className, techhubSize = 28, emsiSize = 22 }: { className?: string; techhubSize?: number; emsiSize?: number }) {
  const techhubHeight = techhubSize;
  const techhubWidth = Math.round(techhubSize * (1670 / 942));
  const emsiHeight = emsiSize;
  const emsiWidth = Math.round(emsiSize * (1646 / 360));
  return (
    <div className={cn("flex items-center gap-2 sm:gap-3", className)}>
      <Image
        src="/logo-transparent.png"
        alt="TechHub EMSI Fès"
        width={techhubWidth}
        height={techhubHeight}
        priority
        className="h-auto w-auto"
        style={{ height: techhubHeight, width: "auto" }}
      />
      <div className="h-5 sm:h-6 w-px bg-border shrink-0" />
      <Image
        src="/emsi-logo.png"
        alt="EMSI — École Marocaine des Sciences de l'Ingénieur"
        width={emsiWidth}
        height={emsiHeight}
        priority
        className="h-auto w-auto opacity-80"
        style={{ height: emsiHeight, width: "auto" }}
      />
    </div>
  );
}
