"use client";

import * as React from "react";

const KONAMI = [
  "ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown",
  "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight",
  "b", "a",
];

/**
 * Konami Code Easter Egg — typing ↑↑↓↓←→←→ B A triggers a Matrix-style
 * digital rain overlay for 8 seconds.
 */
export function KonamiEasterEgg() {
  const [active, setActive] = React.useState(false);
  const sequenceRef = React.useRef<string[]>([]);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      sequenceRef.current = [...sequenceRef.current.slice(-9), key];

      if (sequenceRef.current.length >= KONAMI.length) {
        const match = KONAMI.every((k, i) => sequenceRef.current[sequenceRef.current.length - KONAMI.length + i] === k);
        if (match) {
          setActive(true);
          sequenceRef.current = [];
          setTimeout(() => setActive(false), 8000);
        }
      }
    };

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Matrix rain canvas
  React.useEffect(() => {
    if (!active || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const chars = "01<>/{}[]#$@*+=TechHubEMSI".split("");
    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize);
    const drops: number[] = Array(columns).fill(1);

    let animationId: number;

    const draw = () => {
      ctx.fillStyle = "rgba(10, 15, 30, 0.05)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = "#2D9CDB";
      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }

      animationId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animationId);
  }, [active]);

  if (!active) return null;

  return (
    <div className="fixed inset-0 z-[200] pointer-events-none">
      <canvas ref={canvasRef} className="w-full h-full opacity-70" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
        <p className="font-mono text-2xl text-engineering font-bold tracking-widest uppercase animate-pulse">
          ░ TechHub Mode ░
        </p>
        <p className="font-mono text-sm text-white/60 mt-2">You found the easter egg ↑↑↓↓←→←→ B A</p>
      </div>
    </div>
  );
}
