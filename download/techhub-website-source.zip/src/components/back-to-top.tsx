"use client";

import * as React from "react";
import { ArrowUp } from "lucide-react";

export function BackToTop() {
  const [show, setShow] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 600);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (!show) return null;

  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-20 right-5 z-40 h-9 w-9 rounded-md border border-border bg-background/80 backdrop-blur-md hover:border-foreground/40 hover:bg-background shadow-sm transition-colors flex items-center justify-center group [margin-bottom:env(safe-area-inset-bottom)]"
      aria-label="Back to top"
    >
      <ArrowUp className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
    </button>
  );
}
