"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * TiltCard — wraps children in a 3D perspective tilt that follows the mouse.
 * Creates a premium, tactile, holographic feel. Desktop-only (no effect on touch).
 */
export function TiltCard({
  children,
  className,
  maxTilt = 8,
  glare = true,
}: {
  children: React.ReactNode;
  className?: string;
  maxTilt?: number;
  glare?: boolean;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const [transform, setTransform] = React.useState("");
  const [glarePos, setGlarePos] = React.useState({ x: 50, y: 50, opacity: 0 });

  const onMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    if (typeof window !== "undefined" && !window.matchMedia("(pointer: fine)").matches) return;

    const rect = ref.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;

    const tiltX = (0.5 - y) * maxTilt * 2;
    const tiltY = (x - 0.5) * maxTilt * 2;

    setTransform(`perspective(800px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale(1.02)`);
    setGlarePos({ x: x * 100, y: y * 100, opacity: 0.15 });
  };

  const onMouseLeave = () => {
    setTransform("perspective(800px) rotateX(0deg) rotateY(0deg) scale(1)");
    setGlarePos((p) => ({ ...p, opacity: 0 }));
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMouseMove}
      onMouseLeave={onMouseLeave}
      className={cn("relative transition-transform duration-200 ease-out [transform-style:preserve-3d]", className)}
      style={{ transform }}
    >
      {children}
      {glare && (
        <div
          className="absolute inset-0 rounded-[inherit] pointer-events-none transition-opacity duration-200"
          style={{
            background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, rgba(45, 156, 219, ${glarePos.opacity}), transparent 60%)`,
            opacity: glarePos.opacity > 0 ? 1 : 0,
          }}
        />
      )}
    </div>
  );
}
