"use client";

import * as React from "react";
import Link from "next/link";
import { useTheme } from "next-themes";
import { Menu, X, Moon, Sun, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DiscordIcon } from "@/components/discord-icon";
import { LanguageToggle } from "@/components/language-toggle";
import { useI18n } from "@/components/i18n-provider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Logo, CombinedLogo } from "@/components/logo";
import { ROUTES, useRouterStore, navigate, type Route } from "@/lib/router";
import { useAuth } from "@/components/auth-provider";
import { cn } from "@/lib/utils";

export function Header() {
  const [open, setOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  const { route } = useRouterStore();
  const { session, logout } = useAuth();
  const { t } = useI18n();

  const navLabel = (id: string): string => {
    switch (id) {
      case "home": return t("nav.home");
      case "about": return t("nav.about");
      case "playground": return t("nav.playground");
      case "facts": return t("nav.facts");
      case "learning": return t("nav.learning");
      case "decisions": return t("nav.decisions");
      case "join": return t("nav.join");
      case "contact": return t("nav.contact");
      default: return id;
    }
  };

  React.useEffect(() => setMounted(true), []);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (r: Route) => {
    navigate(r);
    setOpen(false);
  };

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full border-b backdrop-blur-md transition-colors [padding-top:env(safe-area-inset-top)]",
        scrolled
          ? "bg-background/80 border-border shadow-[0_1px_0_0_var(--border),0_4px_30px_-10px_rgba(45,156,219,0.15)] backdrop-blur-xl"
          : "bg-background/50 border-transparent backdrop-blur-md"
      )}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          <button
            onClick={() => go("home")}
            className="flex items-center transition-opacity hover:opacity-80"
            aria-label="TechHub EMSI Fès home"
          >
            <CombinedLogo />
          </button>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1" aria-label="Primary">
            {ROUTES.filter((r) => r.id !== "home").map((r) => (
              <button
                key={r.id}
                onClick={() => go(r.id)}
                className={cn(
                  "px-3 py-1.5 text-[13.5px] rounded-md font-medium transition-colors",
                  route === r.id
                    ? "text-foreground bg-secondary"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/60"
                )}
              >
                {navLabel(r.id)}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => mounted && setTheme(theme === "dark" ? "light" : "dark")}
              aria-label="Toggle theme"
              className="h-9 w-9"
            >
              {mounted && theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <LanguageToggle />
            <Button
              asChild
              variant="ghost"
              size="icon"
              className="hidden sm:inline-flex h-9 w-9"
            >
              <a href="https://discord.gg/xyVtPuuk" target="_blank" rel="noopener noreferrer" aria-label="Discord">
                <DiscordIcon className="h-4 w-4" />
              </a>
            </Button>

            {session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-9 px-2 gap-2">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-secondary text-foreground text-xs font-mono">
                        {initials(session.name)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline text-[13.5px] font-medium">{session.name.split(" ")[0]}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col gap-0.5">
                      <p className="text-sm font-medium leading-none">{session.name}</p>
                      <p className="text-xs leading-none text-muted-foreground mt-1">{session.email}</p>
                      <span className="mt-1 inline-flex w-fit font-mono text-[10px] tracking-wider uppercase px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground">
                        {session.role}
                      </span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => go("dashboard")}>
                    Member dashboard
                    <ChevronRight className="ml-auto h-3.5 w-3.5" />
                  </DropdownMenuItem>
                  {(session.role === "ADMIN" || session.role === "LEAD") && (
                    <DropdownMenuItem onClick={() => go("admin")}>
                      Admin console
                      <ChevronRight className="ml-auto h-3.5 w-3.5" />
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={async () => { await logout(); navigate("home"); }}
                    className="text-destructive focus:text-destructive"
                  >
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                onClick={() => go("login")}
                size="sm"
                className="h-9 hidden sm:inline-flex bg-engineering hover:bg-engineering/90 text-white font-medium px-4 shadow-[0_0_20px_-4px_rgba(45,156,219,0.6)] hover:shadow-[0_0_30px_-2px_rgba(45,156,219,0.8)] transition-all duration-300 hover:-translate-y-0.5 group"
              >
                <span className="relative flex items-center gap-1.5">
                  <span className="absolute -inset-1 rounded-sm bg-engineering/30 blur-md opacity-0 group-hover:opacity-100 transition-opacity" />
                  <svg className="h-3.5 w-3.5 relative" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
                    <polyline points="10 17 15 12 10 7" />
                    <line x1="15" y1="12" x2="3" y2="12" />
                  </svg>
                  <span className="relative">{t("nav.signIn")}</span>
                </span>
              </Button>
            )}

            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden h-9 w-9"
              onClick={() => setOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile nav */}
      {open && (
        <div className="lg:hidden border-t border-border bg-background">
          <nav className="mx-auto max-w-7xl px-4 py-3 grid gap-1" aria-label="Mobile">
            {ROUTES.map((r) => (
              <button
                key={r.id}
                onClick={() => go(r.id)}
                className={cn(
                  "text-left px-3 py-2 rounded-md text-sm font-medium transition-colors",
                  route === r.id ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/60"
                )}
              >
                {navLabel(r.id)}
              </button>
            ))}
            {!session && (
              <Button onClick={() => go("login")} size="sm" className="mt-2 w-full">
                Sign in
              </Button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

function initials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

// Unused import alias kept to avoid tree-shake of next/link for future link use
void Link;
