"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, SkipForward, SkipBack, RotateCcw, Shuffle } from "lucide-react";
import { BlueprintFrame, TechPill } from "@/components/site-primitives";

type Algo = "bubble" | "insertion" | "selection";

const ALGOS: { id: Algo; label: string; complexity: string }[] = [
  { id: "bubble", label: "Bubble sort", complexity: "O(n²)" },
  { id: "insertion", label: "Insertion sort", complexity: "O(n²)" },
  { id: "selection", label: "Selection sort", complexity: "O(n²)" },
];

interface Step {
  array: number[];
  compare: [number, number] | null;
  swap: [number, number] | null;
  sorted: number[];
  description: string;
}

function genArray(size: number): number[] {
  return Array.from({ length: size }, () => Math.floor(Math.random() * 90) + 10);
}

function makeSteps(algo: Algo, input: number[]): Step[] {
  const arr = [...input];
  const steps: Step[] = [];
  const sorted: number[] = [];

  function snapshot(compare: [number, number] | null, swap: [number, number] | null, description: string) {
    steps.push({ array: [...arr], compare, swap, sorted: [...sorted], description });
  }

  snapshot(null, null, `Initial array of ${arr.length} elements.`);

  if (algo === "bubble") {
    for (let i = 0; i < arr.length; i++) {
      for (let j = 0; j < arr.length - i - 1; j++) {
        snapshot([j, j + 1], null, `Compare arr[${j}] (${arr[j]}) and arr[${j + 1}] (${arr[j + 1]}).`);
        if (arr[j] > arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          snapshot(null, [j, j + 1], `Swap — arr[${j}] was larger.`);
        }
      }
      sorted.unshift(arr.length - i - 1);
    }
  } else if (algo === "insertion") {
    for (let i = 1; i < arr.length; i++) {
      let j = i;
      while (j > 0) {
        snapshot([j - 1, j], null, `Compare arr[${j - 1}] (${arr[j - 1]}) and arr[${j}] (${arr[j]}).`);
        if (arr[j - 1] > arr[j]) {
          [arr[j - 1], arr[j]] = [arr[j], arr[j - 1]];
          snapshot(null, [j - 1, j], `Shift left — arr[${j - 1}] was larger.`);
          j--;
        } else {
          break;
        }
      }
    }
    for (let k = 0; k < arr.length; k++) sorted.push(k);
  } else if (algo === "selection") {
    for (let i = 0; i < arr.length; i++) {
      let min = i;
      for (let j = i + 1; j < arr.length; j++) {
        snapshot([min, j], null, `Is arr[${j}] (${arr[j]}) smaller than current min (${arr[min]})?`);
        if (arr[j] < arr[min]) min = j;
      }
      if (min !== i) {
        [arr[i], arr[min]] = [arr[min], arr[i]];
        snapshot(null, [i, min], `Swap min into position ${i}.`);
      }
      sorted.push(i);
    }
  }

  snapshot(null, null, "Sorted.");
  return steps;
}

export function AlgorithmVisualizer() {
  const [algo, setAlgo] = React.useState<Algo>("bubble");
  const [size, setSize] = React.useState(12);
  const [array, setArray] = React.useState<number[]>(() => genArray(12));
  const [steps, setSteps] = React.useState<Step[]>([]);
  const [idx, setIdx] = React.useState(0);
  const [playing, setPlaying] = React.useState(false);
  const [speed, setSpeed] = React.useState(50);

  React.useEffect(() => {
    setSteps(makeSteps(algo, array));
    setIdx(0);
  }, [algo, array]);

  React.useEffect(() => {
    if (!playing) return;
    const interval = setInterval(() => {
      setIdx((i) => {
        if (i >= steps.length - 1) { setPlaying(false); return i; }
        return i + 1;
      });
    }, 510 - speed * 5);
    return () => clearInterval(interval);
  }, [playing, steps.length, speed]);

  const current = steps[idx] || { array, compare: null, swap: null, sorted: [], description: "" };

  function shuffle() {
    setArray(genArray(size));
    setPlaying(false);
  }

  function reset() {
    setArray(genArray(size));
    setIdx(0);
    setPlaying(false);
  }

  function changeSize(s: number) {
    setSize(s);
    setArray(genArray(s));
    setPlaying(false);
  }

  const max = Math.max(...current.array);

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-8 space-y-5">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Algorithm</Label>
          <div className="grid grid-cols-3 gap-1 mt-2">
            {ALGOS.map((a) => (
              <button
                key={a.id}
                onClick={() => setAlgo(a.id)}
                className={
                  "font-mono text-[11px] tracking-wider uppercase px-2 py-2 rounded-sm border transition-colors " +
                  (algo === a.id
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")
                }
              >
                {a.label}
              </button>
            ))}
          </div>
        </div>

        <BlueprintFrame className="border border-border rounded-md p-5 bg-secondary/20">
          <div className="h-72 flex items-end gap-1">
            {current.array.map((v, i) => {
              const isCompare = current.compare && (current.compare[0] === i || current.compare[1] === i);
              const isSwap = current.swap && (current.swap[0] === i || current.swap[1] === i);
              const isSorted = current.sorted.includes(i);
              const bg = isSwap ? "bg-destructive" : isCompare ? "bg-engineering" : isSorted ? "bg-foreground/80" : "bg-foreground/30";
              return (
                <div
                  key={i}
                  className="flex-1 rounded-t-sm transition-all"
                  style={{
                    height: `${(v / max) * 100}%`,
                    background: "var(--fallback)",
                  }}
                >
                  <div className={`h-full w-full rounded-t-sm ${bg}`} />
                </div>
              );
            })}
          </div>
        </BlueprintFrame>

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setIdx(0)} disabled={idx === 0}>
            <SkipBack className="h-3.5 w-3.5" />
          </Button>
          <Button
            size="sm"
            onClick={() => setPlaying((p) => !p)}
            disabled={idx >= steps.length - 1}
            className="bg-engineering hover:bg-engineering/90"
          >
            {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            <span className="ml-1.5">{playing ? "Pause" : "Play"}</span>
          </Button>
          <Button variant="outline" size="sm" onClick={() => setIdx((i) => Math.min(steps.length - 1, i + 1))} disabled={idx >= steps.length - 1}>
            <SkipForward className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="sm" onClick={reset}>
            <RotateCcw className="h-3.5 w-3.5" />
            <span className="ml-1.5">Reset</span>
          </Button>
          <Button variant="ghost" size="sm" onClick={shuffle}>
            <Shuffle className="h-3.5 w-3.5" />
            <span className="ml-1.5">Shuffle</span>
          </Button>
          <div className="ml-auto flex items-center gap-3">
            <span className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Speed</span>
            <Slider value={[speed]} onValueChange={(v) => setSpeed(v[0])} min={1} max={100} step={1} className="w-28" />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <div className="border border-border rounded-md p-3 bg-background">
            <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Step</p>
            <p className="font-mono text-sm mt-1">{idx + 1} / {steps.length}</p>
          </div>
          <div className="border border-border rounded-md p-3 bg-background">
            <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Description</p>
            <p className="text-sm mt-1 text-foreground">{current.description}</p>
          </div>
        </div>
      </div>

      <div className="lg:col-span-4 space-y-5">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Array size: {size}</Label>
          <Slider
            value={[size]}
            onValueChange={(v) => changeSize(v[0])}
            min={5}
            max={30}
            step={1}
            className="mt-3"
          />
        </div>

        <BlueprintFrame className="border border-border rounded-md p-4 bg-secondary/20">
          <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-2">Algorithm</p>
          <h3 className="font-semibold">{ALGOS.find((a) => a.id === algo)!.label}</h3>
          <div className="flex flex-wrap gap-1.5 mt-3">
            <TechPill>{ALGOS.find((a) => a.id === algo)!.complexity}</TechPill>
            <TechPill>stable: {algo === "selection" ? "no" : "yes"}</TechPill>
            <TechPill>in-place: yes</TechPill>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed mt-3">
            {algo === "bubble" && "Repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order. The largest unsorted element 'bubbles up' to its position each pass."}
            {algo === "insertion" && "Builds the sorted array one element at a time. Each new element is compared backwards and shifted into its correct position — like sorting a hand of cards."}
            {algo === "selection" && "Finds the minimum element in the unsorted portion and swaps it into place. Minimum number of swaps among the three — useful when writes are expensive."}
          </p>
        </BlueprintFrame>

        <div className="border border-border rounded-md p-4">
          <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground mb-3">Legend</p>
          <ul className="space-y-2 text-xs">
            <li className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm bg-foreground/30" /> Unsorted
            </li>
            <li className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm bg-engineering" /> Comparing
            </li>
            <li className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm bg-destructive" /> Swapping
            </li>
            <li className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm bg-foreground/80" /> Sorted
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
