"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Copy, Check, RefreshCw, ShieldCheck, Shield, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { TechPill, BlueprintFrame } from "@/components/site-primitives";

const SETS = {
  lower: "abcdefghijklmnopqrstuvwxyz",
  upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  numbers: "0123456789",
  symbols: "!@#$%^&*()-_=+[]{};:,.<>?/~",
};

function generate(length: number, opts: Record<keyof typeof SETS, boolean>): string {
  let pool = "";
  if (opts.lower) pool += SETS.lower;
  if (opts.upper) pool += SETS.upper;
  if (opts.numbers) pool += SETS.numbers;
  if (opts.symbols) pool += SETS.symbols;
  if (!pool) return "";
  const arr = new Uint32Array(length);
  crypto.getRandomValues(arr);
  let out = "";
  for (let i = 0; i < length; i++) out += pool[arr[i] % pool.length];
  return out;
}

function strength(pw: string): { score: number; label: string; color: string } {
  if (!pw) return { score: 0, label: "—", color: "bg-secondary" };
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 14) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^a-zA-Z0-9]/.test(pw)) s++;
  const labels = ["Very weak", "Weak", "Fair", "Good", "Strong", "Very strong"];
  const colors = ["bg-destructive", "bg-destructive", "bg-amber-500", "bg-engineering", "bg-engineering", "bg-emerald-600"];
  return { score: s, label: labels[s], color: colors[s] };
}

export function PasswordGenerator() {
  const [length, setLength] = React.useState(20);
  const [opts, setOpts] = React.useState<Record<keyof typeof SETS, boolean>>({ lower: true, upper: true, numbers: true, symbols: true });
  const [pw, setPw] = React.useState("");
  const [copied, setCopied] = React.useState(false);
  const [show, setShow] = React.useState(true);

  const regen = React.useCallback(() => {
    setPw(generate(length, opts));
    setCopied(false);
  }, [length, opts]);

  React.useEffect(() => { regen(); }, [regen]);

  const s = strength(pw);

  function copy() {
    navigator.clipboard.writeText(pw);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.success("Password copied.");
  }

  const ShieldIcon = s.score >= 3 ? ShieldCheck : s.score >= 1 ? Shield : ShieldAlert;

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 space-y-5">
        {/* Output */}
        <BlueprintFrame className="border border-border rounded-md p-5 bg-background">
          <div className="flex items-center gap-2">
            <code className={"flex-1 font-mono text-base break-all " + (show ? "text-foreground" : "text-muted-foreground")}>
              {show ? pw : "•".repeat(pw.length)}
            </code>
            <Button variant="ghost" size="sm" onClick={() => setShow((v) => !v)} className="h-8 w-8 p-0">
              {show ? "🙈" : "👁"}
            </Button>
            <Button variant="ghost" size="sm" onClick={copy} className="h-8 w-8 p-0">
              {copied ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={regen} className="h-8 w-8 p-0">
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="mt-4 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1.5 text-muted-foreground font-mono">
                <ShieldIcon className="h-3.5 w-3.5" />
                {s.label}
              </span>
              <span className="font-mono text-muted-foreground">{pw.length} chars</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
              <div className={"h-full rounded-full transition-all " + s.color} style={{ width: `${(s.score / 5) * 100}%` }} />
            </div>
          </div>
        </BlueprintFrame>

        {/* Entropy */}
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div className="border border-border rounded-md p-3 bg-background">
            <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Entropy</p>
            <p className="font-mono text-lg text-foreground mt-1">{Math.round(pw.length * Math.log2(Object.values(SETS).filter((_, i) => Object.values(opts)[i]).join("").length || 1))} bits</p>
          </div>
          <div className="border border-border rounded-md p-3 bg-background">
            <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Crack time</p>
            <p className="font-mono text-lg text-foreground mt-1">{s.score >= 4 ? "centuries" : s.score === 3 ? "weeks" : s.score === 2 ? "hours" : "seconds"}</p>
          </div>
          <div className="border border-border rounded-md p-3 bg-background">
            <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Charset</p>
            <p className="font-mono text-lg text-foreground mt-1">{Object.values(SETS).filter((_, i) => Object.values(opts)[i]).join("").length}</p>
          </div>
        </div>
      </div>

      <div className="lg:col-span-5 space-y-5">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Length: {length}</Label>
          <Slider value={[length]} onValueChange={(v) => setLength(v[0])} min={4} max={64} step={1} className="mt-3" />
          <div className="flex justify-between mt-1 text-[10px] font-mono text-muted-foreground">
            <span>4</span><span>16</span><span>32</span><span>48</span><span>64</span>
          </div>
        </div>

        <div className="space-y-2">
          <p className="label-mono">Character sets</p>
          {(Object.keys(SETS) as (keyof typeof SETS)[]).map((k) => (
            <label key={k} className="flex items-center gap-3 p-3 border border-border rounded-md bg-background cursor-pointer hover:border-foreground/30 transition-colors">
              <input
                type="checkbox"
                checked={opts[k]}
                onChange={(e) => setOpts((o) => ({ ...o, [k]: e.target.checked }))}
                className="accent-engineering h-4 w-4"
              />
              <span className="text-sm font-medium capitalize">{k}</span>
              <code className="ml-auto font-mono text-[11px] text-muted-foreground">{SETS[k].slice(0, 12)}…</code>
            </label>
          ))}
        </div>

        <div className="flex flex-wrap gap-1.5">
          <TechPill>crypto.getRandomValues</TechPill>
          <TechPill>client-side only</TechPill>
        </div>
      </div>
    </div>
  );
}
