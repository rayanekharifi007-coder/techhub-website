"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RotateCcw } from "lucide-react";
import { BlueprintFrame, TechPill } from "@/components/site-primitives";

type GateType = "AND" | "OR" | "NOT" | "NAND" | "NOR" | "XOR" | "XNOR";

const GATES: { type: GateType; symbol: string; arity: 1 | 2; desc: string }[] = [
  { type: "AND", symbol: "&", arity: 2, desc: "1 if both inputs are 1" },
  { type: "OR", symbol: "|", arity: 2, desc: "1 if either input is 1" },
  { type: "NOT", symbol: "!", arity: 1, desc: "Inverts the input" },
  { type: "NAND", symbol: "⊼", arity: 2, desc: "AND then NOT" },
  { type: "NOR", symbol: "⊽", arity: 2, desc: "OR then NOT" },
  { type: "XOR", symbol: "⊕", arity: 2, desc: "1 if inputs differ" },
  { type: "XNOR", symbol: "⊙", arity: 2, desc: "1 if inputs match" },
];

function evalGate(gate: GateType, a: boolean, b: boolean): boolean {
  switch (gate) {
    case "AND": return a && b;
    case "OR": return a || b;
    case "NOT": return !a;
    case "NAND": return !(a && b);
    case "NOR": return !(a || b);
    case "XOR": return a !== b;
    case "XNOR": return a === b;
  }
}

export function LogicGateSimulator() {
  const [gate, setGate] = React.useState<GateType>("AND");
  const [a, setA] = React.useState(false);
  const [b, setB] = React.useState(false);

  const meta = GATES.find((g) => g.type === gate)!;
  const out = evalGate(gate, a, b);

  // Build the truth table
  const rows = meta.arity === 1
    ? [[false], [true]]
    : [
        [false, false], [false, true],
        [true, false], [true, true],
      ];

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 space-y-6">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Gate</Label>
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 mt-2">
            {GATES.map((g) => (
              <button
                key={g.type}
                onClick={() => setGate(g.type)}
                className={
                  "font-mono text-[11px] tracking-wider px-2 py-2 rounded-sm border transition-colors " +
                  (gate === g.type
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")
                }
                title={g.desc}
              >
                {g.type}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2 font-mono">{meta.desc}</p>
        </div>

        {/* Schematic */}
        <BlueprintFrame className="border border-border rounded-md p-6 bg-secondary/20">
          <svg viewBox="0 0 460 200" className="w-full" role="img" aria-label="Logic gate schematic">
            {/* Wires from inputs */}
            <line x1="20" y1="70" x2="180" y2="70" stroke="currentColor" strokeWidth="1.5" className={a ? "text-engineering" : "text-foreground/40"} />
            {meta.arity === 2 && (
              <line x1="20" y1="130" x2="180" y2="130" stroke="currentColor" strokeWidth="1.5" className={b ? "text-engineering" : "text-foreground/40"} />
            )}
            {/* Input labels */}
            <text x="10" y="74" className="font-mono" fontSize="11" fill="currentColor">A</text>
            {meta.arity === 2 && <text x="10" y="134" className="font-mono" fontSize="11" fill="currentColor">B</text>}
            {/* Gate body */}
            <rect x="180" y="50" width="100" height={meta.arity === 2 ? 100 : 60} fill="var(--background)" stroke="currentColor" strokeWidth="1.5" className="text-foreground" rx="2" />
            <text x="230" y={meta.arity === 2 ? 110 : 86} textAnchor="middle" className="font-mono" fontSize="22" fill="currentColor" fontWeight="600">
              {meta.symbol}
            </text>
            <text x="230" y={meta.arity === 2 ? 130 : 106} textAnchor="middle" className="font-mono" fontSize="9" fill="var(--muted-foreground)" fontWeight="500">
              {gate}
            </text>
            {/* Output wire */}
            <line x1="280" y1={meta.arity === 2 ? 100 : 80} x2="420" y2={meta.arity === 2 ? 100 : 80} stroke="currentColor" strokeWidth="1.5" className={out ? "text-engineering" : "text-foreground/40"} />
            <text x="430" y={meta.arity === 2 ? 104 : 84} className="font-mono" fontSize="11" fill="currentColor">Q</text>
            {/* Input dots */}
            <circle cx="20" cy="70" r="4" fill={a ? "var(--engineering)" : "var(--muted-foreground)"} />
            {meta.arity === 2 && <circle cx="20" cy="130" r="4" fill={b ? "var(--engineering)" : "var(--muted-foreground)"} />}
            {/* Output dot */}
            <circle cx="420" cy={meta.arity === 2 ? 100 : 80} r="5" fill={out ? "var(--engineering)" : "var(--muted-foreground)"} />
          </svg>
        </BlueprintFrame>

        {/* Input toggles */}
        <div className="grid grid-cols-2 gap-3">
          <InputToggle label="A" value={a} onChange={setA} />
          {meta.arity === 2 ? (
            <InputToggle label="B" value={b} onChange={setB} />
          ) : (
            <div className="border border-dashed border-border rounded-md p-4 bg-secondary/20 flex items-center justify-center text-xs text-muted-foreground font-mono">
              NOT is unary — only A is used.
            </div>
          )}
        </div>

        <div className="flex items-center justify-between p-4 border border-border rounded-md bg-background">
          <div>
            <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Output Q</p>
            <p className={"font-mono text-2xl font-semibold mt-1 " + (out ? "text-engineering" : "text-foreground/40")}>
              {out ? "1" : "0"}
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => { setA(false); setB(false); }}>
            <RotateCcw className="mr-2 h-3.5 w-3.5" />
            Reset
          </Button>
        </div>
      </div>

      <div className="lg:col-span-5 space-y-3">
        <p className="label-mono">Truth table</p>
        <div className="border border-border rounded-md overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-secondary/50 border-b border-border">
                <th className="text-left p-2 font-mono text-[10px] tracking-wider uppercase text-muted-foreground">A</th>
                {meta.arity === 2 && <th className="text-left p-2 font-mono text-[10px] tracking-wider uppercase text-muted-foreground">B</th>}
                <th className="text-left p-2 font-mono text-[10px] tracking-wider uppercase text-engineering">Q</th>
                <th className="text-left p-2 font-mono text-[10px] tracking-wider uppercase text-muted-foreground">match</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const result = meta.arity === 1 ? evalGate(gate, r[0], false) : evalGate(gate, r[0], r[1]);
                const isCurrent = meta.arity === 1 ? a === r[0] : a === r[0] && b === r[1];
                return (
                  <tr key={i} className={"border-b border-border last:border-0 " + (isCurrent ? "bg-engineering/5" : "")}>
                    <td className="p-2 font-mono">{r[0] ? 1 : 0}</td>
                    {meta.arity === 2 && <td className="p-2 font-mono">{r[1] ? 1 : 0}</td>}
                    <td className={"p-2 font-mono font-semibold " + (result ? "text-engineering" : "text-foreground/40")}>{result ? 1 : 0}</td>
                    <td className="p-2 font-mono text-[10px] text-muted-foreground">{isCurrent ? "←" : ""}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="space-y-2 pt-2">
          <p className="label-mono">Tip</p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Try the NAND gate — it is <em>functionally complete</em>, meaning every other logic
            gate can be built from NANDs alone. That is why NAND is the workhorse of digital
            electronics and CPU design.
          </p>
          <div className="flex flex-wrap gap-1.5 pt-1">
            <TechPill>74xx00</TechPill>
            <TechPill>CMOS</TechPill>
            <TechPill>universal gate</TechPill>
          </div>
        </div>
      </div>
    </div>
  );
}

function InputToggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={
        "p-4 border rounded-md text-left transition-colors " +
        (value
          ? "border-engineering bg-engineering/5"
          : "border-border bg-background hover:border-foreground/30")
      }
    >
      <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Input {label}</p>
      <p className={"font-mono text-2xl font-semibold mt-1 " + (value ? "text-engineering" : "text-foreground/40")}>
        {value ? "1" : "0"}
      </p>
    </button>
  );
}
