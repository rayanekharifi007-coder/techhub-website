"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Check, Hash, Braces, Regex, Fingerprint } from "lucide-react";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function DevTools() {
  return (
    <Tabs defaultValue="regex">
      <TabsList className="flex h-auto flex-wrap gap-1 bg-secondary/50 p-1 rounded-md">
        <TabsTrigger value="regex" className="gap-2"><Regex className="h-3.5 w-3.5" /> Regex tester</TabsTrigger>
        <TabsTrigger value="json" className="gap-2"><Braces className="h-3.5 w-3.5" /> JSON formatter</TabsTrigger>
        <TabsTrigger value="uuid" className="gap-2"><Fingerprint className="h-3.5 w-3.5" /> UUID generator</TabsTrigger>
        <TabsTrigger value="hash" className="gap-2"><Hash className="h-3.5 w-3.5" /> Hash & encode</TabsTrigger>
      </TabsList>
      <TabsContent value="regex" className="mt-4"><RegexTester /></TabsContent>
      <TabsContent value="json" className="mt-4"><JsonFormatter /></TabsContent>
      <TabsContent value="uuid" className="mt-4"><UuidGenerator /></TabsContent>
      <TabsContent value="hash" className="mt-4"><HashTool /></TabsContent>
    </Tabs>
  );
}

function RegexTester() {
  const [pattern, setPattern] = React.useState("\\b(\\w+@\\w+\\.\\w+)\\b");
  const [flags, setFlags] = React.useState("g");
  const [text, setText] = React.useState("Contact us at emsi.techhub@gmail.com or admin@techhub-emsi.ma.");

  const { matches, error } = React.useMemo(() => {
    if (!pattern) return { matches: [], error: null as string | null };
    try {
      const re = new RegExp(pattern, flags);
      const out: { match: string; index: number; groups: string[] }[] = [];
      if (flags.includes("g")) {
        let m;
        while ((m = re.exec(text)) !== null) {
          out.push({ match: m[0], index: m.index, groups: m.slice(1) });
          if (m.index === re.lastIndex) re.lastIndex++;
        }
      } else {
        const m = re.exec(text);
        if (m) out.push({ match: m[0], index: m.index, groups: m.slice(1) });
      }
      return { matches: out, error: null as string | null };
    } catch (e) {
      return { matches: [], error: (e as Error).message };
    }
  }, [pattern, flags, text]);

  const highlighted = React.useMemo(() => {
    if (error || matches.length === 0) return [{ t: text, hit: false }];
    const parts: { t: string; hit: boolean }[] = [];
    let last = 0;
    matches.forEach((m) => {
      if (m.index > last) parts.push({ t: text.slice(last, m.index), hit: false });
      parts.push({ t: m.match, hit: true });
      last = m.index + m.match.length;
    });
    if (last < text.length) parts.push({ t: text.slice(last), hit: false });
    return parts;
  }, [matches, text, error]);

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Pattern</Label>
          <div className="flex gap-2 mt-1.5">
            <Input value={pattern} onChange={(e) => setPattern(e.target.value)} className="font-mono" />
            <Input value={flags} onChange={(e) => setFlags(e.target.value)} className="font-mono w-20" />
          </div>
        </div>
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Test text</Label>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="font-mono mt-1.5 min-h-[160px]"
          />
        </div>
        {error && <p className="text-xs text-destructive font-mono">{error}</p>}
      </div>
      <div className="space-y-3">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Highlighted</Label>
          <div className="mt-1.5 border border-border rounded-md p-3 bg-secondary/30 font-mono text-sm leading-relaxed whitespace-pre-wrap break-words">
            {highlighted.map((p, i) => (
              <mark
                key={i}
                className={
                  p.hit
                    ? "bg-engineering/20 text-engineering rounded-sm px-0.5"
                    : "bg-transparent text-foreground"
                }
              >
                {p.t}
              </mark>
            ))}
          </div>
        </div>
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Matches · {matches.length}</Label>
          <div className="mt-1.5 space-y-1.5 max-h-60 overflow-y-auto scrollbar-thin">
            {matches.length === 0 && (
              <p className="text-xs text-muted-foreground font-mono px-3 py-2 border border-dashed border-border rounded-md">
                No matches.
              </p>
            )}
            {matches.map((m, i) => (
              <div key={i} className="border border-border rounded-md p-2 bg-background text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-foreground">{m.match}</span>
                  <span className="text-muted-foreground">@{m.index}</span>
                </div>
                {m.groups.length > 0 && (
                  <div className="mt-1 text-muted-foreground">
                    groups: {m.groups.map((g, j) => <span key={j} className="text-engineering">[{g}]</span>)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function JsonFormatter() {
  const [input, setInput] = React.useState('{"name":"TechHub","founded":2026,"tracks":["systems","ai","web"]}');
  const [copied, setCopied] = React.useState(false);

  const { pretty, error } = React.useMemo(() => {
    try {
      const obj = JSON.parse(input);
      return { pretty: JSON.stringify(obj, null, 2), error: null as string | null };
    } catch (e) {
      return { pretty: "", error: (e as Error).message };
    }
  }, [input]);

  function minify() {
    try {
      const obj = JSON.parse(input);
      setInput(JSON.stringify(obj));
      toast.success("Minified.");
    } catch {
      toast.error("Invalid JSON.");
    }
  }

  function copy() {
    navigator.clipboard.writeText(pretty);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.success("Copied.");
  }

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <Label className="text-xs font-mono uppercase tracking-wider">Input</Label>
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="font-mono min-h-[320px]"
        />
        {error && <p className="text-xs text-destructive font-mono">{error}</p>}
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={minify}>Minify</Button>
        </div>
      </div>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-xs font-mono uppercase tracking-wider">Pretty</Label>
          <Button size="sm" variant="ghost" onClick={copy} disabled={!pretty}>
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            <span className="ml-1.5">Copy</span>
          </Button>
        </div>
        <pre className="font-mono text-[12.5px] leading-relaxed border border-border rounded-md p-3 bg-secondary/30 min-h-[320px] whitespace-pre overflow-auto scrollbar-thin">
          {pretty || "// invalid JSON"}
        </pre>
      </div>
    </div>
  );
}

function UuidGenerator() {
  const [count, setCount] = React.useState(5);
  const [uuids, setUuids] = React.useState<string[]>([]);
  const [copiedIdx, setCopiedIdx] = React.useState<number | null>(null);

  function uuidv4(): string {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
    const b = new Uint8Array(16);
    crypto.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const hex = Array.from(b).map((x) => x.toString(16).padStart(2, "0"));
    return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10, 16).join("")}`;
  }

  React.useEffect(() => {
    setUuids(Array.from({ length: count }, () => uuidv4()));
  }, [count]);

  function copy(i: number) {
    navigator.clipboard.writeText(uuids[i]);
    setCopiedIdx(i);
    setTimeout(() => setCopiedIdx(null), 1500);
    toast.success("Copied.");
  }

  function regenerate() {
    setUuids(Array.from({ length: count }, () => uuidv4()));
  }

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="flex items-center gap-3">
        <Label className="text-xs font-mono uppercase tracking-wider">Count: {count}</Label>
        <Input
          type="number"
          min={1}
          max={50}
          value={count}
          onChange={(e) => setCount(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
          className="w-24"
        />
        <Button size="sm" onClick={regenerate}>Regenerate</Button>
      </div>
      <div className="space-y-2">
        {uuids.map((u, i) => (
          <div
            key={i}
            className="flex items-center gap-3 border border-border rounded-md p-3 bg-background hover:border-foreground/30 transition-colors"
          >
            <span className="font-mono text-[10px] text-muted-foreground w-6">{i + 1}</span>
            <code className="flex-1 font-mono text-sm">{u}</code>
            <Button variant="ghost" size="sm" onClick={() => copy(i)} className="h-8 w-8 p-0">
              {copiedIdx === i ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

function HashTool() {
  const [input, setInput] = React.useState("TechHub EMSI Fès");
  const [outputs, setOutputs] = React.useState<{ algo: string; value: string }[]>([]);
  const [copied, setCopied] = React.useState<string | null>(null);

  React.useEffect(() => {
    (async () => {
      const enc = new TextEncoder().encode(input);
      const algos = [
        { algo: "SHA-1", id: "SHA-1" },
        { algo: "SHA-256", id: "SHA-256" },
        { algo: "SHA-384", id: "SHA-384" },
        { algo: "SHA-512", id: "SHA-512" },
      ];
      const results = await Promise.all(
        algos.map(async (a) => {
          const buf = await crypto.subtle.digest(a.id, enc);
          return { algo: a.algo, value: Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("") };
        })
      );
      // base64
      const b64 = btoa(unescape(encodeURIComponent(input)));
      results.push({ algo: "Base64", value: b64 });
      // url-encoded
      results.push({ algo: "URL-encoded", value: encodeURIComponent(input) });
      setOutputs(results);
    })();
  }, [input]);

  function copy(algo: string, value: string) {
    navigator.clipboard.writeText(value);
    setCopied(algo);
    setTimeout(() => setCopied(null), 1500);
    toast.success(`Copied ${algo}.`);
  }

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <Label className="text-xs font-mono uppercase tracking-wider">Input</Label>
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="font-mono min-h-[320px]"
        />
        <p className="text-xs text-muted-foreground">
          {input.length} chars · {new Blob([input]).size} bytes
        </p>
      </div>
      <div className="space-y-2">
        <Label className="text-xs font-mono uppercase tracking-wider">Digests & encodings</Label>
        {outputs.map((o) => (
          <div key={o.algo} className="border border-border rounded-md p-3 bg-background">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-mono text-[10px] tracking-widest uppercase text-engineering">{o.algo}</span>
              <Button variant="ghost" size="sm" onClick={() => copy(o.algo, o.value)} className="h-7 w-7 p-0">
                {copied === o.algo ? <Check className="h-3 w-3 text-engineering" /> : <Copy className="h-3 w-3" />}
              </Button>
            </div>
            <code className="font-mono text-[11.5px] break-all leading-relaxed text-foreground">{o.value}</code>
          </div>
        ))}
      </div>
    </div>
  );
}
