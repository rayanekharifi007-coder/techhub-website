"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shuffle, Copy, Check, Lock, Unlock } from "lucide-react";
import { toast } from "sonner";
import { TechPill, BlueprintFrame } from "@/components/site-primitives";

// HSL → HEX helpers
function hslToHex(h: number, s: number, l: number): string {
  l /= 100;
  const a = (s * Math.min(l, 1 - l)) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

function hexToHsl(hex: string): [number, number, number] {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}

const SCHEMES = [
  { id: "analogous", label: "Analogous", offsets: [0, 30, 60, -30, -60] },
  { id: "complementary", label: "Complementary", offsets: [0, 180, 30, 210, 60] },
  { id: "triadic", label: "Triadic", offsets: [0, 120, 240, 60, 180] },
  { id: "split", label: "Split-complement", offsets: [0, 150, 210, 30, 330] },
  { id: "mono", label: "Monochrome", offsets: [0, 0, 0, 0, 0] },
] as const;

export function ColorPalette() {
  const [base, setBase] = React.useState("#1f3a8a");
  const [scheme, setScheme] = React.useState<(typeof SCHEMES)[number]["id"]>("analogous");
  const [locked, setLocked] = React.useState<boolean[]>([true, false, false, false, false]);
  const [copied, setCopied] = React.useState<number | null>(null);

  const palette = React.useMemo(() => {
    const [h, s, l] = hexToHsl(base);
    const offsets = SCHEMES.find((x) => x.id === scheme)!.offsets;
    return offsets.map((off, i) => {
      if (scheme === "mono") {
        const lightnesses = [25, 40, 55, 70, 85];
        return hslToHex(h, s, lightnesses[i]);
      }
      const newH = (h + off + 360) % 360;
      return hslToHex(newH, s, l);
    });
  }, [base, scheme]);

  function shuffle() {
    const newBase = hslToHex(Math.floor(Math.random() * 360), 50 + Math.floor(Math.random() * 30), 40 + Math.floor(Math.random() * 20));
    setBase(newBase);
  }

  function copy(i: number) {
    navigator.clipboard.writeText(palette[i].toUpperCase());
    setCopied(i);
    setTimeout(() => setCopied(null), 1500);
    toast.success(`Copied ${palette[i].toUpperCase()}.`);
  }

  function copyAll() {
    navigator.clipboard.writeText(palette.map((c) => c.toUpperCase()).join(", "));
    toast.success("Palette copied.");
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <label className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Base</label>
          <input type="color" value={base} onChange={(e) => setBase(e.target.value)} className="h-9 w-12 rounded border border-border bg-transparent cursor-pointer" />
          <Input value={base} onChange={(e) => setBase(e.target.value)} className="font-mono w-28" />
        </div>
        <div className="flex items-center gap-1">
          {SCHEMES.map((s) => (
            <button
              key={s.id}
              onClick={() => setScheme(s.id)}
              className={"font-mono text-[10px] tracking-wider uppercase px-2 py-1.5 rounded-sm border transition-colors " + (scheme === s.id ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")}
            >
              {s.label}
            </button>
          ))}
        </div>
        <Button size="sm" variant="outline" onClick={shuffle} className="ml-auto">
          <Shuffle className="mr-1.5 h-3.5 w-3.5" /> Randomize
        </Button>
        <Button size="sm" variant="ghost" onClick={copyAll}>
          <Copy className="mr-1.5 h-3.5 w-3.5" /> Copy all
        </Button>
      </div>

      {/* Palette swatches */}
      <div className="grid grid-cols-5 gap-2 h-64">
        {palette.map((c, i) => (
          <div key={i} className="group relative rounded-md overflow-hidden border border-border" style={{ background: c }}>
            <button
              onClick={() => setLocked((l) => { const n = [...l]; n[i] = !n[i]; return n; })}
              className="absolute top-2 right-2 h-7 w-7 rounded-md bg-black/20 backdrop-blur-sm flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label={locked[i] ? "Unlock" : "Lock"}
            >
              {locked[i] ? <Lock className="h-3.5 w-3.5" /> : <Unlock className="h-3.5 w-3.5" />}
            </button>
            <button
              onClick={() => copy(i)}
              className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-black/40 to-transparent text-white text-xs font-mono opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-between"
            >
              <span>{c.toUpperCase()}</span>
              {copied === i ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
            </button>
          </div>
        ))}
      </div>

      <BlueprintFrame className="border border-border rounded-md p-4 bg-secondary/20">
        <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-2">CSS variables</p>
        <pre className="font-mono text-[12px] text-foreground overflow-x-auto scrollbar-thin">
{`--c1: ${palette[0].toUpperCase()};
--c2: ${palette[1].toUpperCase()};
--c3: ${palette[2].toUpperCase()};
--c4: ${palette[3].toUpperCase()};
--c5: ${palette[4].toUpperCase()};`}
        </pre>
      </BlueprintFrame>

      <div className="flex flex-wrap gap-1.5">
        <TechPill>HSL math</TechPill>
        <TechPill>5 schemes</TechPill>
        <TechPill>lockable swatches</TechPill>
      </div>
    </div>
  );
}
