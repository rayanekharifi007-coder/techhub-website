"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Download, Link2, Wifi, Mail, Phone, MessageSquare, Loader2, Check } from "lucide-react";
import { TechPill } from "@/components/site-primitives";
import { toast } from "sonner";

type Mode = "text" | "url" | "wifi" | "email" | "phone" | "sms";

export function QrGenerator() {
  const [mode, setMode] = React.useState<Mode>("text");
  const [text, setText] = React.useState("https://techhub-emsi.ma");
  const [size, setSize] = React.useState(280);
  const [color, setColor] = React.useState("#0f172a");
  const [bg, setBg] = React.useState("#ffffff");
  const [errorLevel, setErrorLevel] = React.useState<"L" | "M" | "Q" | "H">("M");

  // WiFi fields
  const [ssid, setSsid] = React.useState("");
  const [wifiPass, setWifiPass] = React.useState("");
  const [encryption, setEncryption] = React.useState<"WPA" | "WEP" | "nopass">("WPA");

  // Email/phone/sms
  const [recipient, setRecipient] = React.useState("");

  const payload = React.useMemo(() => {
    if (mode === "wifi") {
      return `WIFI:T:${encryption};S:${ssid};P:${wifiPass};;`;
    }
    if (mode === "email") return `mailto:${recipient}`;
    if (mode === "phone") return `tel:${recipient}`;
    if (mode === "sms") return `smsto:${recipient}:${text}`;
    return text;
  }, [mode, text, ssid, wifiPass, encryption, recipient]);

  // Use api.qrserver.com — public, no API key, supports color & size
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(payload)}&color=${color.slice(1)}&bgcolor=${bg.slice(1)}&ecc=${errorLevel}`;

  const [downloading, setDownloading] = React.useState(false);

  async function download() {
    setDownloading(true);
    try {
      const proxyUrl = `/api/qr-download?url=${encodeURIComponent(qrUrl)}`;
      const res = await fetch(proxyUrl);
      if (!res.ok) throw new Error("Download failed");
      const blob = await res.blob();

      // Create object URL
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `qr-code-${Date.now()}.png`;
      link.rel = "noopener";
      link.style.display = "none";
      document.body.appendChild(link);

      // Try click event
      link.click();
      toast.success("QR code downloaded.");

      // Cleanup
      setTimeout(() => {
        if (link.parentNode) document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
      }, 2000);
    } catch (e) {
      // Fallback: open in new tab so user can save manually
      window.open(qrUrl, "_blank");
    } finally {
      setDownloading(false);
    }
  }

  const MODES: { id: Mode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "text", label: "Text", icon: MessageSquare },
    { id: "url", label: "URL", icon: Link2 },
    { id: "wifi", label: "WiFi", icon: Wifi },
    { id: "email", label: "Email", icon: Mail },
    { id: "phone", label: "Phone", icon: Phone },
    { id: "sms", label: "SMS", icon: MessageSquare },
  ];

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 space-y-4">
        <div>
          <Label className="text-xs font-mono uppercase tracking-wider">Type</Label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 mt-2">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={"flex flex-col items-center gap-1 p-2 rounded-sm border transition-colors " + (mode === m.id ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")}
              >
                <m.icon className="h-3.5 w-3.5" />
                <span className="font-mono text-[10px] uppercase tracking-wider">{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        {mode === "wifi" ? (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Network name (SSID)</Label>
              <input className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm" value={ssid} onChange={(e) => setSsid(e.target.value)} placeholder="MyNetwork" />
            </div>
            <div className="space-y-1.5">
              <Label>Password</Label>
              <input className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm" value={wifiPass} onChange={(e) => setWifiPass(e.target.value)} placeholder="••••••••" />
            </div>
            <div className="space-y-1.5">
              <Label>Encryption</Label>
              <select className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm" value={encryption} onChange={(e) => setEncryption(e.target.value as typeof encryption)}>
                <option value="WPA">WPA/WPA2</option>
                <option value="WEP">WEP</option>
                <option value="nopass">None (open)</option>
              </select>
            </div>
          </div>
        ) : mode === "email" || mode === "phone" || mode === "sms" ? (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>{mode === "email" ? "Email address" : "Phone number"}</Label>
              <input className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm" value={recipient} onChange={(e) => setRecipient(e.target.value)} placeholder={mode === "email" ? "you@example.com" : "+212 6 12 34 56 78"} />
            </div>
            {(mode === "sms" || mode === "email") && (
              <div className="space-y-1.5">
                <Label>{mode === "sms" ? "Message" : "Body (optional)"}</Label>
                <Textarea value={text} onChange={(e) => setText(e.target.value)} className="min-h-[100px]" placeholder="Type your message…" />
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-1.5">
            <Label>Content</Label>
            <Textarea value={text} onChange={(e) => setText(e.target.value)} className="min-h-[160px] font-mono text-[13px]" spellCheck={false} />
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Foreground</Label>
            <div className="flex gap-2">
              <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-12 rounded border border-border cursor-pointer" />
              <input className="flex-1 h-9 rounded-md border border-input bg-background px-3 text-sm font-mono" value={color} onChange={(e) => setColor(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Background</Label>
            <div className="flex gap-2">
              <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-9 w-12 rounded border border-border cursor-pointer" />
              <input className="flex-1 h-9 rounded-md border border-input bg-background px-3 text-sm font-mono" value={bg} onChange={(e) => setBg(e.target.value)} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Size: {size}px</Label>
            <input type="range" min={128} max={600} step={8} value={size} onChange={(e) => setSize(Number(e.target.value))} className="w-full accent-engineering" />
          </div>
          <div className="space-y-1.5">
            <Label>Error correction</Label>
            <select className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm" value={errorLevel} onChange={(e) => setErrorLevel(e.target.value as typeof errorLevel)}>
              <option value="L">L — 7%</option>
              <option value="M">M — 15%</option>
              <option value="Q">Q — 25%</option>
              <option value="H">H — 30%</option>
            </select>
          </div>
        </div>
      </div>

      <div className="lg:col-span-5">
        <div className="border border-border rounded-md p-5 bg-background flex flex-col items-center gap-4 sticky top-20">
          <p className="label-mono self-start">Preview</p>
          <div className="rounded-md overflow-hidden border border-border" style={{ background: bg }}>
            <img src={qrUrl} alt="QR code" width={size} height={size} style={{ display: "block" }} />
          </div>
          <code className="text-xs font-mono text-muted-foreground break-all text-center max-w-full">{payload.slice(0, 80)}{payload.length > 80 ? "…" : ""}</code>
          <Button onClick={download} disabled={downloading} className="w-full bg-engineering hover:bg-engineering/90">
            {downloading ? (
              <><Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> Downloading…</>
            ) : (
              <><Download className="mr-2 h-3.5 w-3.5" /> Download PNG</>
            )}
          </Button>
          <p className="text-[10px] text-muted-foreground text-center">
            Tip: you can also right-click the image → "Save image as…"
          </p>
          <div className="flex flex-wrap gap-1.5 justify-center">
            <TechPill>6 modes</TechPill>
            <TechPill>custom colors</TechPill>
            <TechPill>up to 600px</TechPill>
          </div>
        </div>
      </div>
    </div>
  );
}
