"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { RotateCcw, Play, ExternalLink } from "lucide-react";
import { toast } from "sonner";

const DEFAULT_HTML = `<div class="card">
  <h1>Hello, TechHub.</h1>
  <p>Edit the panels and the preview updates live.</p>
  <button onclick="ping()">Run JS</button>
</div>`;

const DEFAULT_CSS = `* { box-sizing: border-box; }
body {
  font-family: ui-sans-serif, system-ui, sans-serif;
  margin: 0;
  padding: 24px;
  background: #f8fafc;
  color: #0f172a;
}
.card {
  border: 1px solid #e2e8f0;
  background: white;
  border-radius: 8px;
  padding: 24px;
  max-width: 320px;
}
h1 { margin: 0 0 8px; font-size: 20px; }
p { margin: 0 0 16px; color: #64748b; font-size: 14px; }
button {
  background: #1f3a8a; color: white; border: none;
  padding: 8px 14px; border-radius: 6px; font-size: 13px;
  cursor: pointer;
}
button:hover { background: #1e3a8a; }`;

const DEFAULT_JS = `function ping() {
  alert("Live JavaScript from TechHub playground.");
}`;

export function CodeEditor() {
  const [html, setHtml] = React.useState(DEFAULT_HTML);
  const [css, setCss] = React.useState(DEFAULT_CSS);
  const [js, setJs] = React.useState(DEFAULT_JS);
  const [debounced, setDebounced] = React.useState({ html, css, js });
  const iframeRef = React.useRef<HTMLIFrameElement>(null);

  React.useEffect(() => {
    const t = setTimeout(() => setDebounced({ html, css, js }), 300);
    return () => clearTimeout(t);
  }, [html, css, js]);

  const srcDoc = React.useMemo(() => {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${debounced.css}</style></head><body>${debounced.html}<script>try{${debounced.js}}catch(e){console.error(e)}<\/script></body></html>`;
  }, [debounced]);

  function reset() {
    setHtml(DEFAULT_HTML); setCss(DEFAULT_CSS); setJs(DEFAULT_JS);
    toast.success("Editor reset to defaults.");
  }

  function openInNewTab() {
    const blob = new Blob([srcDoc], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="label-mono">Source · HTML / CSS / JS</p>
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" onClick={reset}>
              <RotateCcw className="h-3.5 w-3.5" />
              <span className="ml-1.5">Reset</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={openInNewTab}>
              <ExternalLink className="h-3.5 w-3.5" />
              <span className="ml-1.5">New tab</span>
            </Button>
          </div>
        </div>

        <CodePanel label="HTML" value={html} onChange={setHtml} lang="html" />
        <CodePanel label="CSS" value={css} onChange={setCss} lang="css" />
        <CodePanel label="JS" value={js} onChange={setJs} lang="javascript" />
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="label-mono">Preview · Live</p>
          <span className="font-mono text-[10px] text-muted-foreground inline-flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-engineering animate-pulse" />
            auto-refresh
          </span>
        </div>
        <div className="border border-border rounded-md overflow-hidden bg-white h-[640px]">
          <iframe
            ref={iframeRef}
            title="preview"
            srcDoc={srcDoc}
            sandbox="allow-scripts allow-modals"
            className="w-full h-full"
          />
        </div>
      </div>
    </div>
  );
}

function CodePanel({
  label, value, onChange, lang,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  lang: string;
}) {
  return (
    <div className="border border-border rounded-md overflow-hidden bg-background">
      <div className="px-3 py-1.5 border-b border-border bg-secondary/40 flex items-center justify-between">
        <span className="font-mono text-[10px] tracking-widest uppercase text-engineering">{label}</span>
        <span className="font-mono text-[10px] text-muted-foreground">{value.length} chars</span>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        spellCheck={false}
        aria-label={`${label} editor`}
        data-lang={lang}
        className="w-full h-32 p-3 font-mono text-[12.5px] leading-relaxed resize-y bg-transparent outline-none scrollbar-thin"
      />
    </div>
  );
}

void Play;
