"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Check } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import { TechPill } from "@/components/site-primitives";

const DEFAULT = `# Markdown preview

Type **markdown** on the left and see the rendered output on the right.

## Features

- Headings, **bold**, *italic*, ~~strike~~
- [Links](https://techhub-emsi.ma)
- \`inline code\` and code blocks:

\`\`\`ts
function greet(name: string) {
  return \`Hello, \${name}!\`;
}
\`\`\`

> Blockquotes are supported too.

| Tool | Status |
|------|--------|
| Binary converter | ✓ |
| Logic gates | ✓ |
| Algorithm visualizer | ✓ |

1. Ordered lists
2. Work as expected
3. Just like GitHub Flavored Markdown
`;

export function MarkdownPreviewer() {
  const [md, setMd] = React.useState(DEFAULT);
  const [copied, setCopied] = React.useState(false);

  function copy() {
    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.success("Markdown copied.");
  }

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="label-mono">Source · Markdown</p>
          <Button size="sm" variant="ghost" onClick={copy}>
            {copied ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Copy className="h-3.5 w-3.5" />}
            <span className="ml-1.5">Copy</span>
          </Button>
        </div>
        <Textarea
          value={md}
          onChange={(e) => setMd(e.target.value)}
          className="font-mono text-[13px] min-h-[500px] resize-y"
          spellCheck={false}
        />
        <p className="text-xs text-muted-foreground">{md.length} chars · {md.split("\n").length} lines</p>
      </div>
      <div className="space-y-2">
        <p className="label-mono">Preview · Rendered</p>
        <div className="border border-border rounded-md p-5 bg-background min-h-[500px] overflow-y-auto scrollbar-thin">
          <article className="prose prose-sm max-w-none text-foreground/90 [&_code]:font-mono [&_code]:text-[12.5px] [&_code]:bg-secondary [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_pre]:bg-secondary [&_pre]:p-3 [&_pre]:rounded-md [&_pre]:overflow-x-auto [&_pre]:text-[12.5px] [&_h1]:text-2xl [&_h1]:font-semibold [&_h1]:mt-4 [&_h1]:mb-2 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:mt-4 [&_h2]:mb-2 [&_h3]:text-lg [&_h3]:font-semibold [&_h3]:mt-3 [&_h3]:mb-1 [&_p]:leading-relaxed [&_p]:my-2 [&_ul]:my-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:my-2 [&_ol]:list-decimal [&_ol]:pl-5 [&_li]:leading-relaxed [&_a]:text-engineering [&_a]:underline [&_blockquote]:border-l-2 [&_blockquote]:border-engineering [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:text-muted-foreground [&_table]:w-full [&_th]:border [&_th]:border-border [&_th]:p-2 [&_th]:bg-secondary [&_td]:border [&_td]:border-border [&_td]:p-2">
            <ReactMarkdown>{md}</ReactMarkdown>
          </article>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <TechPill>GFM</TechPill>
          <TechPill>tables</TechPill>
          <TechPill>code blocks</TechPill>
        </div>
      </div>
    </div>
  );
}
