"use client";

import * as React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Copy, Check, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { BlueprintFrame } from "@/components/site-primitives";

type Base = "binary" | "decimal" | "hex" | "octal";

const BASES: { id: Base; label: string; radix: number; prefix: string }[] = [
  { id: "binary", label: "Binary", radix: 2, prefix: "0b" },
  { id: "decimal", label: "Decimal", radix: 10, prefix: "" },
  { id: "hex", label: "Hex", radix: 16, prefix: "0x" },
  { id: "octal", label: "Octal", radix: 8, prefix: "0o" },
];

export function BinaryConverter() {
  const [value, setValue] = React.useState<string>("42");
  const [base, setBase] = React.useState<Base>("decimal");
  const [copied, setCopied] = React.useState<Base | null>(null);

  // Validate the input against the chosen base
  const valid = React.useMemo(() => {
    if (!value) return false;
    const chars: Record<Base, RegExp> = {
      binary: /^[01]+$/,
      decimal: /^\d+$/,
      hex: /^[0-9a-fA-F]+$/,
      octal: /^[0-7]+$/,
    };
    return chars[base].test(value.replace(/^0[box]/i, ""));
  }, [value, base]);

  const num = React.useMemo(() => {
    if (!valid) return null;
    try {
      return BigInt(value.replace(/^0[box]/i, ""), Number(BASES.find((b) => b.id === base)!.radix));
    } catch {
      return null;
    }
  }, [value, base, valid]);

  const outputs = React.useMemo(() => {
    if (num === null) return {} as Record<Base, string>;
    return {
      binary: num.toString(2),
      decimal: num.toString(10),
      hex: num.toString(16).toUpperCase(),
      octal: num.toString(8),
    } as Record<Base, string>;
  }, [num]);

  function copy(b: Base) {
    if (!outputs[b]) return;
    navigator.clipboard.writeText(outputs[b]);
    setCopied(b);
    toast.success(`Copied ${b} value.`);
    setTimeout(() => setCopied(null), 1500);
  }

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-5 space-y-5">
        <div className="space-y-2">
          <Label className="text-xs font-mono uppercase tracking-wider">Input</Label>
          <div className="flex gap-2">
            <Input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className={`font-mono ${valid ? "" : "border-destructive"}`}
              placeholder="Enter a number…"
              aria-label="Number input"
            />
          </div>
          {!valid && (
            <p className="text-xs text-destructive font-mono">
              Invalid input for the chosen base.
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label className="text-xs font-mono uppercase tracking-wider">From base</Label>
          <div className="grid grid-cols-4 gap-1">
            {BASES.map((b) => (
              <button
                key={b.id}
                onClick={() => setBase(b.id)}
                className={
                  "font-mono text-[11px] tracking-wider uppercase px-2 py-2 rounded-sm border transition-colors " +
                  (base === b.id
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")
                }
              >
                {b.label}
              </button>
            ))}
          </div>
        </div>

        <BlueprintFrame className="border border-border rounded-md p-4 bg-secondary/30">
          <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-2">Preview</p>
          <pre className="font-mono text-[13px] text-foreground overflow-x-auto scrollbar-thin">
{num === null
  ? "// invalid input"
  : `${BASES.find((b) => b.id === base)!.prefix}${outputs[base]}`}
          </pre>
        </BlueprintFrame>
      </div>

      <div className="lg:col-span-7 space-y-3">
        <p className="label-mono">Conversions</p>
        {BASES.filter((b) => b.id !== base).map((b) => (
          <div
            key={b.id}
            className="flex items-center gap-3 p-4 border border-border rounded-md bg-background hover:border-foreground/30 transition-colors"
          >
            <div className="flex items-center gap-2 w-28 shrink-0">
              <span className="font-mono text-[11px] tracking-widest uppercase text-engineering w-16">
                {b.label}
              </span>
              <ArrowRight className="h-3 w-3 text-muted-foreground" />
            </div>
            <code className="flex-1 font-mono text-sm text-foreground overflow-x-auto scrollbar-thin whitespace-nowrap">
              {num === null ? <span className="text-muted-foreground">—</span> : outputs[b.id]}
            </code>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => copy(b.id)}
              disabled={num === null}
              className="h-8 w-8 p-0"
            >
              {copied === b.id ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
          </div>
        ))}

        <div className="border border-dashed border-border rounded-md p-4 bg-secondary/20">
          <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground mb-2">Bit pattern · 32-bit</p>
          <div className="flex flex-wrap gap-1 font-mono text-[11px]">
            {num !== null &&
              num.toString(2).padStart(32, "0").slice(-32).split("").map((bit, i) => (
                <span
                  key={i}
                  className={
                    "h-6 w-6 flex items-center justify-center rounded-sm " +
                    (bit === "1" ? "bg-engineering text-white" : "bg-secondary text-muted-foreground")
                  }
                >
                  {bit}
                </span>
              ))}
            {num === null && <span className="text-muted-foreground">—</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
