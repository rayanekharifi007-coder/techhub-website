"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Copy, Check, Plus, Trash2, Shuffle, ChevronUp, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { TechPill, BlueprintFrame } from "@/components/site-primitives";

type Stop = { color: string; position: number };

const TYPES = [
  { id: "linear", label: "Linear" },
  { id: "radial", label: "Radial" },
  { id: "conic", label: "Conic" },
] as const;

export function GradientBuilder() {
  const [type, setType] = React.useState<(typeof TYPES)[number]["id"]>("linear");
  const [angle, setAngle] = React.useState(135);
  const [stops, setStops] = React.useState<Stop[]>([
    { color: "#1f3a8a", position: 0 },
    { color: "#3730a3", position: 50 },
    { color: "#1e1b4b", position: 100 },
  ]);
  const [copied, setCopied] = React.useState(false);

  function updateStop(i: number, patch: Partial<Stop>) {
    setStops((s) => s.map((st, j) => (j === i ? { ...st, ...patch } : st)));
  }
  function addStop() {
    setStops((s) => [...s, { color: "#7c3aed", position: 50 }]);
  }
  function removeStop(i: number) {
    if (stops.length <= 2) return;
    setStops((s) => s.filter((_, j) => j !== i));
  }
  function moveStop(i: number, dir: -1 | 1) {
    setStops((s) => {
      const n = [...s];
      const j = i + dir;
      if (j < 0 || j >= n.length) return n;
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  }
  function shuffle() {
    const colors = ["#1f3a8a", "#3730a3", "#1e1b4b", "#7c3aed", "#0d4f7c", "#166534", "#7c2d12", "#92400e", "#0f766e"];
    const n = stops.length;
    setStops(Array.from({ length: n }, (_, i) => ({
      color: colors[Math.floor(Math.random() * colors.length)],
      position: Math.round((i / (n - 1)) * 100),
    })));
  }

  const css = React.useMemo(() => {
    const sorted = [...stops].sort((a, b) => a.position - b.position);
    const stopStr = sorted.map((s) => `${s.color} ${s.position}%`).join(", ");
    if (type === "linear") return `linear-gradient(${angle}deg, ${stopStr})`;
    if (type === "radial") return `radial-gradient(circle, ${stopStr})`;
    return `conic-gradient(from ${angle}deg, ${stopStr})`;
  }, [type, angle, stops]);

  function copy() {
    navigator.clipboard.writeText(`background: ${css};`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.success("CSS copied.");
  }

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 space-y-4">
        {/* Type + angle */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex gap-1">
            {TYPES.map((t) => (
              <button
                key={t.id}
                onClick={() => setType(t.id)}
                className={"font-mono text-[11px] tracking-wider uppercase px-3 py-1.5 rounded-sm border transition-colors " + (type === t.id ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")}
              >
                {t.label}
              </button>
            ))}
          </div>
          {type !== "radial" && (
            <div className="flex items-center gap-2 ml-auto">
              <Label className="text-xs font-mono uppercase tracking-wider">Angle: {angle}°</Label>
              <input type="range" min={0} max={360} value={angle} onChange={(e) => setAngle(Number(e.target.value))} className="w-32 accent-engineering" />
            </div>
          )}
          <Button size="sm" variant="outline" onClick={shuffle}>
            <Shuffle className="mr-1.5 h-3.5 w-3.5" /> Shuffle
          </Button>
        </div>

        {/* Stops editor */}
        <div className="space-y-2">
          {stops.map((s, i) => (
            <div key={i} className="flex items-center gap-2 p-2 border border-border rounded-md bg-background">
              <input type="color" value={s.color} onChange={(e) => updateStop(i, { color: e.target.value })} className="h-9 w-12 rounded border border-border cursor-pointer" />
              <Input value={s.color} onChange={(e) => updateStop(i, { color: e.target.value })} className="font-mono w-28" />
              <div className="flex-1 flex items-center gap-2">
                <input type="range" min={0} max={100} value={s.position} onChange={(e) => updateStop(i, { position: Number(e.target.value) })} className="flex-1 accent-engineering" />
                <span className="font-mono text-xs text-muted-foreground w-10 text-right">{s.position}%</span>
              </div>
              <div className="flex gap-0.5">
                <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => moveStop(i, -1)}><ChevronUp className="h-3 w-3" /></Button>
                <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => moveStop(i, 1)}><ChevronDown className="h-3 w-3" /></Button>
              </div>
              <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => removeStop(i)} disabled={stops.length <= 2}>
                <Trash2 className="h-3 w-3 text-destructive" />
              </Button>
            </div>
          ))}
          <Button size="sm" variant="outline" onClick={addStop} className="w-full">
            <Plus className="mr-1.5 h-3.5 w-3.5" /> Add color stop
          </Button>
        </div>
      </div>

      <div className="lg:col-span-5">
        <div className="sticky top-20 space-y-3">
          <p className="label-mono">Preview</p>
          <div
            className="h-56 rounded-md border border-border"
            style={{ background: css }}
          />
          <BlueprintFrame className="border border-border rounded-md p-4 bg-secondary/20">
            <div className="flex items-center justify-between mb-2">
              <p className="font-mono text-[10px] tracking-widest uppercase text-engineering">CSS</p>
              <Button size="sm" variant="ghost" onClick={copy}>
                {copied ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Copy className="h-3.5 w-3.5" />}
                <span className="ml-1.5">Copy</span>
              </Button>
            </div>
            <pre className="font-mono text-[11.5px] text-foreground overflow-x-auto scrollbar-thin whitespace-pre-wrap break-all">
{`background: ${css};`}
            </pre>
          </BlueprintFrame>
          <div className="flex flex-wrap gap-1.5">
            <TechPill>linear · radial · conic</TechPill>
            <TechPill>unlimited stops</TechPill>
          </div>
        </div>
      </div>
    </div>
  );
}
