"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Check, Clock } from "lucide-react";
import { toast } from "sonner";
import { TechPill, BlueprintFrame } from "@/components/site-primitives";

type Part = "minute" | "hour" | "day" | "month" | "weekday";

const PRESETS: { label: string; cron: string; desc: string }[] = [
  { label: "Every minute", cron: "* * * * *", desc: "Runs every single minute" },
  { label: "Every 5 minutes", cron: "*/5 * * * *", desc: "Runs every 5 minutes" },
  { label: "Every hour", cron: "0 * * * *", desc: "At minute 0 of every hour" },
  { label: "Every day at midnight", cron: "0 0 * * *", desc: "At 00:00 every day" },
  { label: "Every day at 9am", cron: "0 9 * * *", desc: "At 09:00 every day" },
  { label: "Every Monday 9am", cron: "0 9 * * 1", desc: "At 09:00 every Monday" },
  { label: "Every weekday 9am", cron: "0 9 * * 1-5", desc: "At 09:00, Monday to Friday" },
  { label: "First of month", cron: "0 0 1 * *", desc: "At 00:00 on day 1 of every month" },
  { label: "Every Sunday midnight", cron: "0 0 * * 0", desc: "At 00:00 every Sunday" },
  { label: "Every 15 minutes (biz hrs)", cron: "*/15 9-17 * * 1-5", desc: "Every 15 min, 9–17, Mon–Fri" },
];

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function CronBuilder() {
  const [parts, setParts] = React.useState<Record<Part, string>>({
    minute: "0", hour: "9", day: "*", month: "*", weekday: "*",
  });
  const [copied, setCopied] = React.useState(false);

  const cron = `${parts.minute} ${parts.hour} ${parts.day} ${parts.month} ${parts.weekday}`;

  function describe(): string {
    const m = parts.minute, h = parts.hour, d = parts.day, mo = parts.month, w = parts.weekday;
    if (m === "*" && h === "*" && d === "*" && mo === "*" && w === "*") return "Every minute.";
    const timePart = h === "*" ? "every hour" : m === "*" ? `at minute 0 past ${h}:00` : `at ${h.padStart(2, "0")}:${m.padStart(2, "0")}`;
    const dayPart = d === "*" ? "every day" : `on day ${d}`;
    const monthPart = mo === "*" ? "of every month" : MONTHS[Number(mo) - 1] ? `of ${MONTHS[Number(mo) - 1]}` : `of month ${mo}`;
    const wdPart = w === "*" ? "" : WEEKDAYS[Number(w)] ? ` on ${WEEKDAYS[Number(w)]}` : ` on weekday ${w}`;
    return `Runs ${timePart} ${dayPart} ${monthPart}${wdPart}.`;
  }

  function copy() {
    navigator.clipboard.writeText(cron);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.success("Cron expression copied.");
  }

  function applyPreset(c: string) {
    const [m, h, d, mo, w] = c.split(" ");
    setParts({ minute: m, hour: h, day: d, month: mo, weekday: w });
  }

  // Generate next 5 run times (simplified — minute-level approximation)
  function nextRuns(): Date[] {
    const runs: Date[] = [];
    const now = new Date();
    now.setSeconds(0, 0);
    // Brute-force scan next 7 days minute-by-minute (slow but works for display)
    const t = new Date(now);
    for (let i = 0; i < 10080 && runs.length < 5; i++) { // 7 days = 10080 min
      t.setMinutes(t.getMinutes() + 1);
      if (matches(t)) runs.push(new Date(t));
    }
    return runs;
  }

  function matches(d: Date): boolean {
    const m = d.getMinutes(), h = d.getHours(), day = d.getDate(), mo = d.getMonth() + 1, wd = d.getDay();
    const test = (val: number, expr: string) => {
      if (expr === "*") return true;
      if (expr.startsWith("*/")) return val % Number(expr.slice(2)) === 0;
      if (expr.includes("-")) { const [a, b] = expr.split("-").map(Number); return val >= a && val <= b; }
      if (expr.includes(",")) return expr.split(",").map(Number).includes(val);
      return Number(expr) === val;
    };
    return test(m, parts.minute) && test(h, parts.hour) && test(day, parts.day) && test(mo, parts.month) && test(wd, parts.weekday);
  }

  const runs = nextRuns();

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-5 space-y-4">
        <p className="label-mono">Presets</p>
        <div className="space-y-1.5 max-h-80 overflow-y-auto scrollbar-thin">
          {PRESETS.map((p) => (
            <button
              key={p.cron}
              onClick={() => applyPreset(p.cron)}
              className={"w-full text-left p-2.5 border rounded-md transition-colors " + (cron === p.cron ? "border-engineering bg-engineering/5" : "border-border bg-background hover:border-foreground/30")}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">{p.label}</span>
                <code className="font-mono text-[11px] text-engineering">{p.cron}</code>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{p.desc}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-7 space-y-4">
        {/* The cron expression display */}
        <BlueprintFrame className="border border-border rounded-md p-5 bg-background">
          <div className="flex items-center justify-between mb-3">
            <p className="label-mono">Expression</p>
            <Button size="sm" variant="ghost" onClick={copy}>
              {copied ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Copy className="h-3.5 w-3.5" />}
              <span className="ml-1.5">Copy</span>
            </Button>
          </div>
          <div className="grid grid-cols-5 gap-2 font-mono text-center">
            {(["minute", "hour", "day", "month", "weekday"] as Part[]).map((p, i) => (
              <div key={p}>
                <p className="text-[9px] tracking-widest uppercase text-muted-foreground mb-1">{p}</p>
                <Input
                  value={parts[p]}
                  onChange={(e) => setParts((s) => ({ ...s, [p]: e.target.value }))}
                  className="text-center font-mono text-base h-10"
                />
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-border text-center">
            <code className="text-lg font-mono text-engineering">{cron}</code>
          </div>
        </BlueprintFrame>

        <div className="border border-border rounded-md p-4 bg-secondary/20">
          <p className="text-sm text-foreground font-medium">{describe()}</p>
        </div>

        <div>
          <p className="label-mono mb-2 inline-flex items-center gap-1.5"><Clock className="h-3 w-3" /> Next 5 runs</p>
          <ul className="space-y-1.5">
            {runs.map((r, i) => (
              <li key={i} className="flex items-center gap-3 border border-border rounded-md p-2.5 bg-background text-sm">
                <span className="font-mono text-[10px] text-muted-foreground w-6">{i + 1}</span>
                <span className="text-foreground">{r.toLocaleString("en-US", { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", year: "numeric" })}</span>
                <span className="ml-auto font-mono text-[10px] text-muted-foreground">in {relativeTime(r)}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex flex-wrap gap-1.5">
          <TechPill>5-field cron</TechPill>
          <TechPill>next-run preview</TechPill>
          <TechPill>10 presets</TechPill>
        </div>
      </div>
    </div>
  );
}

function relativeTime(d: Date): string {
  const diff = d.getTime() - Date.now();
  const mins = Math.round(diff / 60000);
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ${mins % 60}m`;
  return `${Math.floor(hrs / 24)}d ${hrs % 24}h`;
}
