"use client";

import * as React from "react";
import { X, Sparkles } from "lucide-react";
import { useI18n } from "@/components/i18n-provider";

const STORAGE_KEY = "techhub-update-notice-dismissed-v1";

export function UpdateNotice() {
  const [show, setShow] = React.useState(false);
  const { t } = useI18n();

  React.useEffect(() => {
    try {
      const dismissed = localStorage.getItem(STORAGE_KEY);
      if (!dismissed) setShow(true);
    } catch {
      setShow(true);
    }
  }, []);

  function dismiss() {
    setShow(false);
    try { localStorage.setItem(STORAGE_KEY, "1"); } catch {}
  }

  if (!show) return null;

  return (
    <div className="relative z-30 border-b border-engineering/20 bg-engineering/[0.04]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 py-2">
          <span className="inline-flex items-center gap-1.5 font-mono text-[10px] tracking-widest uppercase text-engineering shrink-0">
            <Sparkles className="h-3 w-3" />
            <span className="hidden sm:inline">{t("notice.live")}</span>
            <span className="sm:hidden">{t("notice.live")}</span>
          </span>
          <p className="text-xs sm:text-[13px] text-foreground/80 flex-1 leading-relaxed">
            <span className="text-foreground font-medium">{t("notice.text").split(".")[0]}.</span>{" "}
            <span className="text-muted-foreground">{t("notice.text").split(".").slice(1).join(".").trim()}</span>
          </p>
          <button
            onClick={dismiss}
            className="shrink-0 h-6 w-6 inline-flex items-center justify-center rounded-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
            aria-label={t("notice.dismiss")}
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
