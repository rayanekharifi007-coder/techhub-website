"use client";

import * as React from "react";
import { Share2, Check } from "lucide-react";
import { toast } from "sonner";

/** Floating share button — uses Web Share API on mobile, copies URL on desktop. */
export function ShareButton() {
  const [shared, setShared] = React.useState(false);

  async function share() {
    const url = window.location.href;
    const shareData = {
      title: "TechHub EMSI Fès — Where Tech Meets Ideas",
      text: "Check out TechHub EMSI Fès — a student-run engineering laboratory.",
      url,
    };
    try {
      if (typeof navigator !== "undefined" && navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(url);
        setShared(true);
        toast.success("Link copied to clipboard.");
        setTimeout(() => setShared(false), 2000);
      }
    } catch {
      // User cancelled or share failed — silent
    }
  }

  return (
    <button
      onClick={share}
      className="fixed bottom-5 left-5 z-40 h-9 px-3 inline-flex items-center gap-2 rounded-md border border-border bg-background/80 backdrop-blur-md hover:border-foreground/40 hover:bg-background shadow-sm transition-colors group [margin-bottom:env(safe-area-inset-bottom)]"
      aria-label="Share this page"
    >
      {shared ? <Check className="h-3.5 w-3.5 text-engineering" /> : <Share2 className="h-3.5 w-3.5 text-muted-foreground group-hover:text-foreground transition-colors" />}
      <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors hidden sm:inline">
        {shared ? "Copied" : "Share"}
      </span>
    </button>
  );
}
