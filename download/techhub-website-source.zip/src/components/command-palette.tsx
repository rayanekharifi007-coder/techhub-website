"use client";

import * as React from "react";
import {
  Dialog, DialogContent, DialogTitle,
} from "@/components/ui/dialog";
import { Search, ArrowRight, Home, BookOpen, Hammer, Users, Mail, Shield, Layout, Sun, Moon, CornerDownLeft, Lightbulb, Vote } from "lucide-react";
import { DiscordIcon } from "@/components/discord-icon";
import { useRouterStore, navigate, type Route } from "@/lib/router";
import { useTheme } from "next-themes";
import { useAuth } from "@/components/auth-provider";

interface Cmd {
  id: string;
  label: string;
  hint?: string;
  icon: React.ComponentType<{ className?: string }>;
  section: "Navigation" | "Account" | "Playground" | "Actions";
  run: () => void;
  keywords?: string;
}

export function CommandPalette() {
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState("");
  const [active, setActive] = React.useState(0);
  const { route } = useRouterStore();
  const { setTheme, theme } = useTheme();
  const { session, logout } = useAuth();
  const inputRef = React.useRef<HTMLInputElement>(null);

  // ⌘K / Ctrl+K to open + G+letter navigation + T for theme
  React.useEffect(() => {
    let gPressed = false;
    let gTimer: ReturnType<typeof setTimeout> | null = null;

    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const inField = tag === "INPUT" || tag === "TEXTAREA";

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      } else if (!inField && !open && !e.metaKey && !e.ctrlKey && !e.altKey) {
        // G + letter navigation
        if (e.key.toLowerCase() === "g" && !gPressed) {
          gPressed = true;
          if (gTimer) clearTimeout(gTimer);
          gTimer = setTimeout(() => { gPressed = false; }, 800);
          return;
        }
        if (gPressed) {
          const map: Record<string, Route> = {
            h: "home", a: "about", p: "playground", f: "facts", l: "learning", d: "decisions", j: "join", c: "contact",
          };
          const r = map[e.key.toLowerCase()];
          if (r) {
            e.preventDefault();
            navigate(r);
          }
          gPressed = false;
          if (gTimer) clearTimeout(gTimer);
        }
        // T for theme toggle
        if (e.key.toLowerCase() === "t" && !gPressed) {
          e.preventDefault();
          setTheme(theme === "dark" ? "light" : "dark");
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      if (gTimer) clearTimeout(gTimer);
    };
  }, [open, theme, setTheme]);

  React.useEffect(() => {
    if (open) {
      setQ("");
      setActive(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  const go = (r: Route) => { navigate(r); setOpen(false); };

  const commands: Cmd[] = React.useMemo(() => {
    const base: Cmd[] = [
      { id: "home", label: "Home", icon: Home, section: "Navigation", run: () => go("home"), keywords: "home landing root" },
      { id: "about", label: "About TechHub", icon: BookOpen, section: "Navigation", run: () => go("about"), keywords: "about story team" },
      { id: "playground", label: "Playground", icon: Hammer, section: "Navigation", run: () => go("playground"), keywords: "playground tools binary gates algorithm code" },
      { id: "facts", label: "Facts", icon: Lightbulb, section: "Navigation", run: () => go("facts"), keywords: "facts trivia tech knowledge" },
      { id: "learning", label: "Learning Hub", icon: BookOpen, section: "Navigation", run: () => go("learning"), keywords: "learning tutorials challenges quizzes" },
      { id: "decisions", label: "Decisions", icon: Vote, section: "Navigation", run: () => go("decisions"), keywords: "decisions vote proposals workshop" },
      { id: "join", label: "Join us", icon: Users, section: "Navigation", run: () => go("join"), keywords: "join apply membership" },
      { id: "contact", label: "Contact", icon: Mail, section: "Navigation", run: () => go("contact"), keywords: "contact email message" },
      { id: "dashboard", label: "Member dashboard", icon: Layout, section: "Account", run: () => go("dashboard"), keywords: "dashboard profile projects" },
      { id: "admin", label: "Admin console", icon: Shield, section: "Account", run: () => go("admin"), keywords: "admin manage projects events" },
      { id: "discord", label: "Join our Discord", icon: DiscordIcon, section: "Actions", run: () => window.open("https://discord.gg/xyVtPuuk", "_blank"), keywords: "discord community chat" },
      { id: "theme-toggle", label: theme === "dark" ? "Switch to light mode" : "Switch to dark mode", icon: theme === "dark" ? Sun : Moon, section: "Actions", run: () => setTheme(theme === "dark" ? "light" : "dark"), keywords: "theme dark light mode toggle" },
    ];
    if (session) {
      base.push({ id: "logout", label: "Sign out", icon: ArrowRight, section: "Account", run: async () => { await logout(); navigate("home"); setOpen(false); }, keywords: "logout sign out" });
    } else {
      base.push({ id: "login", label: "Sign in", icon: ArrowRight, section: "Account", run: () => go("login"), keywords: "login sign in auth" });
    }
    return base;
  }, [route, theme, session]);

  const filtered = React.useMemo(() => {
    if (!q.trim()) return commands;
    const needle = q.toLowerCase();
    return commands.filter((c) =>
      c.label.toLowerCase().includes(needle) ||
      c.section.toLowerCase().includes(needle) ||
      (c.keywords || "").toLowerCase().includes(needle)
    );
  }, [q, commands]);

  // Group by section
  const grouped = React.useMemo(() => {
    const map = new Map<string, Cmd[]>();
    filtered.forEach((c) => {
      if (!map.has(c.section)) map.set(c.section, []);
      map.get(c.section)!.push(c);
    });
    return Array.from(map.entries());
  }, [filtered]);

  // Keyboard navigation
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!open) return;
      if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(a + 1, filtered.length - 1)); }
      else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
      else if (e.key === "Enter") { e.preventDefault(); filtered[active]?.run(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, filtered, active]);

  React.useEffect(() => { setActive(0); }, [q]);

  let flatIdx = -1;

  return (
    <>
      {/* Floating ⌘K button — bottom right */}
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-5 right-5 z-40 group inline-flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-background/80 backdrop-blur-md hover:border-foreground/40 hover:bg-background shadow-sm transition-colors [margin-bottom:env(safe-area-inset-bottom)]"
        aria-label="Open command palette"
      >
        <Search className="h-3.5 w-3.5 text-muted-foreground group-hover:text-foreground transition-colors" />
        <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors hidden sm:inline">Quick nav</span>
        <kbd className="hidden sm:inline-flex items-center gap-0.5 font-mono text-[10px] px-1.5 py-0.5 rounded border border-border bg-secondary text-muted-foreground">
          ⌘K
        </kbd>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="p-0 gap-0 overflow-hidden sm:max-w-xl top-[15%] translate-y-0" aria-describedby={undefined}>
          <DialogTitle className="sr-only">Command palette</DialogTitle>
          {/* Search input */}
          <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
            <Search className="h-4 w-4 text-muted-foreground shrink-0" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Type a command or search…"
              className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground"
            />
            <kbd className="font-mono text-[10px] px-1.5 py-0.5 rounded border border-border bg-secondary text-muted-foreground">ESC</kbd>
          </div>

          {/* Results */}
          <div className="max-h-[420px] overflow-y-auto scrollbar-thin py-2">
            {filtered.length === 0 ? (
              <div className="px-4 py-10 text-center text-sm text-muted-foreground">
                No results for "<span className="text-foreground">{q}</span>"
              </div>
            ) : (
              grouped.map(([section, items]) => (
                <div key={section} className="mb-1">
                  <p className="px-4 py-1.5 font-mono text-[10px] tracking-widest uppercase text-muted-foreground">{section}</p>
                  {items.map((c) => {
                    flatIdx++;
                    const idx = flatIdx;
                    return (
                      <button
                        key={c.id}
                        onMouseEnter={() => setActive(idx)}
                        onClick={() => c.run()}
                        className={
                          "w-full flex items-center gap-3 px-4 py-2 text-left transition-colors " +
                          (active === idx ? "bg-secondary text-foreground" : "text-foreground/80 hover:bg-secondary/50")
                        }
                      >
                        <c.icon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <span className="flex-1 text-sm">{c.label}</span>
                        {active === idx && <CornerDownLeft className="h-3 w-3 text-engineering" />}
                      </button>
                    );
                  })}
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-2 border-t border-border flex items-center justify-between text-[10px] font-mono text-muted-foreground">
            <div className="flex items-center gap-3">
              <span><kbd className="px-1 py-0.5 rounded border border-border">↑</kbd> <kbd className="px-1 py-0.5 rounded border border-border">↓</kbd> navigate</span>
              <span><kbd className="px-1 py-0.5 rounded border border-border">↵</kbd> select</span>
            </div>
            <span>TechHub · ⌘K</span>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
