"use client";

import * as React from "react";

/**
 * Cursor trail — glowing particles that follow the mouse on desktop.
 * Creates a premium, futuristic feel. Hidden on touch devices.
 */
export function CursorTrail() {
  const [particles, setParticles] = React.useState<{ x: number; y: number; id: number }[]>([]);
  const idRef = React.useRef(0);

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (!window.matchMedia("(pointer: fine)").matches) return;

    let lastTime = 0;
    const onMove = (e: MouseEvent) => {
      const now = Date.now();
      if (now - lastTime < 40) return; // Throttle to ~25fps
      lastTime = now;

      const id = idRef.current++;
      setParticles((prev) => [...prev.slice(-8), { x: e.clientX, y: e.clientY, id }]);

      // Remove particle after it fades
      setTimeout(() => {
        setParticles((prev) => prev.filter((p) => p.id !== id));
      }, 600);
    };

    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[34] hidden lg:block">
      {particles.map((p, i) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: p.x - 4,
            top: p.y - 4,
            width: 8,
            height: 8,
            background: `rgba(45, 156, 219, ${0.4 - i * 0.04})`,
            boxShadow: `0 0 ${12 - i}px rgba(45, 156, 219, ${0.3 - i * 0.03})`,
            transition: "opacity 0.6s ease-out, transform 0.6s ease-out",
            opacity: 1 - i * 0.1,
            transform: `scale(${1 - i * 0.08})`,
          }}
        />
      ))}
    </div>
  );
}
