"use client";

import * as React from "react";
import Image from "next/image";
import { WorldClock } from "@/components/world-clock";

/**
 * Engineering boot screen — 8 seconds.
 * Mobile-first design: stacks vertically on phones, 3-column on desktop.
 * Bottom: "Built by @r4yane.e" → links to Instagram.
 */
export function Splash({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = React.useState(0);
  const [fading, setFading] = React.useState(false);
  const [gone, setGone] = React.useState(false);

  React.useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const DURATION = 7800;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / DURATION);
      const eased = 1 - Math.pow(1 - t, 2);
      const pct = Math.round(eased * 100);
      setProgress(pct);
      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        window.setTimeout(() => setFading(true), 120);
        window.setTimeout(() => {
          setGone(true);
          onDone();
        }, 560);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  if (gone) return null;

  return (
    <div
      aria-hidden="true"
      className={
        "fixed inset-0 z-[100] flex flex-col bg-[var(--navy)] text-white transition-opacity duration-400 " +
        (fading ? "opacity-0 pointer-events-none" : "opacity-100")
      }
      style={{ ["--navy" as string]: "oklch(0.26 0.06 256)" }}
    >
      {/* Static gradient mesh background with neon glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-1/4 -left-1/4 w-[150%] h-[150%] opacity-30"
          style={{
            background: "conic-gradient(from 0deg at 50% 50%, rgba(45,156,219,0.15), transparent 40%, rgba(45,156,219,0.1) 60%, transparent 80%, rgba(45,156,219,0.15))",
          }}
        />
        <div
          className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full opacity-20 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(45,156,219,0.4), transparent 70%)" }}
        />
        {/* Neon corner glows */}
        <div className="absolute top-0 left-0 w-64 h-64 rounded-full opacity-15 blur-3xl" style={{ background: "radial-gradient(circle, rgba(45,156,219,0.6), transparent 70%)" }} />
        <div className="absolute bottom-0 right-0 w-64 h-64 rounded-full opacity-15 blur-3xl" style={{ background: "radial-gradient(circle, rgba(99,102,241,0.5), transparent 70%)" }} />
      </div>

      {/* Neon border frame */}
      <div className="absolute inset-2 sm:inset-4 rounded-lg pointer-events-none" style={{ border: "1px solid rgba(45,156,219,0.15)", boxShadow: "inset 0 0 60px rgba(45,156,219,0.05)" }} />

      {/* Engineering grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.15] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
          maskImage: "radial-gradient(ellipse at center, black 20%, transparent 80%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 20%, transparent 80%)",
        }}
      />

      {/* Top bar — system info + world clock */}
      <div className="relative p-4 sm:p-6 flex items-start justify-between shrink-0">
        <div className="font-mono text-[9px] sm:text-[10px] tracking-widest uppercase text-white/30">
          <p>techhub-os v1.0.0</p>
          <p className="mt-0.5 hidden sm:block">build 0x2026.10</p>
        </div>
        <WorldClock className="hidden sm:block" />
        <div className="font-mono text-[9px] sm:text-[10px] tracking-widest uppercase text-white/30 text-right">
          <p>EMSI · Fès</p>
          <p className="mt-0.5 hidden sm:block">{new Date().toISOString().slice(0, 10)}</p>
        </div>
      </div>

      {/* Main content — mobile: centered vertical, desktop: 3 columns */}
      <div className="relative flex-1 flex items-center justify-center px-4 sm:px-6 py-2">
        <div className="w-full max-w-5xl grid lg:grid-cols-12 gap-4 sm:gap-8 items-center">
          {/* Logo — centered on mobile, left on desktop */}
          <div className="lg:col-span-4 flex flex-col items-center lg:items-start gap-3 sm:gap-4 order-1">
            <div className="relative">
              {/* Glow ring behind logo */}
              <div className="absolute inset-0 rounded-2xl bg-engineering/20 blur-2xl scale-110" style={{ boxShadow: "0 0 40px rgba(45,156,219,0.3)" }} />
              <div className="relative bg-white/[0.03] rounded-2xl p-3 sm:p-4 border border-engineering/30 backdrop-blur-sm" style={{ boxShadow: "0 0 30px -5px rgba(45,156,219,0.4)" }}>
                {/* Both logos stacked */}
                <Image
                  src="/logo-transparent.png"
                  alt="TechHub EMSI Fès"
                  width={140}
                  height={79}
                  priority
                  className="h-auto w-auto"
                  style={{ width: 140, height: "auto" }}
                />
                <div className="mt-2 pt-2 border-t border-white/10">
                  <Image
                    src="/emsi-logo.png"
                    alt="EMSI — École Marocaine des Sciences de l'Ingénieur"
                    width={120}
                    height={26}
                    priority
                    className="h-auto w-auto mx-auto opacity/70"
                    style={{ width: 120, height: "auto", opacity: 0.7 }}
                  />
                </div>
              </div>
            </div>
            <div className="text-center lg:text-left">
              <p className="font-mono text-[9px] sm:text-[10px] tracking-[0.2em] uppercase text-white/50">
                Where Tech Meets Ideas
              </p>
              <p className="font-mono text-[8px] sm:text-[10px] tracking-[0.15em] uppercase text-white/30 mt-1 hidden sm:block">
                EMSI · Fès, Morocco
              </p>
            </div>
          </div>

          {/* Progress + stats — center on mobile, middle on desktop */}
          <div className="lg:col-span-4 w-full max-w-xs mx-auto order-2">
            <div className="flex items-center justify-between font-mono text-[9px] sm:text-[10px] tracking-[0.18em] uppercase text-white/50 mb-1.5">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-white/70" />
                {progress < 100 ? "INIT" : "READY"}
              </span>
              <span className="tabular-nums">{String(progress).padStart(3, "0")}%</span>
            </div>

            {/* Progress bar */}
            <div className="relative h-[3px] w-full bg-white/10 rounded-full overflow-hidden">
              <div
                className="absolute inset-y-0 left-0 rounded-full transition-[width] duration-75 ease-linear"
                style={{
                  width: `${progress}%`,
                  background: "linear-gradient(to right, rgba(45,156,219,0.6), #ffffff)",
                  boxShadow: "0 0 10px rgba(45,156,219,0.6)",
                }}
              />
            </div>

            {/* Tick marks */}
            <div className="flex justify-between mt-1">
              {Array.from({ length: 21 }).map((_, i) => (
                <span
                  key={i}
                  className={"w-px " + (i % 5 === 0 ? "h-1.5 bg-white/30" : "h-1 bg-white/15")}
                />
              ))}
            </div>

            {/* System stats — hidden on small mobile, shown on sm+ */}
            <div className="mt-4 sm:mt-6 grid grid-cols-2 gap-1.5 font-mono text-[9px] sm:text-[10px] text-white/40 hidden sm:grid">
              <div className="flex justify-between border-b border-white/10 pb-1">
                <span>CPU</span><span className="text-white/60">96°</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1">
                <span>MEM</span><span className="text-white/60">8.0 GB</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1">
                <span>NET</span><span className="text-white/60">↑ 42 mbps</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1">
                <span>DSK</span><span className="text-white/60">62%</span>
              </div>
            </div>
          </div>

          {/* Boot log — hidden on mobile, shown on desktop */}
          <div className="lg:col-span-4 w-full max-w-md mx-auto order-3 hidden lg:block">
            <p className="font-mono text-[10px] tracking-widest uppercase text-white/30 mb-2">boot log</p>
            <div className="font-mono text-[10.5px] leading-relaxed text-white/45 h-[220px] overflow-hidden bg-white/[0.02] border border-white/10 rounded-md p-3">
              <BootLog progress={progress} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom — credit + tagline. ALWAYS visible, mobile + desktop */}
      <div className="relative p-3 sm:p-6 flex items-end justify-between gap-2 shrink-0">
        {/* Left: "Built by @r4yane.e" → Instagram link */}
        <a
          href="https://instagram.com/r4yane.e"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-5 py-2 sm:py-3 rounded-md border-2 border-engineering/40 bg-engineering/[0.08] backdrop-blur-md hover:border-engineering/80 hover:bg-engineering/[0.15] transition-all group shadow-[0_0_25px_-3px_rgba(45,156,219,0.4)] hover:shadow-[0_0_35px_-2px_rgba(45,156,219,0.7)]"
        >
          {/* Instagram icon */}
          <svg className="h-4 w-4 sm:h-5 sm:w-5 text-white/60 group-hover:text-white transition-colors shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
          </svg>
          <div className="flex flex-col">
            <span className="font-mono text-[9px] sm:text-[11px] tracking-[0.12em] sm:tracking-[0.18em] uppercase text-white/45 group-hover:text-white/65 transition-colors leading-none">
              Built by
            </span>
            <span className="font-semibold text-[14px] sm:text-[18px] tracking-tight text-white/90 group-hover:text-white transition-colors leading-tight">
              @r4yane.e
            </span>
          </div>
          <svg className="h-3 sm:h-4 w-3 sm:w-4 text-white/40 group-hover:text-white/70 group-hover:translate-x-0.5 transition-all shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 17L17 7M17 7H8M17 7V16" />
          </svg>
        </a>

        {/* Right: copyright — hidden on small mobile */}
        <div className="text-right font-mono text-[9px] sm:text-[10px] tracking-widest uppercase text-white/30 hidden xs:block sm:block">
          <p>© 2026 TechHub EMSI Fès</p>
          <p className="mt-0.5 hidden sm:block">Student-run · Open source</p>
        </div>
      </div>
    </div>
  );
}

function BootLog({ progress }: { progress: number }) {
  const lines = [
    { at: 2,  text: "> booting techhub-os v1.0" },
    { at: 8,  text: "> checking memory            ✓ 8.0 GB" },
    { at: 14, text: "> mounting /playground        ✓" },
    { at: 20, text: "> mounting /learning          ✓" },
    { at: 26, text: "> mounting /dashboard         ✓" },
    { at: 32, text: "> calibrating engineering grid ✓" },
    { at: 38, text: "> warming up type checker      ✓" },
    { at: 44, text: "> loading binary converter     ✓" },
    { at: 50, text: "> loading logic gates          ✓" },
    { at: 56, text: "> loading algorithm visualizer ✓" },
    { at: 62, text: "> loading code editor          ✓" },
    { at: 68, text: "> loading color palette        ✓" },
    { at: 74, text: "> loading gradient builder     ✓" },
    { at: 80, text: "> loading markdown preview     ✓" },
    { at: 86, text: "> loading password generator   ✓" },
    { at: 92, text: "> loading QR generator         ✓" },
    { at: 96, text: "> loading cron builder         ✓" },
    { at: 99, text: "> ready." },
  ];
  return (
    <div className="space-y-0.5">
      {lines
        .filter((l) => progress >= l.at)
        .map((l, i) => (
          <p key={i} className="animate-[fadeIn_180ms_ease-out]">
            {l.text}
          </p>
        ))}
    </div>
  );
}
