"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import ReactMarkdown from "react-markdown";
import {
  BookOpen, Code2, BrainCircuit, Search, Clock, ArrowRight,
  CheckCircle2, Loader2, Trophy, PlayCircle, X,
} from "lucide-react";
import { SectionHeader, TechPill, Reveal, EmptyState, LoadingState } from "@/components/site-primitives";
import { useAuth } from "@/components/auth-provider";
import { useI18n } from "@/components/i18n-provider";
import { navigate } from "@/lib/router";
import { toast } from "sonner";

interface Tutorial {
  id: string; title: string; slug: string; summary: string; content?: string;
  category: string; difficulty: string; minutes: number; createdAt: string;
  author?: { name: string };
}
interface Challenge {
  id: string; title: string; slug: string; description: string;
  difficulty: string; category: string; createdAt: string;
  progress: { status: string; attempts: number };
  starterCode?: string; tests?: { input: unknown[]; expected: unknown }[];
  solution?: string | null;
}
interface QuizSummary { id: string; title: string; slug: string; category: string; }

const TUTORIAL_CATEGORIES = ["ALL", "FRONTEND", "BACKEND", "SYSTEMS", "AI", "TOOLS"];
const TUTORIAL_DIFFICULTIES = ["ALL", "BEGINNER", "INTERMEDIATE", "ADVANCED"];

export function LearningView() {
  const { t } = useI18n();
  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label={t("learning.label")}
            title={t("learning.title")}
            description={t("learning.desc")}
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="tutorials">
            <TabsList className="flex h-auto flex-wrap gap-1 bg-secondary/50 p-1 rounded-md">
              <TabsTrigger value="tutorials" className="gap-2"><BookOpen className="h-3.5 w-3.5" /> {t("learning.tab.tutorials")}</TabsTrigger>
              <TabsTrigger value="challenges" className="gap-2"><Code2 className="h-3.5 w-3.5" /> {t("learning.tab.challenges")}</TabsTrigger>
              <TabsTrigger value="quizzes" className="gap-2"><BrainCircuit className="h-3.5 w-3.5" /> {t("learning.tab.quizzes")}</TabsTrigger>
            </TabsList>
            <TabsContent value="tutorials" className="mt-6"><TutorialsPanel /></TabsContent>
            <TabsContent value="challenges" className="mt-6"><ChallengesPanel /></TabsContent>
            <TabsContent value="quizzes" className="mt-6"><QuizzesPanel /></TabsContent>
          </Tabs>
        </div>
      </section>
    </>
  );
}

function TutorialsPanel() {
  const [tutorials, setTutorials] = React.useState<Tutorial[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("ALL");
  const [difficulty, setDifficulty] = React.useState("ALL");
  const [selected, setSelected] = React.useState<Tutorial | null>(null);

  React.useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (category !== "ALL") params.set("category", category);
    if (difficulty !== "ALL") params.set("difficulty", difficulty);
    fetch(`/api/tutorials?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        const list = d.tutorials || [];
        const filtered = search
          ? list.filter((t: Tutorial) =>
              t.title.toLowerCase().includes(search.toLowerCase()) ||
              t.summary.toLowerCase().includes(search.toLowerCase()))
          : list;
        setTutorials(filtered);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [category, difficulty, search]);

  function open(t: Tutorial) {
    fetch(`/api/tutorials?slug=${t.slug}`)
      .then((r) => r.json())
      .then((d) => setSelected(d.tutorial))
      .catch(() => toast.error("Could not load tutorial."));
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tutorials…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <FilterChips label="Category" value={category} options={TUTORIAL_CATEGORIES} onChange={setCategory} />
          <FilterChips label="Difficulty" value={difficulty} options={TUTORIAL_DIFFICULTIES} onChange={setDifficulty} />
        </div>
      </div>

      {loading ? (
        <LoadingState rows={4} />
      ) : tutorials.length === 0 ? (
        <EmptyState
          icon={<BookOpen className="h-6 w-6" />}
          title="No tutorials match your filters."
          description="Try a different category or remove the search query."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {tutorials.map((t, i) => (
            <Reveal key={t.id} delay={(i % 6) * 50}>
              <button
                onClick={() => open(t)}
                className="group text-left w-full h-full border border-border rounded-md p-5 bg-background hover:border-foreground/30 transition-colors flex flex-col"
              >
                <div className="flex items-center justify-between">
                  <TechPill>{t.category}</TechPill>
                  <TechPill tone="engineering">{t.difficulty}</TechPill>
                </div>
                <h3 className="font-semibold text-base mt-3 group-hover:text-engineering transition-colors">{t.title}</h3>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed flex-1">{t.summary}</p>
                <div className="flex items-center justify-between mt-4 pt-3 border-t border-border text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="h-3 w-3" />
                    {t.minutes} min
                  </span>
                  {t.author && <span>{t.author.name}</span>}
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      )}

      <TutorialDialog tutorial={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function TutorialDialog({ tutorial, onClose }: { tutorial: Tutorial | null; onClose: () => void }) {
  if (!tutorial) return null;
  return (
    <Dialog open={!!tutorial} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <TechPill>{tutorial.category}</TechPill>
            <TechPill tone="engineering">{tutorial.difficulty}</TechPill>
            <TechPill>{tutorial.minutes} min</TechPill>
          </div>
          <DialogTitle className="text-2xl tracking-tight mt-2">{tutorial.title}</DialogTitle>
          <DialogDescription className="text-base text-foreground/80">{tutorial.summary}</DialogDescription>
        </DialogHeader>
        <article className="prose prose-sm max-w-none text-foreground/90 [&_code]:font-mono [&_code]:text-[12.5px] [&_code]:bg-secondary [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_pre]:bg-secondary [&_pre]:p-3 [&_pre]:rounded-md [&_pre]:overflow-x-auto [&_pre]:text-[12.5px] [&_h1]:text-xl [&_h1]:font-semibold [&_h1]:mt-4 [&_h2]:text-lg [&_h2]:font-semibold [&_h2]:mt-4 [&_p]:leading-relaxed [&_li]:leading-relaxed">
          <ReactMarkdown>{tutorial.content || ""}</ReactMarkdown>
        </article>
      </DialogContent>
    </Dialog>
  );
}

function ChallengesPanel() {
  const [challenges, setChallenges] = React.useState<Challenge[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState<Challenge | null>(null);
  const { session } = useAuth();

  React.useEffect(() => {
    fetch("/api/challenges")
      .then((r) => r.json())
      .then((d) => { setChallenges(d.challenges || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      {loading ? (
        <LoadingState rows={4} />
      ) : challenges.length === 0 ? (
        <EmptyState
          icon={<Code2 className="h-6 w-6" />}
          title="No coding challenges yet."
          description="Challenges are added by leads. Check back soon."
        />
      ) : (
        <div className="grid gap-3">
          {challenges.map((c, i) => (
            <Reveal key={c.id} delay={(i % 6) * 50}>
              <button
                onClick={() => {
                  if (!session) { toast.error("Sign in to attempt challenges."); navigate("login"); return; }
                  fetch(`/api/challenges?slug=${c.slug}`)
                    .then((r) => r.json())
                    .then((d) => setSelected(d.challenge))
                    .catch(() => toast.error("Could not load challenge."));
                }}
                className="group w-full text-left grid grid-cols-12 gap-4 items-center p-4 border border-border rounded-md bg-background hover:border-foreground/30 transition-colors"
              >
                <div className="col-span-12 sm:col-span-7 space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-base group-hover:text-engineering transition-colors">{c.title}</h3>
                    {c.progress.status === "SOLVED" && <CheckCircle2 className="h-4 w-4 text-engineering" />}
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{c.description}</p>
                </div>
                <div className="col-span-6 sm:col-span-2">
                  <TechPill tone={c.difficulty === "EASY" ? "engineering" : "default"}>{c.difficulty}</TechPill>
                </div>
                <div className="col-span-6 sm:col-span-3 text-right text-xs text-muted-foreground font-mono">
                  {c.progress.status === "SOLVED"
                    ? "solved"
                    : c.progress.attempts > 0
                      ? `${c.progress.attempts} attempt${c.progress.attempts === 1 ? "" : "s"}`
                      : "not started"}
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      )}
      <ChallengeDialog challenge={selected} onClose={() => setSelected(null)} onSolved={() => {
        // Refresh list
        fetch("/api/challenges")
          .then((r) => r.json())
          .then((d) => setChallenges(d.challenges || []));
      }} />
    </div>
  );
}

function ChallengeDialog({
  challenge, onClose, onSolved,
}: {
  challenge: Challenge | null;
  onClose: () => void;
  onSolved: () => void;
}) {
  const [code, setCode] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [result, setResult] = React.useState<{ allPass: boolean; results: { pass: boolean; got: string; expected: string }[] } | null>(null);

  React.useEffect(() => {
    setCode(challenge?.starterCode || "");
    setResult(null);
  }, [challenge?.slug]);

  if (!challenge) return null;

  async function submit() {
    if (!challenge) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/challenges", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug: challenge.slug, code }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit.");
      setResult(data);
      if (data.allPass) {
        toast.success("All tests passed.");
        onSolved();
      } else {
        toast.error(`${data.results.filter((r: { pass: boolean }) => r.pass).length}/${data.results.length} tests passed.`);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={!!challenge} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <TechPill tone="engineering">{challenge.difficulty}</TechPill>
            <TechPill>{challenge.category}</TechPill>
          </div>
          <DialogTitle className="text-2xl tracking-tight mt-2">{challenge.title}</DialogTitle>
          <DialogDescription className="text-base text-foreground/80">{challenge.description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="label-mono">Your solution · JavaScript</p>
            <Button size="sm" onClick={submit} disabled={submitting} className="bg-engineering hover:bg-engineering/90">
              {submitting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
              <span className="ml-1.5">Run tests</span>
            </Button>
          </div>
          <div className="border border-border rounded-md overflow-hidden bg-secondary/30">
            <div className="px-3 py-1.5 border-b border-border bg-secondary/50 font-mono text-[10px] tracking-widest uppercase text-muted-foreground">
              solution.js
            </div>
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              spellCheck={false}
              className="font-mono text-[13px] min-h-[260px] resize-y bg-transparent border-0 outline-none focus-visible:ring-0"
            />
          </div>

          {result && (
            <div className="border border-border rounded-md p-3 bg-background space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">Results</span>
                {result.allPass
                  ? <Badge className="bg-engineering text-white"><CheckCircle2 className="h-3 w-3 mr-1" /> All pass</Badge>
                  : <Badge variant="destructive">{result.results.filter((r) => r.pass).length}/{result.results.length}</Badge>}
              </div>
              <div className="space-y-1.5">
                {result.results.map((r, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs font-mono">
                    {r.pass
                      ? <CheckCircle2 className="h-3.5 w-3.5 text-engineering shrink-0 mt-0.5" />
                      : <X className="h-3.5 w-3.5 text-destructive shrink-0 mt-0.5" />}
                    <div className="flex-1">
                      <p className="text-foreground">expected: <span className="text-engineering">{r.expected}</span></p>
                      <p className="text-muted-foreground">got: <span className={r.pass ? "text-engineering" : "text-destructive"}>{r.got}</span></p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function QuizzesPanel() {
  const [quizzes, setQuizzes] = React.useState<QuizSummary[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState<QuizSummary | null>(null);

  React.useEffect(() => {
    fetch("/api/quizzes/list")
      .then((r) => r.json())
      .then((d) => { setQuizzes(d.quizzes || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      {loading ? (
        <LoadingState rows={3} />
      ) : quizzes.length === 0 ? (
        <EmptyState icon={<BrainCircuit className="h-6 w-6" />} title="No quizzes available yet." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {quizzes.map((q, i) => (
            <Reveal key={q.id} delay={(i % 6) * 50}>
              <button
                onClick={() => setSelected(q)}
                className="group w-full text-left border border-border rounded-md p-5 bg-background hover:border-foreground/30 transition-colors"
              >
                <TechPill>{q.category}</TechPill>
                <h3 className="font-semibold text-base mt-3 group-hover:text-engineering transition-colors">{q.title}</h3>
                <p className="text-sm text-muted-foreground mt-2">Test your knowledge — multiple choice, graded instantly.</p>
                <span className="inline-flex items-center gap-1.5 text-sm text-foreground mt-4 group-hover:text-engineering transition-colors">
                  <Trophy className="h-3.5 w-3.5" />
                  Start quiz
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      )}
      <QuizDialog quiz={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function QuizDialog({ quiz, onClose }: { quiz: QuizSummary | null; onClose: () => void }) {
  const { session } = useAuth();
  const [questions, setQuestions] = React.useState<{ id: string; prompt: string; options: string[] }[]>([]);
  const [answers, setAnswers] = React.useState<number[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [result, setResult] = React.useState<{ score: number; total: number; graded: { correct: boolean; userAnswer: number | null; correctAnswer: number }[] } | null>(null);

  React.useEffect(() => {
    if (!quiz) return;
    setLoading(true);
    setResult(null);
    setAnswers([]);
    fetch(`/api/quizzes/attempt?slug=${quiz.slug}`)
      .then((r) => r.json())
      .then((d) => {
        setQuestions(d.quiz?.questions || []);
        setAnswers(new Array(d.quiz?.questions?.length || 0).fill(null));
        setLoading(false);
      })
      .catch(() => { setLoading(false); toast.error("Could not load quiz."); });
  }, [quiz?.slug]);

  if (!quiz) return null;

  async function submit() {
    if (!quiz) return;
    if (!session) { toast.error("Sign in to submit."); navigate("login"); return; }
    setSubmitting(true);
    try {
      const res = await fetch("/api/quizzes/attempt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug: quiz.slug, answers }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit.");
      setResult(data);
      if (data.score === data.total) toast.success("Perfect score.");
      else toast.message(`You scored ${data.score}/${data.total}.`);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={!!quiz} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <TechPill>{quiz.category}</TechPill>
          <DialogTitle className="text-2xl tracking-tight mt-2">{quiz.title}</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="py-8 flex items-center justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : result ? (
          <div className="space-y-4">
            <div className="text-center py-4 border border-border rounded-md bg-secondary/30">
              <p className="font-mono text-[11px] tracking-widest uppercase text-engineering">Result</p>
              <p className="font-mono text-4xl font-semibold mt-1 text-foreground">{result.score} / {result.total}</p>
              <p className="text-sm text-muted-foreground mt-1">
                {result.score === result.total ? "Perfect — all correct." : `${Math.round((result.score / result.total) * 100)}% correct.`}
              </p>
            </div>
            <div className="space-y-3">
              {questions.map((q, i) => {
                const r = result.graded[i];
                return (
                  <div key={q.id} className="border border-border rounded-md p-3 bg-background">
                    <p className="text-sm font-medium mb-2">{i + 1}. {q.prompt}</p>
                    <div className="space-y-1.5">
                      {q.options.map((opt, j) => {
                        const isCorrect = j === r.correctAnswer;
                        const isUser = j === r.userAnswer;
                        return (
                          <div
                            key={j}
                            className={
                              "text-xs font-mono px-2 py-1.5 rounded-sm " +
                              (isCorrect
                                ? "bg-engineering/15 text-engineering"
                                : isUser
                                  ? "bg-destructive/10 text-destructive"
                                  : "text-muted-foreground")
                            }
                          >
                            {opt}
                            {isCorrect && " ✓"}
                            {isUser && !isCorrect && " ✗ (your answer)"}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <Button variant="outline" onClick={onClose} className="w-full">Close</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {questions.map((q, i) => (
              <div key={q.id} className="border border-border rounded-md p-3 bg-background">
                <p className="text-sm font-medium mb-2">{i + 1}. {q.prompt}</p>
                <div className="space-y-1.5">
                  {q.options.map((opt, j) => (
                    <button
                      key={j}
                      onClick={() => setAnswers((a) => { const n = [...a]; n[i] = j; return n; })}
                      className={
                        "block w-full text-left text-xs font-mono px-2 py-1.5 rounded-sm border transition-colors " +
                        (answers[i] === j
                          ? "bg-engineering/15 text-engineering border-engineering/40"
                          : "border-border text-muted-foreground hover:border-foreground/30")
                      }
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <Button onClick={submit} disabled={submitting || answers.some((a) => a === null)} className="w-full bg-engineering hover:bg-engineering/90">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Submit answers
            </Button>
            {answers.some((a) => a === null) && (
              <p className="text-xs text-muted-foreground text-center">Answer all questions to submit.</p>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function FilterChips({
  label, value, options, onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto scrollbar-thin">
      <span className="sr-only">{label}</span>
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(opt)}
          className={
            "font-mono text-[11px] tracking-wider uppercase px-2.5 py-1 rounded-sm border transition-colors whitespace-nowrap " +
            (value === opt
              ? "bg-foreground text-background border-foreground"
              : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")
          }
        >
          {opt === "ALL" ? "All" : opt}
        </button>
      ))}
    </div>
  );
}
