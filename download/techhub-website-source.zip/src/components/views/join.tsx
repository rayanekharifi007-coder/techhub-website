"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle2, Loader2, Sparkles, X } from "lucide-react";
import { SectionHeader, TechPill, BlueprintFrame, Reveal } from "@/components/site-primitives";
import { useI18n } from "@/components/i18n-provider";
import { toast } from "sonner";

const SPECIALTIES = [
  "Software Engineering",
  "Computer Engineering",
  "Networks & Telecom",
  "Industrial Engineering",
  "Data Science",
  "Other",
];
const YEARS = ["1st year", "2nd year", "3rd year", "4th year", "5th year", "Graduate"];
const SKILL_SUGGESTIONS = [
  "TypeScript", "React", "Node.js", "Python", "Rust", "Go", "C/C++",
  "SQL", "Docker", "Linux", "TensorFlow", "FPGA",
];

export function JoinView() {
  const { t } = useI18n();
  const [submitting, setSubmitting] = React.useState(false);
  const [submitted, setSubmitted] = React.useState(false);
  const [form, setForm] = React.useState({
    fullName: "", email: "", phone: "", specialty: "Software Engineering",
    year: "1st year", motivation: "", experience: "", portfolio: "",
  });
  const [skills, setSkills] = React.useState<string[]>([]);
  const [skillInput, setSkillInput] = React.useState("");

  function set<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  function addSkill(s: string) {
    const v = s.trim();
    if (!v) return;
    if (skills.includes(v)) return;
    setSkills((arr) => [...arr, v]);
    setSkillInput("");
  }

  function removeSkill(s: string) {
    setSkills((arr) => arr.filter((x) => x !== s));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (form.motivation.length < 40) {
      toast.error("Motivation must be at least 40 characters.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, skills }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit application.");
      setSubmitted(true);
      toast.success("Application sent to emsi.techhub@gmail.com.");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  if (submitted) {
    return (
      <section className="py-20 sm:py-28">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 text-center">
          <BlueprintFrame className="bg-background border border-border rounded-md p-10 space-y-4">
            <CheckCircle2 className="h-10 w-10 text-engineering mx-auto" />
            <p className="label-mono">{t("join.success.title")}</p>
            <h2 className="text-3xl font-semibold tracking-tight">
              {t("join.success.thanks")} {form.fullName.split(" ")[0]}.
            </h2>
            <p className="text-base text-muted-foreground leading-relaxed max-w-md mx-auto">
              {t("join.success.body")}{" "}
              <a href="mailto:emsi.techhub@gmail.com" className="text-engineering font-medium hover:underline">
                emsi.techhub@gmail.com
              </a>
              . {t("join.success.review")}{" "}
              <span className="text-foreground font-medium">{form.email}</span> {t("join.success.nextSteps")}
            </p>
            <div className="pt-4 border-t border-border space-y-2 text-xs text-muted-foreground font-mono">
              <p>{t("join.success.appId")} <span className="text-engineering">{Math.random().toString(36).slice(2, 10).toUpperCase()}</span></p>
              <p>{t("join.success.forwarded")} <span className="text-foreground">emsi.techhub@gmail.com</span></p>
              <p>{t("join.success.review2")} <span className="text-foreground">Friday EOD</span></p>
            </div>
            <Button variant="outline" className="mt-4" onClick={() => {
              setSubmitted(false);
              setForm({ fullName: "", email: "", phone: "", specialty: "Software Engineering", year: "1st year", motivation: "", experience: "", portfolio: "" });
              setSkills([]);
            }}>
              {t("join.success.another")}
            </Button>
          </BlueprintFrame>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label={t("join.label")}
            title={t("join.title")}
            description={t("join.desc")}
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-8">
          <form onSubmit={submit} className="lg:col-span-7 space-y-6">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="fullName">{t("join.form.fullName")}</Label>
                <Input id="fullName" required value={form.fullName} onChange={(e) => set("fullName", e.target.value)} placeholder="Yasmine El Idrissi" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="email">{t("join.form.email")}</Label>
                <Input id="email" type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="phone">{t("join.form.phone")}</Label>
                <Input id="phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+212 6 12 34 56 78" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="portfolio">{t("join.form.portfolio")}</Label>
                <Input id="portfolio" type="url" value={form.portfolio} onChange={(e) => set("portfolio", e.target.value)} placeholder="https://github.com/you" />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="specialty">{t("join.form.specialty")}</Label>
                <select
                  id="specialty"
                  value={form.specialty}
                  onChange={(e) => set("specialty", e.target.value)}
                  className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  {SPECIALTIES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="year">{t("join.form.year")}</Label>
                <select
                  id="year"
                  value={form.year}
                  onChange={(e) => set("year", e.target.value)}
                  className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="motivation">{t("join.form.motivation")} <span className="text-xs text-muted-foreground font-mono">({form.motivation.length}/2000, min 40)</span></Label>
              <Textarea
                id="motivation"
                required
                minLength={40}
                maxLength={2000}
                value={form.motivation}
                onChange={(e) => set("motivation", e.target.value)}
                placeholder="Why TechHub? What do you want to build, learn, or teach? Be specific."
                className="min-h-[140px]"
              />
            </div>

            <div className="space-y-1.5">
              <Label>{t("join.form.skills")}</Label>
              <div className="flex gap-2">
                <Input
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addSkill(skillInput); } }}
                  placeholder={t("join.form.skillsPlaceholder")}
                />
                <Button type="button" variant="outline" onClick={() => addSkill(skillInput)}>{t("join.form.add")}</Button>
              </div>
              {skills.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {skills.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => removeSkill(s)}
                      className="inline-flex items-center gap-1 font-mono text-[11px] tracking-wider uppercase px-2 py-1 rounded-sm border border-engineering/30 bg-engineering/5 text-engineering"
                    >
                      {s}
                      <X className="h-3 w-3" />
                    </button>
                  ))}
                </div>
              )}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {SKILL_SUGGESTIONS.filter((s) => !skills.includes(s)).slice(0, 6).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => addSkill(s)}
                    className="font-mono text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-sm border border-border text-muted-foreground hover:text-foreground hover:border-foreground/40"
                  >
                    + {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="experience">{t("join.form.experience")}</Label>
              <Textarea
                id="experience"
                value={form.experience}
                onChange={(e) => set("experience", e.target.value)}
                placeholder="Past projects, internships, hackathons, or anything else worth mentioning."
                className="min-h-[100px]"
              />
            </div>

            <div className="pt-4 border-t border-border flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                Applications are reviewed by leads every Friday.
              </p>
              <Button type="submit" disabled={submitting} className="bg-engineering hover:bg-engineering/90">
                {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
                {t("join.form.submit")}
              </Button>
            </div>
          </form>

          <aside className="lg:col-span-5 space-y-4">
            <Reveal>
              <BlueprintFrame className="bg-background border border-border rounded-md p-6 space-y-4">
                <p className="label-mono">What we look for</p>
                <ul className="space-y-3 text-sm">
                  {[
                    { k: "Curiosity.", v: "You ask why, and you go look up the answer when no one tells you." },
                    { k: "Follow-through.", v: "You finish what you start, even when the README doesn't compile." },
                    { k: "Kindness.", v: "You explain things clearly and you review pull requests with care." },
                    { k: "Engineering taste.", v: "You can tell when something is over-engineered and when it is under-specified." },
                  ].map((it) => (
                    <li key={it.k} className="flex gap-3">
                      <Sparkles className="h-3.5 w-3.5 text-engineering mt-0.5 shrink-0" />
                      <div>
                        <p className="font-medium text-foreground">{it.k}</p>
                        <p className="text-muted-foreground leading-relaxed">{it.v}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </BlueprintFrame>
            </Reveal>

            <Reveal delay={100}>
              <div className="border border-dashed border-border rounded-md p-5 bg-secondary/20 space-y-2">
                <p className="label-mono">Timeline</p>
                <div className="text-sm space-y-2">
                  <div className="flex items-baseline gap-3">
                    <span className="font-mono text-[11px] text-engineering w-20">Friday</span>
                    <span>Applications reviewed by leads.</span>
                  </div>
                  <div className="flex items-baseline gap-3">
                    <span className="font-mono text-[11px] text-engineering w-20">+3 days</span>
                    <span>Short interview (in person or remote).</span>
                  </div>
                  <div className="flex items-baseline gap-3">
                    <span className="font-mono text-[11px] text-engineering w-20">+1 week</span>
                    <span>Onboarding workshop & first project.</span>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal delay={150}>
              <div className="border border-border rounded-md p-5 bg-background">
                <p className="label-mono">FAQ</p>
                <dl className="mt-3 space-y-3 text-sm">
                  <div>
                    <dt className="font-medium text-foreground">Do I need prior experience?</dt>
                    <dd className="text-muted-foreground mt-0.5">No. We accept first-years with zero coding background. The bar is curiosity and follow-through, not skill.</dd>
                  </div>
                  <div>
                    <dt className="font-medium text-foreground">How much time does it take?</dt>
                    <dd className="text-muted-foreground mt-0.5">Expect 4–6 hours per week minimum. Members who ship spend more.</dd>
                  </div>
                  <div>
                    <dt className="font-medium text-foreground">Is there a membership fee?</dt>
                    <dd className="text-muted-foreground mt-0.5">No. The club is free for EMSI Fès students.</dd>
                  </div>
                </dl>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}
