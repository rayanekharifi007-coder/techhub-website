"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Loader2, GitBranch, CalendarDays, Trophy, BookOpen, Code2,
  Pencil, Check, X, ArrowUpRight, Activity, Clock,
} from "lucide-react";
import { SectionHeader, TechPill, EmptyState, LoadingState } from "@/components/site-primitives";
import { useAuth } from "@/components/auth-provider";
import { navigate } from "@/lib/router";
import { toast } from "sonner";

interface DashboardData {
  user: {
    id: string; name: string; email: string; role: string; bio: string | null;
    github: string | null; linkedin: string | null; specialty: string | null;
    skills: string[]; avatarUrl: string | null; graduationYear: number | null;
    createdAt: string;
  };
  projects: {
    id: string; title: string; slug: string; category: string; status: string;
    featured: boolean; githubUrl: string | null; demoUrl: string | null; createdAt: string;
  }[];
  registrations: {
    id: string; status: string; createdAt: string;
    event: { id: string; title: string; slug: string; startDate: string; endDate: string; location: string; type: string; status: string };
  }[];
  challengeProgress: {
    id: string; status: string; attempts: number;
    challenge: { id: string; title: string; slug: string; difficulty: string; category: string };
  }[];
  quizAttempts: {
    id: string; score: number; total: number; createdAt: string;
    quiz: { id: string; title: string; slug: string; category: string };
  }[];
  stats: { projects: number; eventsRegistered: number; challengesSolved: number; quizzesTaken: number; avgQuizScore: number };
}

export function DashboardView() {
  const { session, loading: authLoading } = useAuth();
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState(false);
  const [profile, setProfile] = React.useState({ bio: "", github: "", linkedin: "", specialty: "" });

  React.useEffect(() => {
    if (authLoading) return;
    if (!session) { setLoading(false); return; }
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setData(d);
        setProfile({
          bio: d.user.bio || "",
          github: d.user.github || "",
          linkedin: d.user.linkedin || "",
          specialty: d.user.specialty || "",
        });
        setLoading(false);
      })
      .catch(() => { setLoading(false); });
  }, [session, authLoading]);

  if (authLoading || loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <LoadingState rows={4} />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <EmptyState
          icon={<Activity className="h-6 w-6" />}
          title="Sign in to view your dashboard."
          description="Your projects, event registrations, learning progress, and profile live here."
          action={<Button onClick={() => navigate("login")}>Sign in</Button>}
        />
      </div>
    );
  }

  if (!data) return null;

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-between gap-6 flex-wrap">
            <div className="space-y-2">
              <p className="label-mono">Member dashboard</p>
              <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">
                {data.user.name}
              </h1>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider">
                  {data.user.role}
                </Badge>
                {data.user.specialty && <span className="text-sm text-muted-foreground">{data.user.specialty}</span>}
                <span className="text-sm text-muted-foreground font-mono">· {data.user.email}</span>
              </div>
            </div>
            {(data.user.role === "ADMIN" || data.user.role === "LEAD") && (
              <Button variant="outline" onClick={() => navigate("admin")}>
                Open admin console
                <ArrowUpRight className="ml-2 h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-6">
          {/* Stats */}
          <div className="lg:col-span-12 grid grid-cols-2 sm:grid-cols-5 gap-3">
            <StatCard icon={GitBranch} label="Projects" value={data.stats.projects} />
            <StatCard icon={CalendarDays} label="Events registered" value={data.stats.eventsRegistered} />
            <StatCard icon={Code2} label="Challenges solved" value={data.stats.challengesSolved} />
            <StatCard icon={Trophy} label="Quizzes taken" value={data.stats.quizzesTaken} />
            <StatCard icon={Activity} label="Avg. quiz score" value={`${data.stats.avgQuizScore}%`} />
          </div>

          {/* Profile */}
          <div className="lg:col-span-5 space-y-3">
            <div className="flex items-center justify-between">
              <p className="label-mono">Profile</p>
              {!editing ? (
                <Button variant="ghost" size="sm" onClick={() => setEditing(true)}>
                  <Pencil className="h-3.5 w-3.5" />
                  <span className="ml-1.5">Edit</span>
                </Button>
              ) : (
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>
                    <X className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" className="bg-engineering hover:bg-engineering/90" onClick={async () => {
                    toast.success("Profile updated locally.");
                    setEditing(false);
                  }}>
                    <Check className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )}
            </div>
            <div className="border border-border rounded-md p-5 bg-background space-y-3">
              {editing ? (
                <>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Bio</Label>
                    <Textarea value={profile.bio} onChange={(e) => setProfile((p) => ({ ...p, bio: e.target.value }))} className="min-h-[80px]" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">GitHub handle</Label>
                    <Input value={profile.github} onChange={(e) => setProfile((p) => ({ ...p, github: e.target.value }))} placeholder="username" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">LinkedIn handle</Label>
                    <Input value={profile.linkedin} onChange={(e) => setProfile((p) => ({ ...p, linkedin: e.target.value }))} placeholder="username" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Specialty</Label>
                    <Input value={profile.specialty} onChange={(e) => setProfile((p) => ({ ...p, specialty: e.target.value }))} />
                  </div>
                </>
              ) : (
                <>
                  <p className="text-sm text-foreground leading-relaxed">
                    {data.user.bio || "No bio yet. Click edit to add one."}
                  </p>
                  {data.user.skills && data.user.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {data.user.skills.map((s) => <TechPill key={s}>{s}</TechPill>)}
                    </div>
                  )}
                  <div className="pt-3 border-t border-border grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <p className="text-muted-foreground font-mono">GitHub</p>
                      <p className="text-foreground">{data.user.github || "—"}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground font-mono">LinkedIn</p>
                      <p className="text-foreground">{data.user.linkedin || "—"}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground font-mono">Member since</p>
                      <p className="text-foreground">{new Date(data.user.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })}</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Projects */}
          <div className="lg:col-span-7 space-y-3">
            <p className="label-mono">My projects · {data.projects.length}</p>
            {data.projects.length === 0 ? (
              <div className="border border-dashed border-border rounded-md p-6 text-center">
                <p className="text-sm text-muted-foreground">You haven't submitted a project yet.</p>
                <Button variant="outline" size="sm" className="mt-3" onClick={() => navigate("admin")}>
                  Submit a proposal
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {data.projects.map((p) => (
                  <div key={p.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-foreground">{p.title}</h3>
                        {p.featured && <Badge className="font-mono text-[9px] bg-engineering text-white">Featured</Badge>}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <TechPill>{p.category}</TechPill>
                        <TechPill tone="engineering">{p.status.replace("_", " ")}</TechPill>
                        <span className="text-xs text-muted-foreground font-mono">{new Date(p.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {p.githubUrl && (
                        <a href={p.githubUrl} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56v-2c-3.2.7-3.88-1.37-3.88-1.37-.53-1.34-1.3-1.7-1.3-1.7-1.06-.72.08-.71.08-.71 1.17.08 1.78 1.2 1.78 1.2 1.04 1.79 2.74 1.27 3.41.97.1-.76.41-1.27.74-1.56-2.55-.29-5.24-1.28-5.24-5.7 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.79 0c2.21-1.49 3.18-1.18 3.18-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.84 1.19 3.1 0 4.43-2.7 5.41-5.26 5.69.42.36.79 1.07.79 2.16v3.2c0 .31.21.67.8.56C20.21 21.39 23.5 17.08 23.5 12 23.5 5.65 18.35.5 12 .5z"/></svg>
                        </a>
                      )}
                      {p.demoUrl && (
                        <a href={p.demoUrl} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground">
                          <ArrowUpRight className="h-4 w-4" />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Event registrations */}
          <div className="lg:col-span-6 space-y-3">
            <p className="label-mono">My events · {data.registrations.length}</p>
            {data.registrations.length === 0 ? (
              <div className="border border-dashed border-border rounded-md p-6 text-center">
                <p className="text-sm text-muted-foreground">No event registrations yet.</p>
                <p className="text-xs text-muted-foreground mt-1">Event registrations open from the admin console when new events are scheduled.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {data.registrations.map((r) => (
                  <div key={r.id} className="border border-border rounded-md p-4 bg-background">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-medium text-foreground text-sm">{r.event.title}</h3>
                        <p className="text-xs text-muted-foreground mt-1 font-mono">
                          <Clock className="inline h-3 w-3 mr-1" />
                          {new Date(r.event.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })} · {r.event.location}
                        </p>
                      </div>
                      <TechPill tone={r.status === "WAITLIST" ? "default" : "engineering"}>{r.status}</TechPill>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Learning progress */}
          <div className="lg:col-span-6 space-y-3">
            <p className="label-mono">Learning progress</p>
            <div className="border border-border rounded-md p-5 bg-background space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="inline-flex items-center gap-2"><Code2 className="h-3.5 w-3.5 text-engineering" /> Challenges solved</span>
                  <span className="font-mono text-xs">{data.stats.challengesSolved}</span>
                </div>
                <Progress value={data.stats.challengesSolved * 25} className="h-1" />
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="inline-flex items-center gap-2"><Trophy className="h-3.5 w-3.5 text-engineering" /> Avg. quiz score</span>
                  <span className="font-mono text-xs">{data.stats.avgQuizScore}%</span>
                </div>
                <Progress value={data.stats.avgQuizScore} className="h-1" />
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="inline-flex items-center gap-2"><BookOpen className="h-3.5 w-3.5 text-engineering" /> Tutorials read</span>
                  <span className="font-mono text-xs">—</span>
                </div>
                <Progress value={0} className="h-1" />
              </div>
              <Button variant="outline" size="sm" className="w-full" onClick={() => navigate("learning")}>
                Continue learning
              </Button>
            </div>
            {data.quizAttempts.length > 0 && (
              <div className="border border-border rounded-md p-3 bg-background">
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-2">Recent quiz attempts</p>
                <ul className="space-y-1.5 text-sm">
                  {data.quizAttempts.slice(0, 3).map((a) => (
                    <li key={a.id} className="flex items-center justify-between">
                      <span className="text-foreground">{a.quiz.title}</span>
                      <span className="font-mono text-xs text-engineering">{a.score}/{a.total}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: number | string }) {
  return (
    <div className="border border-border rounded-md p-4 bg-background">
      <div className="flex items-center gap-2">
        <Icon className="h-3.5 w-3.5 text-engineering" />
        <span className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">{label}</span>
      </div>
      <p className="font-mono text-2xl font-semibold mt-2 text-foreground">{value}</p>
    </div>
  );
}

void Loader2;
