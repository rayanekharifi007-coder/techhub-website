"use client";

import * as React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Binary, Cpu, Activity, Code2, Wrench, Palette, FileText, KeyRound, QrCode, Clock, Paintbrush } from "lucide-react";
import { BinaryConverter } from "@/components/playground/binary-converter";
import { LogicGateSimulator } from "@/components/playground/logic-gates";
import { AlgorithmVisualizer } from "@/components/playground/algorithm-visualizer";
import { CodeEditor } from "@/components/playground/code-editor";
import { DevTools } from "@/components/playground/dev-tools";
import { ColorPalette } from "@/components/playground/color-palette";
import { MarkdownPreviewer } from "@/components/playground/markdown-previewer";
import { PasswordGenerator } from "@/components/playground/password-generator";
import { QrGenerator } from "@/components/playground/qr-generator";
import { CronBuilder } from "@/components/playground/cron-builder";
import { GradientBuilder } from "@/components/playground/gradient-builder";
import { useI18n } from "@/components/i18n-provider";

export function PlaygroundView() {
  const { t } = useI18n();
  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <p className="label-mono">{t("playground.label")}</p>
          <h1 className="text-3xl sm:text-5xl font-semibold tracking-tight mt-3 leading-[1.1]">
            {t("playground.title")}
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground mt-4 max-w-2xl leading-relaxed">
            {t("playground.desc")}
          </p>
        </div>
      </section>

      <section className="py-10 sm:py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="binary" className="space-y-6">
            <TabsList className="flex h-auto flex-wrap gap-2 bg-secondary/50 p-2 rounded-md">
              <TabsTrigger value="binary" className="gap-2 h-11 px-4 text-sm">
                <Binary className="h-4 w-4" />
                {t("playground.tab.binary")}
              </TabsTrigger>
              <TabsTrigger value="gates" className="gap-2 h-11 px-4 text-sm">
                <Cpu className="h-4 w-4" />
                {t("playground.tab.gates")}
              </TabsTrigger>
              <TabsTrigger value="algo" className="gap-2 h-11 px-4 text-sm">
                <Activity className="h-4 w-4" />
                {t("playground.tab.algo")}
              </TabsTrigger>
              <TabsTrigger value="code" className="gap-2 h-11 px-4 text-sm">
                <Code2 className="h-4 w-4" />
                {t("playground.tab.code")}
              </TabsTrigger>
              <TabsTrigger value="palette" className="gap-2 h-11 px-4 text-sm">
                <Palette className="h-4 w-4" />
                {t("playground.tab.palette")}
              </TabsTrigger>
              <TabsTrigger value="gradient" className="gap-2 h-11 px-4 text-sm">
                <Paintbrush className="h-4 w-4" />
                {t("playground.tab.gradient")}
              </TabsTrigger>
              <TabsTrigger value="markdown" className="gap-2 h-11 px-4 text-sm">
                <FileText className="h-4 w-4" />
                {t("playground.tab.markdown")}
              </TabsTrigger>
              <TabsTrigger value="password" className="gap-2 h-11 px-4 text-sm">
                <KeyRound className="h-4 w-4" />
                {t("playground.tab.password")}
              </TabsTrigger>
              <TabsTrigger value="qr" className="gap-2 h-11 px-4 text-sm">
                <QrCode className="h-4 w-4" />
                {t("playground.tab.qr")}
              </TabsTrigger>
              <TabsTrigger value="cron" className="gap-2 h-11 px-4 text-sm">
                <Clock className="h-4 w-4" />
                {t("playground.tab.cron")}
              </TabsTrigger>
              <TabsTrigger value="tools" className="gap-2 h-11 px-4 text-sm">
                <Wrench className="h-4 w-4" />
                {t("playground.tab.tools")}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="binary"><BinaryConverter /></TabsContent>
            <TabsContent value="gates"><LogicGateSimulator /></TabsContent>
            <TabsContent value="algo"><AlgorithmVisualizer /></TabsContent>
            <TabsContent value="code"><CodeEditor /></TabsContent>
            <TabsContent value="palette"><ColorPalette /></TabsContent>
            <TabsContent value="gradient"><GradientBuilder /></TabsContent>
            <TabsContent value="markdown"><MarkdownPreviewer /></TabsContent>
            <TabsContent value="password"><PasswordGenerator /></TabsContent>
            <TabsContent value="qr"><QrGenerator /></TabsContent>
            <TabsContent value="cron"><CronBuilder /></TabsContent>
            <TabsContent value="tools"><DevTools /></TabsContent>
          </Tabs>
        </div>
      </section>
    </>
  );
}
