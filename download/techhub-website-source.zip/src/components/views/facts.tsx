"use client";

import * as React from "react";
import { Search, Shuffle, ChevronDown, Lightbulb, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SectionHeader, TechPill, Reveal, BlueprintFrame, EmptyState } from "@/components/site-primitives";
import { useI18n } from "@/components/i18n-provider";
import { cn } from "@/lib/utils";

interface Fact {
  category: string;
  title: string;
  body: string;
  source?: string;
}

const FACTS: Fact[] = [
  // Internet
  { category: "internet", title: "The first website is still online", body: "Tim Berners-Lee's first website (info.cern.ch) went live on August 6, 1991. It's still accessible today and explains what the World Wide Web is.", source: "CERN" },
  { category: "internet", title: "There are over 5 billion internet users", body: "As of 2024, roughly 5.4 billion people — about 67% of the global population — use the internet. The first billion was reached in 2005.", source: "ITU" },
  { category: "internet", title: "An email travels through ~5–10 servers", body: "When you send an email, it typically passes through 5 to 10 different servers via SMTP before reaching the recipient's inbox, often in under a second.", source: "RFC 5321" },
  { category: "internet", title: "DNS is the phonebook of the internet", body: "The Domain Name System translates human-readable domain names (like google.com) into IP addresses (like 142.250.80.46). A single DNS lookup can involve 4+ servers.", source: "RFC 1035" },
  { category: "internet", title: "The undersea cable network spans 1.4M km", body: "Over 1.4 million kilometers of undersea fiber-optic cables carry 99% of intercontinental internet traffic. There are ~550 active cables as of 2024.", source: "TeleGeography" },

  // Programming
  { category: "programming", title: "The first programmer was a woman", body: "Ada Lovelace (1815–1852) wrote the first algorithm intended for Charles Babbage's Analytical Engine. She is widely regarded as the world's first computer programmer.", source: "Computer History Museum" },
  { category: "programming", title: "There are over 700 programming languages", body: "Wikipedia lists 700+ programming languages. In practice, ~25 are widely used, and the top 5 (JavaScript, Python, Java, C++, C#) account for the majority of code written.", source: "TIOBE Index" },
  { category: "programming", title: "The 'null' reference was a billion-dollar mistake", body: "Tony Hoare, who invented the null reference in 1965, called it his 'billion-dollar mistake' because it has caused countless bugs, crashes, and security vulnerabilities.", source: "Tony Hoare, QCon 2009" },
  { category: "programming", title: "Git was built in 10 days", body: "Linus Torvalds created the first version of Git in April 2005, reportedly in about 10 days. It was born out of a licensing dispute with BitKeeper, the VCS Linux previously used.", source: "Linus Torvalds" },
  { category: "programming", title: "The first 'Hello World' was in B (1972)", body: "The famous 'Hello, World!' program first appeared in a 1972 B-language tutorial by Brian Kernighan. It became the canonical first program for any new language.", source: "Brian Kernighan" },
  { category: "programming", title: "Python is named after Monty Python", body: "Guido van Rossum named Python after the British comedy group Monty Python, not the snake. References to spam, eggs, and knights appear throughout the documentation.", source: "Python.org" },

  // Hardware
  { category: "hardware", title: "Moore's Law is slowing", body: "Gordon Moore predicted in 1965 that transistor count would double every 2 years. This held for ~50 years but has slowed since 2015 due to physical limits at atomic scale.", source: "Intel" },
  { category: "hardware", title: "A modern CPU has billions of transistors", body: "The Apple M3 Max chip has 92 billion transistors. The first microprocessor (Intel 4004, 1971) had 2,300. That's a 40-million-fold increase.", source: "Apple / Intel" },
  { category: "hardware", title: "RAM is ~100,000× faster than disk", body: "DDR5 RAM latency is ~50 nanoseconds. NVMe SSD latency is ~100 microseconds. HDD latency is ~5 milliseconds. Your RAM is 100,000× faster than a spinning disk.", source: "JEDEC" },
  { category: "hardware", title: "The first GPU was the GeForce 256 (1999)", body: "NVIDIA coined the term 'GPU' (Graphics Processing Unit) with the GeForce 256 in 1999. It had 23 million transistors and could process 50 million polygons/sec.", source: "NVIDIA" },
  { category: "hardware", title: "Your phone has more computing power than Apollo 11", body: "The iPhone's A-series chip is ~100,000× faster than the Apollo Guidance Computer (1969), which had 4KB of RAM and ran at 0.043 MHz.", source: "Computer History Museum" },

  // Security
  { category: "security", title: "The most common password is '123456'", body: "Despite years of warnings, '123456' remains the most common password globally, appearing in 4+ million breaches. 'password' is #2.", source: "NordPass" },
  { category: "security", title: "90% of breaches start with a phishing email", body: "Phishing — tricking users into revealing credentials — is the initial access vector in ~90% of corporate data breaches. Security awareness training reduces risk by ~70%.", source: "Verizon DBIR" },
  { category: "security", title: "HTTPS doesn't mean 'trustworthy'", body: "HTTPS (TLS encryption) means the connection is encrypted — not that the site is legitimate. A phishing site can have a valid TLS certificate. Always verify the domain.", source: "Let's Encrypt" },
  { category: "security", title: "The first computer virus was 'Creeper' (1971)", body: "Creeper, created by Bob Thomas in 1971, was the first self-replicating program. It displayed 'I'm the creeper, catch me if you can!' on infected DEC PDP-10 machines.", source: "BBN Technologies" },
  { category: "security", title: "SHA-256 produces 2^256 possible hashes", body: "SHA-256 outputs 256 bits, giving 2^256 ≈ 10^77 possible hashes. That's more than the number of atoms in the observable universe (~10^80). Finding a collision is computationally infeasible.", source: "NIST" },

  // AI & ML
  { category: "ai", title: "GPT-4 has ~1.8 trillion parameters", body: "GPT-4 (2023) has an estimated 1.8 trillion parameters — 10× more than GPT-3's 175 billion. Training it cost an estimated $100M+ in compute.", source: "OpenAI / Semafor" },
  { category: "ai", title: "The first neural network was built in 1958", body: "Frank Rosenblatt built the 'Perceptron' — the first artificial neural network — in 1958 on an IBM 704. It could recognize simple patterns but was limited to linear separability.", source: "Cornell Aeronautical Lab" },
  { category: "ai", title: "AlphaGo beat the world champion in 2016", body: "DeepMind's AlphaGo defeated Lee Sedol (9-dan professional) 4–1 in March 2016. Move 37 in game 2 was described as 'not a human move' — a creative move no human would make.", source: "DeepMind" },
  { category: "ai", title: "Training a large model emits ~300 tons of CO₂", body: "Training a single large language model can emit 280+ tons of CO₂ — equivalent to 5x the lifetime emissions of an average car. Efficient architectures and green data centers matter.", source: "MIT Technology Review" },
  { category: "ai", title: "Backpropagation was described in 1986", body: "While the backpropagation algorithm was described by Rumelhart, Hinton, and Williams in 1986, it wasn't until ~2012 (AlexNet) that GPUs made it practical for deep networks.", source: "Nature" },

  // Web
  { category: "web", title: "The first browser was 'WorldWideWeb' (1990)", body: "Tim Berners-Lee wrote the first web browser in 1990 on a NeXT computer. It was later renamed Nexus to avoid confusion with the World Wide Web itself.", source: "CERN" },
  { category: "web", title: "JavaScript was created in 10 days", body: "Brendan Eich created JavaScript (originally 'Mocha') for Netscape in May 1995 in just 10 days. It was renamed to JavaScript for marketing reasons tied to Java.", source: "Brendan Eich" },
  { category: "web", title: "HTTP/3 uses UDP, not TCP", body: "HTTP/3 (2022) runs over QUIC, which is built on UDP — not TCP. This eliminates head-of-line blocking and reduces connection setup latency to a single round-trip.", source: "IETF RFC 9114" },
  { category: "web", title: "CSS has 500+ properties", body: "As of 2024, CSS has 500+ properties. The most-used are display, color, font-size, margin, and padding. The 'cascade' determines which rule wins when multiple apply.", source: "MDN Web Docs" },
  { category: "web", title: "The average web page is ~2.5 MB", body: "The median web page weighs ~2.5 MB as of 2024 — up from ~500 KB in 2010. Images account for ~50%, JavaScript ~20%, and fonts ~5% of total payload.", source: "HTTP Archive" },

  // Systems
  { category: "systems", title: "Linux runs 96% of the top 1M web servers", body: "As of 2024, Linux powers ~96% of the top 1 million web servers. The remaining 4% is mostly Windows Server. Linux also runs 100% of the top 500 supercomputers.", source: "W3Techs / Top500" },
  { category: "systems", title: "Unix time will overflow in 2038", body: "The Year 2038 problem: 32-bit Unix time (seconds since Jan 1, 1970) overflows on January 19, 2038 at 03:14:07 UTC. Most 64-bit systems are unaffected.", source: "POSIX" },
  { category: "systems", title: "Docker containers share the host kernel", body: "Unlike VMs, Docker containers don't run a full OS — they share the host's kernel and use namespaces + cgroups for isolation. This makes them ~10× lighter than VMs.", source: "Docker" },
  { category: "systems", title: "The first web server was a NeXT cube", body: "Tim Berners-Lee's first web server (1990) was a NeXTcube at CERN. It had a handwritten label on the front: 'This machine is a server. DO NOT POWER IT DOWN!!'", source: "CERN" },
  { category: "systems", title: "UTF-8 can represent 1.1M characters", body: "UTF-8 encodes all 1.1+ million Unicode code points (including emoji, CJK, and historical scripts) in 1–4 bytes. It's backwards-compatible with ASCII and used by ~98% of the web.", source: "Unicode Consortium" },

  // History
  { category: "history", title: "The first computer bug was a real moth (1947)", body: "In 1947, Grace Hopper's team found a moth trapped in a relay of the Harvard Mark II computer. They taped it in the logbook with the note: 'First actual case of bug being found.'", source: "Naval Surface Warfare Center" },
  { category: "history", title: "ENIAC weighed 27 tons", body: "ENIAC (1945), one of the first electronic general-purpose computers, weighed 27 tons, occupied 167 m², and used 17,468 vacuum tubes. It could do 5,000 additions per second.", source: "University of Pennsylvania" },
  { category: "history", title: "The first smartphone was IBM's Simon (1994)", body: "IBM's Simon Personal Communicator (1994) is considered the first smartphone. It had a touchscreen, email, calendar, and apps — 13 years before the iPhone.", source: "IBM" },
  { category: "history", title: "The 'cloud' existed since the 1960s", body: "The concept of cloud computing dates to J.C.R. Licklider's 'Intergalactic Computer Network' idea (1963). Amazon launched AWS (the first modern cloud) in 2006 with S3 and EC2.", source: "Amazon" },
  { category: "history", title: "Space Invaders caused a yen shortage (1978)", body: "When Space Invaders launched in Japan in 1978, it was so popular that the country reportedly faced a shortage of ¥100 coins. The rumor was later debunked, but the game's cultural impact was real.", source: "Taito" },

  // More Internet facts
  { category: "internet", title: "Google's original name was 'BackRub'", body: "Before it was Google, the search engine was called 'BackRub' (1996) because it analyzed backlinks. The name 'Google' is a play on 'googol' — the number 10^100.", source: "Google" },
  { category: "internet", title: "The '@' symbol was chosen for email in 1971", body: "Ray Tomlinson sent the first network email in 1971 and chose '@' to separate user from host because it was rarely used in names and made logical sense: 'user AT host'.", source: "BBN Technologies" },

  // More Programming facts
  { category: "programming", title: "The first C compiler was written in PDP-11 assembly", body: "Dennis Ritchie created C in 1972 at Bell Labs. The first C compiler was hand-written in PDP-11 assembly. Later, C became self-hosting — the compiler was rewritten in C and could compile itself.", source: "Bell Labs" },
  { category: "programming", title: "Linux kernel has 30+ million lines of code", body: "As of 2024, the Linux kernel has ~30 million lines of code. Despite this, ~90% of contributions are from developers who contribute fewer than 10 patches each.", source: "Linux Kernel Archive" },
  { category: "programming", title: "The 'Hello World' in Brainfuck is 112 chars", body: "In the esoteric language Brainfuck, 'Hello World!' requires 112 characters of only +-><[]. instructions. Example: ++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.", source: "Esolang Wiki" },

  // More Hardware facts
  { category: "hardware", title: "The first 1GB hard drive cost $40,000 (1980)", body: "IBM's 3380 disk drive (1980) was the first to hold 1GB. It weighed 500 lbs and cost ~$40,000. Today, a 1TB microSD card fits on your fingertip for ~$60.", source: "IBM" },
  { category: "hardware", title: "5G can theoretically reach 20 Gbps", body: "5G networks can theoretically reach 20 Gbps download speeds — 100× faster than 4G LTE. Real-world speeds are typically 100–400 Mbps, limited by tower density and signal.", source: "3GPP" },

  // More Security facts
  { category: "security", title: "The Morris Worm infected 6,000 computers (1988)", body: "The Morris Worm (November 1988) was the first internet worm. It infected ~6,000 UNIX computers (10% of the internet at the time) and caused $100K–$10M in damage. Its author was the first person convicted under the CFAA.", source: "Cornell University" },
  { category: "security", title: "Multifactor auth blocks 99.9% of automated attacks", body: "According to Microsoft, enabling MFA blocks 99.9% of automated account attacks. Despite this, only ~30% of internet users have MFA enabled on their accounts.", source: "Microsoft Security" },

  // More AI facts
  { category: "ai", title: "The Turing Test was proposed in 1950", body: "Alan Turing proposed the 'Imitation Game' (now the Turing Test) in 1950. A machine passes if a human can't tell if they're talking to a human or a computer. No AI has definitively passed it yet.", source: "Alan Turing, Computing Machinery and Intelligence" },
  { category: "ai", title: "A single ChatGPT query uses ~10× more power than a Google search", body: "A Google search uses ~0.3 Wh of energy. A ChatGPT query uses ~1–3 Wh — roughly 10× more. Scaling AI to billions of daily queries could significantly increase data center energy consumption.", source: "SemiAnalysis" },

  // More Web facts
  { category: "web", title: "React was open-sourced in 2013", body: "Facebook (Meta) released React as open source in May 2013. By 2024, it powers ~40% of the top 10,000 websites. The first commit was by Jordan Walke in 2011.", source: "Meta Open Source" },
  { category: "web", title: "The first domain name was symbolics.com (1985)", body: "symbolics.com was registered on March 15, 1985 — the first-ever .com domain. The company (Symbolics Computer Corporation) no longer exists, but the domain is still active.", source: "Verisign" },

  // More Systems facts
  { category: "systems", title: "Kubernetes means 'helmsman' in Greek", body: "Kubernetes (K8s) was open-sourced by Google in 2014. The name means 'helmsman' or 'pilot' in Greek — it steers the ship of containers. The logo is a ship's wheel.", source: "Google Cloud" },
  { category: "systems", title: "The first ARPANET message was 'lo' (1969)", body: "On October 29, 1969, the first ARPANET message was sent from UCLA to Stanford. The intended message was 'LOGIN' but the system crashed after two characters, so the first message was literally 'lo'.", source: "UCLA" },

  // More History facts
  { category: "history", title: "The QWERTY layout was designed to prevent jams (1873)", body: "The QWERTY keyboard layout (1873) was designed to slow typists down — common letter pairs were separated to prevent mechanical typewriter arms from jamming. We still use it today despite better alternatives like Dvorak.", source: "Smithsonian" },
  { category: "history", title: "WiFi was invented by an actress (1942 patent)", body: "Hedy Lamarr, a Hollywood actress, co-invented frequency-hopping spread spectrum in 1941 — the foundation of modern WiFi, Bluetooth, and GPS. She received no credit until 1997.", source: "US Patent 2,292,387" },

  // Additional facts — batch 2
  { category: "programming", title: "The '404' error code is not named after a room", body: "Contrary to popular myth, HTTP 404 was not named after 'Room 404' at CERN. It's simply the 4th error code in the 4xx (client error) series. The room 404 story is an urban legend.", source: "W3C" },
  { category: "programming", title: "You can write a 'Hello World' in 1 line of Brainf*ck", body: "Brainf*ck is an esoteric language with only 8 commands (> < + - . , [ ]). A 'Hello World' takes 100+ characters. It was created by Urban Müller in 1993 to be the smallest possible compiler.", source: "Esolang Wiki" },
  { category: "programming", title: "The semicolon is optional in Go", body: "In Go, semicolons at the end of statements are automatically inserted by the lexer. You almost never write them manually. This was inspired by the semicolon-insertion rules of JavaScript.", source: "Go Spec" },
  { category: "hardware", title: "SSDs have a limited number of write cycles", body: "Each NAND flash cell in an SSD can be written ~1,000–100,000 times before wearing out. Wear leveling and TRIM distribute writes evenly. Modern SSDs last 5–10+ years under normal use.", source: "JEDEC" },
  { category: "hardware", title: "USB-C can carry 240W of power", body: "USB Power Delivery 3.1 (2021) supports up to 48V at 5A = 240W. That's enough to charge a gaming laptop, a monitor, or even a small TV — all through a single USB-C cable.", source: "USB-IF" },
  { category: "security", title: "A 12-character password takes 226 years to crack", body: "A 12-character password with uppercase, lowercase, numbers, and symbols has ~74^12 ≈ 10^22 combinations. At 10 billion guesses/sec, brute-forcing takes ~226 years. Length matters more than complexity.", source: "NIST SP 800-63" },
  { category: "security", title: "2FA stops 99.9% of automated attacks", body: "According to Microsoft, multi-factor authentication blocks over 99.9% of automated account compromise attacks. Despite this, only ~20% of users enable it. Turn it on everywhere.", source: "Microsoft Security" },
  { category: "ai", title: "ChatGPT reached 100M users in 2 months", body: "ChatGPT (launched Nov 30, 2022) reached 100 million users in January 2023 — the fastest-growing consumer app in history. For comparison, TikTok took 9 months, Instagram took 2.5 years.", source: "UBS / SimilarWeb" },
  { category: "web", title: "The <blink> tag was invented after a beer", body: "In 1994, a Netscape engineer named Lou Montulli was at a bar with colleagues. Someone mentioned text blinking. He coded <blink> that night. It became one of the most hated HTML tags ever.", source: "Lou Montulli" },
  { category: "web", title: "Cookies were invented in 1994 for shopping carts", body: "Lou Montulli invented web cookies in 1994 to solve the 'shopping cart' problem — HTTP is stateless, so there was no way to remember what a user added to their cart between page loads.", source: "Netscape" },
  { category: "systems", title: "The first domain name was symbolics.com (1985)", body: "symbolics.com was registered on March 15, 1985 — the first ever .com domain. Symbolics was a computer company that made Lisp machines. The domain still exists today.", source: "Verisign" },
  { category: "history", title: "The first 1GB hard drive cost $40,000 (1980)", body: "In 1980, IBM released the first 1GB hard drive — the 3380. It weighed 500 pounds, was the size of a refrigerator, and cost $40,000–$143,000. Today, 1GB of flash storage costs less than $0.05.", source: "IBM" },
  { category: "history", title: "Apple's first logo showed Isaac Newton (1976)", body: "Apple's first logo (1976) depicted Isaac Newton sitting under an apple tree with a quote from Wordsworth. It was replaced by the famous bitten-apple silhouette in 1977, designed by Rob Janoff.", source: "Apple" },
];

const CATEGORY_ICONS: Record<string, string> = {
  internet: "🌐",
  programming: "💻",
  hardware: "🔧",
  security: "🔒",
  ai: "🤖",
  web: "🌍",
  systems: "⚙️",
  history: "📚",
};

export function FactsView() {
  const { t } = useI18n();
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("ALL");
  const [expanded, setExpanded] = React.useState<string | null>(null);
  const [randomFact, setRandomFact] = React.useState<Fact | null>(null);

  const categories = ["ALL", "internet", "programming", "hardware", "security", "ai", "web", "systems", "history"];

  const filtered = React.useMemo(() => {
    return FACTS.filter((f) => {
      if (category !== "ALL" && f.category !== category) return false;
      if (search) {
        const q = search.toLowerCase();
        return f.title.toLowerCase().includes(q) || f.body.toLowerCase().includes(q);
      }
      return true;
    });
  }, [search, category]);

  // Track fact views for achievements
  React.useEffect(() => {
    window.dispatchEvent(new CustomEvent("techhub-achievement", {
      detail: { factsViewed: filtered.length },
    }));
  }, [filtered.length]);

  function shuffle() {
    const random = FACTS[Math.floor(Math.random() * FACTS.length)];
    setRandomFact(random);
  }

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label={t("facts.label")}
            title={t("facts.title")}
            description={t("facts.desc")}
          />
          <div className="mt-6 flex flex-wrap gap-2 items-center">
            <Button onClick={shuffle} variant="outline" size="sm" className="gap-2">
              <Shuffle className="h-3.5 w-3.5" />
              {t("facts.shuffle")}
            </Button>
            <span className="text-xs text-muted-foreground font-mono">
              {FACTS.length} {t("facts.factsCount")} · {filtered.length} {t("facts.factsCount")}
            </span>
          </div>
        </div>
      </section>

      {/* Random fact modal */}
      {randomFact && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setRandomFact(null)}
        >
          <BlueprintFrame
            className="relative bg-background border border-border rounded-lg p-8 max-w-lg w-full space-y-4"
            onClick={(e: React.MouseEvent) => e.stopPropagation()}
          >
            <button
              onClick={() => setRandomFact(null)}
              className="absolute top-3 right-3 h-8 w-8 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-3xl">{CATEGORY_ICONS[randomFact.category]}</span>
              <p className="label-mono">{t("facts.didYouKnow")}</p>
            </div>
            <h3 className="text-xl font-semibold tracking-tight">{randomFact.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{randomFact.body}</p>
            {randomFact.source && (
              <p className="text-xs text-muted-foreground font-mono pt-2 border-t border-border">
                {t("facts.category")}: {t(`facts.categories.${randomFact.category}`)} · {randomFact.source}
              </p>
            )}
            <Button onClick={shuffle} variant="outline" size="sm" className="w-full gap-2">
              <Shuffle className="h-3.5 w-3.5" />
              {t("facts.shuffle")}
            </Button>
          </BlueprintFrame>
        </div>
      )}

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Search + filters */}
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("facts.search")}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 pr-9"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={cn(
                    "font-mono text-[11px] tracking-wider uppercase px-2.5 py-1.5 rounded-sm border transition-colors whitespace-nowrap inline-flex items-center gap-1.5",
                    category === c
                      ? "bg-foreground text-background border-foreground"
                      : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40"
                  )}
                >
                  {c !== "ALL" && <span>{CATEGORY_ICONS[c]}</span>}
                  {c === "ALL" ? t("facts.all") : t(`facts.categories.${c}`)}
                </button>
              ))}
            </div>
          </div>

          {/* Facts grid */}
          {filtered.length === 0 ? (
            <EmptyState
              icon={<Lightbulb className="h-6 w-6" />}
              title={t("facts.noResults")}
            />
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((f, i) => {
                const id = `${f.category}-${f.title}`;
                const isExpanded = expanded === id;
                return (
                  <Reveal key={id} delay={(i % 6) * 40}>
                    <button
                      onClick={() => setExpanded(isExpanded ? null : id)}
                      className="group text-left w-full h-full p-5 rounded-md border border-border bg-background hover:border-foreground/30 transition-colors"
                    >
                      <div className="flex items-start gap-3 mb-3">
                        <span className="text-2xl shrink-0">{CATEGORY_ICONS[f.category]}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <TechPill className="text-[9px]">{t(`facts.categories.${f.category}`)}</TechPill>
                          </div>
                          <h3 className="font-semibold text-sm leading-tight group-hover:text-engineering transition-colors">
                            {f.title}
                          </h3>
                        </div>
                        <ChevronDown className={cn("h-4 w-4 text-muted-foreground shrink-0 transition-transform", isExpanded && "rotate-180")} />
                      </div>
                      <p className={cn(
                        "text-xs text-muted-foreground leading-relaxed overflow-hidden transition-all",
                        isExpanded ? "max-h-96" : "max-h-12 line-clamp-2"
                      )}>
                        {f.body}
                      </p>
                      {isExpanded && f.source && (
                        <p className="text-[10px] text-muted-foreground font-mono mt-3 pt-2 border-t border-border">
                          {f.source}
                        </p>
                      )}
                    </button>
                  </Reveal>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
