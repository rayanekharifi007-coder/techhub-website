"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Plus, Pencil, Trash2, Check, X, Loader2, ShieldCheck, AlertCircle,
  GitBranch, CalendarDays, Users, FileText, Megaphone, Code2, BrainCircuit, Inbox, Mail,
} from "lucide-react";
import { TechPill, EmptyState, LoadingState } from "@/components/site-primitives";
import { useAuth } from "@/components/auth-provider";
import { navigate } from "@/lib/router";
import { toast } from "sonner";

export function AdminView() {
  const { session, loading } = useAuth();
  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <LoadingState rows={4} />
      </div>
    );
  }
  if (!session) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <EmptyState
          icon={<AlertCircle className="h-6 w-6" />}
          title="Sign in to access the admin console."
          action={<Button onClick={() => navigate("login")}>Sign in</Button>}
        />
      </div>
    );
  }
  if (session.role !== "ADMIN" && session.role !== "LEAD") {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <EmptyState
          icon={<ShieldCheck className="h-6 w-6" />}
          title="Admin access required."
          description="Your account does not have permission to view this page. Contact an administrator if you believe this is an error."
          action={<Button onClick={() => navigate("dashboard")}>Back to dashboard</Button>}
        />
      </div>
    );
  }

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="h-4 w-4 text-engineering" />
            <p className="label-mono">Admin console · {session.role}</p>
          </div>
          <h1 className="text-3xl font-semibold tracking-tight">Operations dashboard</h1>
          <p className="text-base text-muted-foreground mt-2">
            Manage projects, events, members, applications, tutorials, challenges, quizzes, and announcements.
          </p>
        </div>
      </section>

      <section className="py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="applications">
            <TabsList className="flex h-auto flex-wrap gap-1 bg-secondary/50 p-1 rounded-md">
              <TabsTrigger value="applications" className="gap-2"><Inbox className="h-3.5 w-3.5" /> Applications</TabsTrigger>
              <TabsTrigger value="messages" className="gap-2"><Mail className="h-3.5 w-3.5" /> Messages</TabsTrigger>
              <TabsTrigger value="projects" className="gap-2"><GitBranch className="h-3.5 w-3.5" /> Projects</TabsTrigger>
              <TabsTrigger value="events" className="gap-2"><CalendarDays className="h-3.5 w-3.5" /> Events</TabsTrigger>
              {session.role === "ADMIN" && (
                <TabsTrigger value="members" className="gap-2"><Users className="h-3.5 w-3.5" /> Members</TabsTrigger>
              )}
              <TabsTrigger value="tutorials" className="gap-2"><FileText className="h-3.5 w-3.5" /> Tutorials</TabsTrigger>
              <TabsTrigger value="challenges" className="gap-2"><Code2 className="h-3.5 w-3.5" /> Challenges</TabsTrigger>
              <TabsTrigger value="quizzes" className="gap-2"><BrainCircuit className="h-3.5 w-3.5" /> Quizzes</TabsTrigger>
              <TabsTrigger value="announcements" className="gap-2"><Megaphone className="h-3.5 w-3.5" /> Announcements</TabsTrigger>
            </TabsList>

            <TabsContent value="applications" className="mt-6"><ApplicationsPanel /></TabsContent>
            <TabsContent value="messages" className="mt-6"><MessagesPanel /></TabsContent>
            <TabsContent value="projects" className="mt-6"><ProjectsPanel /></TabsContent>
            <TabsContent value="events" className="mt-6"><EventsPanel /></TabsContent>
            {session.role === "ADMIN" && (
              <TabsContent value="members" className="mt-6"><MembersPanel /></TabsContent>
            )}
            <TabsContent value="tutorials" className="mt-6"><TutorialsPanel /></TabsContent>
            <TabsContent value="challenges" className="mt-6"><ChallengesPanel /></TabsContent>
            <TabsContent value="quizzes" className="mt-6"><QuizzesPanel /></TabsContent>
            <TabsContent value="announcements" className="mt-6"><AnnouncementsPanel /></TabsContent>
          </Tabs>
        </div>
      </section>
    </>
  );
}

/* ===== Applications ===== */
interface Application {
  id: string; fullName: string; email: string; phone: string | null;
  specialty: string; year: string; motivation: string; skills: string[];
  experience: string | null; portfolio: string | null;
  status: string; note: string | null; reviewer?: { name: string } | null;
  createdAt: string;
}

function ApplicationsPanel() {
  const [apps, setApps] = React.useState<Application[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState<Application | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/applications")
      .then((r) => r.json())
      .then((d) => { setApps(d.applications || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function decide(id: string, status: "APPROVED" | "REJECTED", note?: string) {
    try {
      const res = await fetch(`/api/admin/applications/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, note: note || "" }),
      });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success(`Application ${status.toLowerCase()}.`);
      setSelected(null);
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  if (loading) return <LoadingState rows={4} />;
  return (
    <div className="space-y-3">
      {apps.length === 0 ? (
        <EmptyState icon={<Inbox className="h-6 w-6" />} title="No applications yet." />
      ) : apps.map((a) => (
        <div key={a.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-foreground">{a.fullName}</h3>
              <TechPill>{a.specialty}</TechPill>
              <TechPill>{a.year}</TechPill>
              <TechPill tone={a.status === "PENDING" ? "default" : a.status === "APPROVED" ? "engineering" : "default"}>
                {a.status}
              </TechPill>
            </div>
            <p className="text-xs text-muted-foreground mt-1 font-mono">{a.email} · {new Date(a.createdAt).toLocaleDateString()}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => setSelected(a)}>Review</Button>
        </div>
      ))}

      <Dialog open={!!selected} onOpenChange={(o) => { if (!o) setSelected(null); }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selected.fullName}</DialogTitle>
                <DialogDescription>
                  {selected.email} · {selected.specialty} · {selected.year}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <div>
                  <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-1">Motivation</p>
                  <p className="text-foreground leading-relaxed">{selected.motivation}</p>
                </div>
                {selected.experience && (
                  <div>
                    <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-1">Experience</p>
                    <p className="text-foreground leading-relaxed">{selected.experience}</p>
                  </div>
                )}
                {selected.skills.length > 0 && (
                  <div>
                    <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-1">Skills</p>
                    <div className="flex flex-wrap gap-1.5">
                      {selected.skills.map((s) => <TechPill key={s}>{s}</TechPill>)}
                    </div>
                  </div>
                )}
                {selected.portfolio && (
                  <div>
                    <p className="font-mono text-[10px] tracking-widest uppercase text-engineering mb-1">Portfolio</p>
                    <a href={selected.portfolio} target="_blank" rel="noopener noreferrer" className="text-engineering hover:underline">{selected.portfolio}</a>
                  </div>
                )}
                {selected.reviewer && (
                  <p className="text-xs text-muted-foreground font-mono pt-2 border-t border-border">
                    Last reviewed by {selected.reviewer.name} · status: {selected.status}
                  </p>
                )}
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => decide(selected.id, "REJECTED")}>
                  <X className="mr-2 h-3.5 w-3.5" /> Reject
                </Button>
                <Button className="bg-engineering hover:bg-engineering/90" onClick={() => decide(selected.id, "APPROVED")}>
                  <Check className="mr-2 h-3.5 w-3.5" /> Approve
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ===== Messages (contact form inbox) ===== */
interface ContactMessage {
  id: string; name: string; email: string; subject: string;
  body: string; handled: boolean; createdAt: string;
}

function MessagesPanel() {
  const [items, setItems] = React.useState<ContactMessage[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState<ContactMessage | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/messages")
      .then((r) => r.json())
      .then((d) => { setItems(d.messages || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function markHandled(id: string) {
    const res = await fetch(`/api/admin/messages/${id}`, { method: "PUT" });
    if (res.ok) { toast.success("Marked as handled."); setSelected(null); load(); } else toast.error("Failed.");
  }
  async function remove(id: string) {
    if (!confirm("Delete this message?")) return;
    const res = await fetch(`/api/admin/messages/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted."); setSelected(null); load(); } else toast.error("Failed.");
  }

  if (loading) return <LoadingState rows={4} />;
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">{items.length} message{items.length === 1 ? "" : "s"} · forwarded to emsi.techhub@gmail.com</p>
      {items.length === 0 ? (
        <EmptyState icon={<Mail className="h-6 w-6" />} title="No messages yet." description="Contact form submissions will appear here, and are also forwarded to emsi.techhub@gmail.com." />
      ) : items.map((m) => (
        <div key={m.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-foreground">{m.subject}</h3>
              {!m.handled && <Badge className="font-mono text-[9px] bg-engineering text-white">NEW</Badge>}
            </div>
            <p className="text-xs text-muted-foreground mt-1 font-mono">{m.name} · {m.email} · {new Date(m.createdAt).toLocaleString()}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => setSelected(m)}>Read</Button>
        </div>
      ))}

      <Dialog open={!!selected} onOpenChange={(o) => { if (!o) setSelected(null); }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selected.subject}</DialogTitle>
                <DialogDescription>
                  From <span className="text-foreground font-medium">{selected.name}</span> &lt;<a href={`mailto:${selected.email}`} className="text-engineering hover:underline">{selected.email}</a>&gt;
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground font-mono">{new Date(selected.createdAt).toLocaleString()}</p>
                <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap border border-border rounded-md p-4 bg-secondary/30">{selected.body}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Mail className="h-3.5 w-3.5" />
                  Forwarded to <span className="text-foreground font-mono">emsi.techhub@gmail.com</span>
                </div>
              </div>
              <DialogFooter className="gap-2">
                <Button asChild variant="outline">
                  <a href={`mailto:${selected.email}?subject=Re: ${encodeURIComponent(selected.subject)}`}>Reply by email</a>
                </Button>
                <Button variant="ghost" onClick={() => remove(selected.id)}>
                  <Trash2 className="mr-2 h-3.5 w-3.5 text-destructive" /> Delete
                </Button>
                {!selected.handled && (
                  <Button className="bg-engineering hover:bg-engineering/90" onClick={() => markHandled(selected.id)}>
                    <Check className="mr-2 h-3.5 w-3.5" /> Mark as handled
                  </Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ===== Projects ===== */
interface Project {
  id: string; title: string; slug: string; summary: string; description: string;
  category: string; techStack: string[]; githubUrl: string | null; demoUrl: string | null;
  status: string; featured: boolean; contributors: string[]; coverColor: string | null;
  author?: { name: string };
}

function ProjectsPanel() {
  const [items, setItems] = React.useState<Project[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState<Project | "new" | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/projects")
      .then((r) => r.json())
      .then((d) => { setItems(d.projects || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function remove(id: string) {
    if (!confirm("Delete this project? This cannot be undone.")) return;
    const res = await fetch(`/api/admin/projects/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted."); load(); } else toast.error("Failed.");
  }

  if (loading) return <LoadingState rows={4} />;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} project{items.length === 1 ? "" : "s"}</p>
        <Button size="sm" onClick={() => setEditing("new")}><Plus className="mr-1.5 h-3.5 w-3.5" /> New project</Button>
      </div>
      {items.map((p) => (
        <div key={p.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-foreground">{p.title}</h3>
              <TechPill>{p.category}</TechPill>
              <TechPill tone="engineering">{p.status.replace("_", " ")}</TechPill>
              {p.featured && <Badge className="font-mono text-[9px] bg-engineering text-white">Featured</Badge>}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{p.summary}</p>
            <p className="text-xs text-muted-foreground mt-1 font-mono">by {p.author?.name}</p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={() => setEditing(p)}><Pencil className="h-3.5 w-3.5" /></Button>
            <Button variant="ghost" size="sm" onClick={() => remove(p.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
          </div>
        </div>
      ))}
      <ProjectEditor project={editing} onClose={() => setEditing(null)} onSaved={load} />
    </div>
  );
}

function ProjectEditor({ project, onClose, onSaved }: { project: Project | "new" | null; onClose: () => void; onSaved: () => void }) {
  const isNew = project === "new";
  const [form, setForm] = React.useState<Partial<Project>>({});
  const [techInput, setTechInput] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (!project) return;
    if (isNew) {
      setForm({ title: "", slug: "", summary: "", description: "", category: "WEB", techStack: [], githubUrl: "", demoUrl: "", status: "IN_PROGRESS", featured: false, contributors: [], coverColor: "#1f3a8a" });
    } else {
      setForm(project);
    }
    setTechInput("");
  }, [project, isNew]);

  if (!project) return null;

  async function save() {
    setSaving(true);
    try {
      const body = { ...form, techStack: form.techStack || [] };
      const res = isNew
        ? await fetch("/api/admin/projects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
        : await fetch(`/api/admin/projects/${form.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success(isNew ? "Project created." : "Project updated.");
      onClose();
      onSaved();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!project} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <DialogTitle>{isNew ? "New project" : "Edit project"}</DialogTitle>
        </DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Title"><Input value={form.title || ""} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></Field>
          <Field label="Slug (optional)"><Input value={form.slug || ""} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} placeholder="auto-generated" /></Field>
          <Field label="Category">
            <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["WEB", "AI", "SYSTEMS", "HARDWARE", "MOBILE", "TOOLING"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Status">
            <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["SHIPPED", "IN_PROGRESS", "CONCEPT"].map((c) => <SelectItem key={c} value={c}>{c.replace("_", " ")}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
        </div>
        <Field label="Summary"><Input value={form.summary || ""} onChange={(e) => setForm((f) => ({ ...f, summary: e.target.value }))} /></Field>
        <Field label="Description"><Textarea value={form.description || ""} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className="min-h-[100px]" /></Field>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="GitHub URL"><Input value={form.githubUrl || ""} onChange={(e) => setForm((f) => ({ ...f, githubUrl: e.target.value }))} /></Field>
          <Field label="Demo URL"><Input value={form.demoUrl || ""} onChange={(e) => setForm((f) => ({ ...f, demoUrl: e.target.value }))} /></Field>
        </div>
        <Field label="Cover color">
          <div className="flex items-center gap-2">
            <Input value={form.coverColor || ""} onChange={(e) => setForm((f) => ({ ...f, coverColor: e.target.value }))} className="font-mono" />
            <div className="h-8 w-8 rounded border border-border" style={{ background: form.coverColor || "#1f3a8a" }} />
          </div>
        </Field>
        <Field label="Tech stack">
          <div className="flex gap-2">
            <Input value={techInput} onChange={(e) => setTechInput(e.target.value)} onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                if (techInput && !(form.techStack || []).includes(techInput)) {
                  setForm((f) => ({ ...f, techStack: [...(f.techStack || []), techInput] }));
                  setTechInput("");
                }
              }
            }} placeholder="Type and press Enter" />
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {(form.techStack || []).map((t) => (
              <button key={t} type="button" onClick={() => setForm((f) => ({ ...f, techStack: (f.techStack || []).filter((x) => x !== t) }))} className="font-mono text-[11px] uppercase tracking-wider px-2 py-0.5 rounded-sm border border-engineering/30 bg-engineering/5 text-engineering inline-flex items-center gap-1">
                {t}<X className="h-3 w-3" />
              </button>
            ))}
          </div>
        </Field>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input type="checkbox" checked={!!form.featured} onChange={(e) => setForm((f) => ({ ...f, featured: e.target.checked }))} className="accent-engineering" />
          Featured project
        </label>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving} className="bg-engineering hover:bg-engineering/90">
            {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
            {isNew ? "Create" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ===== Events ===== */
interface EventItem {
  id: string; title: string; slug: string; description: string; type: string;
  startDate: string; endDate: string; location: string; capacity: number;
  status: string; schedule: { time: string; title: string; speaker: string }[];
  registered: number; coverColor: string | null;
}

function EventsPanel() {
  const [items, setItems] = React.useState<EventItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState<EventItem | "new" | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/events")
      .then((r) => r.json())
      .then((d) => { setItems(d.events || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function remove(id: string) {
    if (!confirm("Delete this event?")) return;
    const res = await fetch(`/api/admin/events/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted."); load(); } else toast.error("Failed.");
  }

  if (loading) return <LoadingState rows={4} />;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} event{items.length === 1 ? "" : "s"}</p>
        <Button size="sm" onClick={() => setEditing("new")}><Plus className="mr-1.5 h-3.5 w-3.5" /> New event</Button>
      </div>
      {items.map((e) => (
        <div key={e.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-foreground">{e.title}</h3>
              <TechPill>{e.type.replace("_", " ")}</TechPill>
              <TechPill tone="engineering">{e.status}</TechPill>
              <span className="text-xs text-muted-foreground font-mono">{e.registered}/{e.capacity}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1 font-mono">{new Date(e.startDate).toLocaleDateString()} · {e.location}</p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={() => setEditing(e)}><Pencil className="h-3.5 w-3.5" /></Button>
            <Button variant="ghost" size="sm" onClick={() => remove(e.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
          </div>
        </div>
      ))}
      <EventEditor event={editing} onClose={() => setEditing(null)} onSaved={load} />
    </div>
  );
}

function EventEditor({ event, onClose, onSaved }: { event: EventItem | "new" | null; onClose: () => void; onSaved: () => void }) {
  const isNew = event === "new";
  const [form, setForm] = React.useState<Partial<EventItem>>({});
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (!event) return;
    if (isNew) {
      setForm({
        title: "", slug: "", description: "", type: "WORKSHOP",
        startDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 16),
        endDate: new Date(Date.now() + 7 * 86400000 + 7200000).toISOString().slice(0, 16),
        location: "EMSI Fès", capacity: 30, status: "UPCOMING", schedule: [], coverColor: "#1f3a8a",
      });
    } else {
      setForm({
        ...event,
        startDate: new Date(event.startDate).toISOString().slice(0, 16),
        endDate: new Date(event.endDate).toISOString().slice(0, 16),
      });
    }
  }, [event, isNew]);

  if (!event) return null;

  async function save() {
    setSaving(true);
    try {
      const body = { ...form, capacity: Number(form.capacity) };
      const res = isNew
        ? await fetch("/api/admin/events", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
        : await fetch(`/api/admin/events/${form.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success(isNew ? "Event created." : "Event updated.");
      onClose();
      onSaved();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!event} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <DialogTitle>{isNew ? "New event" : "Edit event"}</DialogTitle>
        </DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Title"><Input value={form.title || ""} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></Field>
          <Field label="Slug (optional)"><Input value={form.slug || ""} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} placeholder="auto-generated" /></Field>
          <Field label="Type">
            <Select value={form.type} onValueChange={(v) => setForm((f) => ({ ...f, type: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["HACKATHON", "WORKSHOP", "TALK", "STUDY_JAM"].map((c) => <SelectItem key={c} value={c}>{c.replace("_", " ")}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Status">
            <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["UPCOMING", "LIVE", "COMPLETED", "CANCELLED"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Start date"><Input type="datetime-local" value={form.startDate as string} onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))} /></Field>
          <Field label="End date"><Input type="datetime-local" value={form.endDate as string} onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))} /></Field>
          <Field label="Location"><Input value={form.location || ""} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} /></Field>
          <Field label="Capacity"><Input type="number" min={1} value={form.capacity ?? 30} onChange={(e) => setForm((f) => ({ ...f, capacity: Number(e.target.value) }))} /></Field>
        </div>
        <Field label="Description"><Textarea value={form.description || ""} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className="min-h-[100px]" /></Field>
        <Field label="Cover color"><Input value={form.coverColor || ""} onChange={(e) => setForm((f) => ({ ...f, coverColor: e.target.value }))} className="font-mono" /></Field>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving} className="bg-engineering hover:bg-engineering/90">
            {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
            {isNew ? "Create" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ===== Members ===== */
interface Member {
  id: string; name: string; email: string; role: string; specialty: string | null;
  github: string | null; bio: string | null; createdAt: string;
}

function MembersPanel() {
  const [items, setItems] = React.useState<Member[]>([]);
  const [loading, setLoading] = React.useState(true);
  const load = () => {
    setLoading(true);
    fetch("/api/admin/members")
      .then((r) => r.json())
      .then((d) => { setItems(d.members || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function changeRole(id: string, role: string) {
    const res = await fetch("/api/admin/members", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, role }),
    });
    if (res.ok) { toast.success(`Role set to ${role}.`); load(); } else toast.error("Failed.");
  }
  async function remove(id: string) {
    if (!confirm("Remove this member? This deletes their account.")) return;
    const res = await fetch(`/api/admin/members/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Removed."); load(); } else toast.error("Failed.");
  }

  if (loading) return <LoadingState rows={4} />;
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">{items.length} member{items.length === 1 ? "" : "s"}</p>
      {items.map((m) => (
        <div key={m.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-foreground">{m.name}</h3>
              <TechPill tone={m.role === "ADMIN" ? "engineering" : "default"}>{m.role}</TechPill>
              {m.specialty && <span className="text-xs text-muted-foreground">{m.specialty}</span>}
            </div>
            <p className="text-xs text-muted-foreground mt-1 font-mono">{m.email} · joined {new Date(m.createdAt).toLocaleDateString()}</p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={m.role} onValueChange={(v) => changeRole(m.id, v)}>
              <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="MEMBER">Member</SelectItem>
                <SelectItem value="LEAD">Lead</SelectItem>
                <SelectItem value="ADMIN">Admin</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="sm" onClick={() => remove(m.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ===== Tutorials ===== */
interface Tutorial {
  id: string; title: string; slug: string; summary: string; content: string;
  category: string; difficulty: string; minutes: number; published: boolean;
  author?: { name: string };
}

function TutorialsPanel() {
  const [items, setItems] = React.useState<Tutorial[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState<Tutorial | "new" | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/tutorials")
      .then((r) => r.json())
      .then((d) => { setItems(d.tutorials || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function remove(id: string) {
    if (!confirm("Delete this tutorial?")) return;
    const res = await fetch(`/api/admin/tutorials/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted."); load(); } else toast.error("Failed.");
  }

  if (loading) return <LoadingState rows={4} />;
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} tutorial{items.length === 1 ? "" : "s"}</p>
        <Button size="sm" onClick={() => setEditing("new")}><Plus className="mr-1.5 h-3.5 w-3.5" /> New tutorial</Button>
      </div>
      {items.map((t) => (
        <div key={t.id} className="border border-border rounded-md p-4 bg-background flex items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-medium text-foreground">{t.title}</h3>
              <TechPill>{t.category}</TechPill>
              <TechPill tone="engineering">{t.difficulty}</TechPill>
              {!t.published && <Badge variant="outline">draft</Badge>}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{t.summary}</p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={() => setEditing(t)}><Pencil className="h-3.5 w-3.5" /></Button>
            <Button variant="ghost" size="sm" onClick={() => remove(t.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
          </div>
        </div>
      ))}
      <TutorialEditor item={editing} onClose={() => setEditing(null)} onSaved={load} />
    </div>
  );
}

function TutorialEditor({ item, onClose, onSaved }: { item: Tutorial | "new" | null; onClose: () => void; onSaved: () => void }) {
  const isNew = item === "new";
  const [form, setForm] = React.useState<Partial<Tutorial>>({});
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (!item) return;
    if (isNew) setForm({ title: "", slug: "", summary: "", content: "", category: "FRONTEND", difficulty: "BEGINNER", minutes: 15, published: true });
    else setForm(item);
  }, [item, isNew]);

  if (!item) return null;

  async function save() {
    setSaving(true);
    try {
      const body = { ...form, minutes: Number(form.minutes) };
      const res = isNew
        ? await fetch("/api/admin/tutorials", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
        : await fetch(`/api/admin/tutorials/${form.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success(isNew ? "Tutorial created." : "Tutorial updated.");
      onClose();
      onSaved();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!item} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader><DialogTitle>{isNew ? "New tutorial" : "Edit tutorial"}</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Title"><Input value={form.title || ""} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></Field>
          <Field label="Slug (optional)"><Input value={form.slug || ""} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} placeholder="auto" /></Field>
          <Field label="Category">
            <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["FRONTEND", "BACKEND", "SYSTEMS", "AI", "TOOLS"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Difficulty">
            <Select value={form.difficulty} onValueChange={(v) => setForm((f) => ({ ...f, difficulty: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["BEGINNER", "INTERMEDIATE", "ADVANCED"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Minutes"><Input type="number" min={1} value={form.minutes ?? 10} onChange={(e) => setForm((f) => ({ ...f, minutes: Number(e.target.value) }))} /></Field>
        </div>
        <Field label="Summary"><Input value={form.summary || ""} onChange={(e) => setForm((f) => ({ ...f, summary: e.target.value }))} /></Field>
        <Field label="Content (Markdown)">
          <Textarea value={form.content || ""} onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))} className="min-h-[200px] font-mono text-[12.5px]" />
        </Field>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input type="checkbox" checked={!!form.published} onChange={(e) => setForm((f) => ({ ...f, published: e.target.checked }))} className="accent-engineering" />
          Published
        </label>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving} className="bg-engineering hover:bg-engineering/90">
            {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
            {isNew ? "Create" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ===== Challenges ===== */
interface Challenge {
  id: string; title: string; slug: string; description: string;
  difficulty: string; category: string; starterCode: string; solution: string;
  tests: { input: unknown[]; expected: unknown }[];
}

function ChallengesPanel() {
  const [items, setItems] = React.useState<Challenge[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState<"new" | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/challenges")
      .then((r) => r.json())
      .then((d) => { setItems(d.challenges || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  if (loading) return <LoadingState rows={4} />;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} challenge{items.length === 1 ? "" : "s"}</p>
        <Button size="sm" onClick={() => setEditing("new")}><Plus className="mr-1.5 h-3.5 w-3.5" /> New challenge</Button>
      </div>
      {items.map((c) => (
        <div key={c.id} className="border border-border rounded-md p-4 bg-background">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-medium text-foreground">{c.title}</h3>
                <TechPill>{c.difficulty}</TechPill>
                <TechPill tone="engineering">{c.category}</TechPill>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{c.tests.length} test case{c.tests.length === 1 ? "" : "s"}</p>
            </div>
          </div>
        </div>
      ))}
      <ChallengeCreator open={editing === "new"} onClose={() => setEditing(null)} onSaved={load} />
    </div>
  );
}

function ChallengeCreator({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = React.useState({
    title: "", slug: "", description: "", difficulty: "EASY", category: "ALGORITHMS",
    starterCode: "function solution(input) {\n  // your code\n}", solution: "", testsJson: '[\n  { "input": [1, 2], "expected": 3 }\n]',
  });
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const tests = JSON.parse(form.testsJson);
      if (!Array.isArray(tests)) throw new Error("Tests must be a JSON array.");
      const res = await fetch("/api/admin/challenges", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, tests }),
      });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success("Challenge created.");
      onClose();
      onSaved();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader><DialogTitle>New coding challenge</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Title"><Input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></Field>
          <Field label="Slug (optional)"><Input value={form.slug} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} /></Field>
          <Field label="Difficulty">
            <Select value={form.difficulty} onValueChange={(v) => setForm((f) => ({ ...f, difficulty: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["EASY", "MEDIUM", "HARD"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Category">
            <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["ALGORITHMS", "DATA_STRUCTURES", "SYSTEMS", "WEB"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
        </div>
        <Field label="Description"><Textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} /></Field>
        <Field label="Starter code"><Textarea value={form.starterCode} onChange={(e) => setForm((f) => ({ ...f, starterCode: e.target.value }))} className="font-mono text-[12.5px] min-h-[120px]" /></Field>
        <Field label="Tests (JSON array)"><Textarea value={form.testsJson} onChange={(e) => setForm((f) => ({ ...f, testsJson: e.target.value }))} className="font-mono text-[12.5px] min-h-[120px]" /></Field>
        {error && <p className="text-xs text-destructive font-mono">{error}</p>}
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving} className="bg-engineering hover:bg-engineering/90">
            {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
            Create
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ===== Quizzes ===== */
interface Quiz {
  id: string; title: string; slug: string; category: string;
  questions: { id: string; prompt: string; options: string[]; answer: number }[];
}

function QuizzesPanel() {
  const [items, setItems] = React.useState<Quiz[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [creating, setCreating] = React.useState(false);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/quizzes")
      .then((r) => r.json())
      .then((d) => { setItems(d.quizzes || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  if (loading) return <LoadingState rows={4} />;
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} quiz{items.length === 1 ? "" : "zes"}</p>
        <Button size="sm" onClick={() => setCreating(true)}><Plus className="mr-1.5 h-3.5 w-3.5" /> New quiz</Button>
      </div>
      {items.map((q) => (
        <div key={q.id} className="border border-border rounded-md p-4 bg-background">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-foreground">{q.title}</h3>
            <TechPill>{q.category}</TechPill>
          </div>
          <p className="text-xs text-muted-foreground mt-1">{q.questions.length} question{q.questions.length === 1 ? "" : "s"}</p>
        </div>
      ))}
      <QuizCreator open={creating} onClose={() => setCreating(false)} onSaved={load} />
    </div>
  );
}

function QuizCreator({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: () => void }) {
  const [title, setTitle] = React.useState("");
  const [category, setCategory] = React.useState("GENERAL");
  const [questionsJson, setQuestionsJson] = React.useState(
    '[\n  {\n    "id": "q1",\n    "prompt": "Question?",\n    "options": ["A", "B", "C", "D"],\n    "answer": 0\n  }\n]'
  );
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const questions = JSON.parse(questionsJson);
      if (!Array.isArray(questions) || questions.length === 0) throw new Error("At least one question required.");
      const res = await fetch("/api/admin/quizzes", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, category, questions }),
      });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success("Quiz created.");
      onClose();
      onSaved();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader><DialogTitle>New quiz</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Title"><Input value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
          <Field label="Category">
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["FRONTEND", "BACKEND", "ALGORITHMS", "SYSTEMS", "GENERAL"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
        </div>
        <Field label="Questions (JSON)">
          <Textarea value={questionsJson} onChange={(e) => setQuestionsJson(e.target.value)} className="font-mono text-[12.5px] min-h-[200px]" />
        </Field>
        {error && <p className="text-xs text-destructive font-mono">{error}</p>}
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving} className="bg-engineering hover:bg-engineering/90">
            {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
            Create
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ===== Announcements ===== */
interface Announcement {
  id: string; title: string; body: string; category: string;
  pinned: boolean; createdAt: string; author?: { name: string };
}

function AnnouncementsPanel() {
  const [items, setItems] = React.useState<Announcement[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState<Announcement | "new" | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/announcements")
      .then((r) => r.json())
      .then((d) => { setItems(d.announcements || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function remove(id: string) {
    if (!confirm("Delete this announcement?")) return;
    const res = await fetch(`/api/admin/announcements/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted."); load(); } else toast.error("Failed.");
  }

  if (loading) return <LoadingState rows={4} />;
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} announcement{items.length === 1 ? "" : "s"}</p>
        <Button size="sm" onClick={() => setEditing("new")}><Plus className="mr-1.5 h-3.5 w-3.5" /> New announcement</Button>
      </div>
      {items.map((a) => (
        <div key={a.id} className="border border-border rounded-md p-4 bg-background flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-foreground">{a.title}</h3>
              <TechPill>{a.category}</TechPill>
              {a.pinned && <Badge className="font-mono text-[9px] bg-engineering text-white">Pinned</Badge>}
            </div>
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{a.body}</p>
            <p className="text-xs text-muted-foreground mt-1 font-mono">by {a.author?.name} · {new Date(a.createdAt).toLocaleDateString()}</p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={() => setEditing(a)}><Pencil className="h-3.5 w-3.5" /></Button>
            <Button variant="ghost" size="sm" onClick={() => remove(a.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
          </div>
        </div>
      ))}
      <AnnouncementEditor item={editing} onClose={() => setEditing(null)} onSaved={load} />
    </div>
  );
}

function AnnouncementEditor({ item, onClose, onSaved }: { item: Announcement | "new" | null; onClose: () => void; onSaved: () => void }) {
  const isNew = item === "new";
  const [form, setForm] = React.useState<Partial<Announcement>>({});
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (!item) return;
    if (isNew) setForm({ title: "", body: "", category: "CLUB", pinned: false });
    else setForm(item);
  }, [item, isNew]);

  if (!item) return null;

  async function save() {
    setSaving(true);
    try {
      const res = isNew
        ? await fetch("/api/admin/announcements", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) })
        : await fetch(`/api/admin/announcements/${form.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (!res.ok) throw new Error((await res.json()).error || "Failed.");
      toast.success(isNew ? "Announcement created." : "Announcement updated.");
      onClose();
      onSaved();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!item} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader><DialogTitle>{isNew ? "New announcement" : "Edit announcement"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Field label="Title"><Input value={form.title || ""} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></Field>
          <Field label="Category">
            <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["CLUB", "EVENT", "LEARNING"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Body"><Textarea value={form.body || ""} onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))} className="min-h-[120px]" /></Field>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" checked={!!form.pinned} onChange={(e) => setForm((f) => ({ ...f, pinned: e.target.checked }))} className="accent-engineering" />
            Pinned to top
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving} className="bg-engineering hover:bg-engineering/90">
            {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
            {isNew ? "Create" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-mono uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
