"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Plus, ThumbsUp, Check, Clock, Trash2, Trophy, Loader2, AlertCircle, Users,
} from "lucide-react";
import { SectionHeader, TechPill, BlueprintFrame, EmptyState, LoadingState } from "@/components/site-primitives";
import { useAuth } from "@/components/auth-provider";
import { useI18n } from "@/components/i18n-provider";
import { navigate } from "@/lib/router";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Proposal {
  id: string;
  title: string;
  description: string;
  category: string;
  deadline: string;
  status: string;
  winner: boolean;
  createdAt: string;
  voteCount: number;
  hasVoted: boolean;
  isClosed: boolean;
  author: { name: string; specialty: string | null };
}

export function DecisionsView() {
  const { session, loading: authLoading } = useAuth();
  const { t } = useI18n();
  const [proposals, setProposals] = React.useState<Proposal[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState("active");
  const [showForm, setShowForm] = React.useState(false);
  const [voting, setVoting] = React.useState<string | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/decisions")
      .then((r) => r.json())
      .then((d) => { setProposals(d.proposals || []); setLoading(false); })
      .catch(() => setLoading(false));
  };
  React.useEffect(load, []);

  async function vote(id: string) {
    if (!session) { toast.error(t("decisions.signInRequired")); navigate("login"); return; }
    setVoting(id);
    try {
      const res = await fetch("/api/decisions/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proposalId: id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to vote.");
      setProposals((prev) => prev.map((p) =>
        p.id === id ? { ...p, voteCount: data.voteCount, hasVoted: data.voted } : p
      ));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setVoting(null);
    }
  }

  async function deleteProposal(id: string) {
    if (!confirm(t("decisions.deleteProposal") + "?")) return;
    const res = await fetch(`/api/decisions/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success(t("decisions.deleteProposal")); load(); } else toast.error("Failed.");
  }

  const active = proposals.filter((p) => !p.isClosed);
  const closed = proposals.filter((p) => p.isClosed);
  const mine = proposals.filter((p) => session && p.author.name === session.name);

  if (authLoading || loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <LoadingState rows={4} />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <EmptyState
          icon={<AlertCircle className="h-6 w-6" />}
          title={t("decisions.signInRequired")}
          description={t("decisions.signInDesc")}
          action={<Button onClick={() => navigate("login")}>{t("nav.signIn")}</Button>}
        />
      </div>
    );
  }

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label={t("decisions.label")}
            title={t("decisions.title")}
            description={t("decisions.desc")}
          />
          <div className="mt-6 flex items-center gap-3">
            <Button onClick={() => setShowForm(true)} className="bg-engineering hover:bg-engineering/90 gap-2">
              <Plus className="h-4 w-4" />
              {t("decisions.newProposal")}
            </Button>
            <span className="text-xs text-muted-foreground font-mono">
              {proposals.length} proposals · {active.length} active · {closed.length} closed
            </span>
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="flex h-auto flex-wrap gap-1 bg-secondary/50 p-1 rounded-md">
              <TabsTrigger value="active" className="gap-2 h-10 px-3 text-sm">
                {t("decisions.tab.active")} ({active.length})
              </TabsTrigger>
              <TabsTrigger value="closed" className="gap-2 h-10 px-3 text-sm">
                {t("decisions.tab.closed")} ({closed.length})
              </TabsTrigger>
              <TabsTrigger value="mine" className="gap-2 h-10 px-3 text-sm">
                {t("decisions.tab.mine")} ({mine.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="mt-6 space-y-3">
              {active.length === 0 ? (
                <EmptyState
                  icon={<ThumbsUp className="h-6 w-6" />}
                  title={t("decisions.noProposals")}
                  description={t("decisions.noProposalsDesc")}
                  action={<Button onClick={() => setShowForm(true)} className="gap-2"><Plus className="h-4 w-4" />{t("decisions.propose")}</Button>}
                />
              ) : (
                active.map((p) => (
                  <ProposalCard
                    key={p.id}
                    proposal={p}
                    t={t}
                    session={session}
                    voting={voting === p.id}
                    onVote={() => vote(p.id)}
                    onDelete={() => deleteProposal(p.id)}
                  />
                ))
              )}
            </TabsContent>

            <TabsContent value="closed" className="mt-6 space-y-3">
              {closed.length === 0 ? (
                <EmptyState icon={<Trophy className="h-6 w-6" />} title={t("decisions.closed")} />
              ) : (
                closed
                  .sort((a, b) => Number(b.winner) - Number(a.winner) || b.voteCount - a.voteCount)
                  .map((p) => (
                    <ProposalCard
                      key={p.id}
                      proposal={p}
                      t={t}
                      session={session}
                      voting={voting === p.id}
                      onVote={() => vote(p.id)}
                      onDelete={() => deleteProposal(p.id)}
                    />
                  ))
              )}
            </TabsContent>

            <TabsContent value="mine" className="mt-6 space-y-3">
              {mine.length === 0 ? (
                <EmptyState icon={<Plus className="h-6 w-6" />} title={t("decisions.noMine")} />
              ) : (
                mine.map((p) => (
                  <ProposalCard
                    key={p.id}
                    proposal={p}
                    t={t}
                    session={session}
                    voting={voting === p.id}
                    onVote={() => vote(p.id)}
                    onDelete={() => deleteProposal(p.id)}
                  />
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <ProposalForm
        open={showForm}
        onClose={() => setShowForm(false)}
        onSaved={load}
        t={t}
      />
    </>
  );
}

function ProposalCard({
  proposal, t, session, voting, onVote, onDelete,
}: {
  proposal: Proposal;
  t: (k: string) => string;
  session: { userId: string; name: string; role: string };
  voting: boolean;
  onVote: () => void;
  onDelete: () => void;
}) {
  const deadline = new Date(proposal.deadline);
  const now = new Date();
  const daysLeft = Math.max(0, Math.ceil((deadline.getTime() - now.getTime()) / 86400000));
  const isAuthor = proposal.author.name === session.name;
  const canDelete = isAuthor || session.role === "ADMIN" || session.role === "LEAD";
  const maxVotes = 100; // visual scale
  const votePct = Math.min(100, (proposal.voteCount / Math.max(1, maxVotes)) * 100);

  const categoryLabel = (cat: string) => {
    const map: Record<string, string> = {
      WORKSHOP: t("decisions.form.categoryWorkshop"),
      TALK: t("decisions.form.categoryTalk"),
      PROJECT: t("decisions.form.categoryProject"),
      EVENT: t("decisions.form.categoryEvent"),
    };
    return map[cat] || cat;
  };

  return (
    <article className={cn(
      "border rounded-md p-5 bg-background transition-colors",
      proposal.winner ? "border-engineering/50 bg-engineering/[0.03]" : "border-border hover:border-foreground/30"
    )}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <TechPill>{categoryLabel(proposal.category)}</TechPill>
            {proposal.winner && (
              <Badge className="gap-1 bg-engineering text-white">
                <Trophy className="h-3 w-3" />
                {t("decisions.winner")}
              </Badge>
            )}
            {proposal.isClosed && !proposal.winner && (
              <Badge variant="outline" className="gap-1">
                <Clock className="h-3 w-3" />
                {t("decisions.closed")}
              </Badge>
            )}
          </div>
          <h3 className="font-semibold text-base">{proposal.title}</h3>
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">{proposal.description}</p>
          <div className="flex items-center gap-3 text-xs text-muted-foreground font-mono pt-1">
            <span>{t("decisions.proposedBy")} {proposal.author.name}</span>
            <span>·</span>
            {!proposal.isClosed ? (
              <span className="text-engineering">{daysLeft} {t("decisions.daysLeft")}</span>
            ) : (
              <span>{t("decisions.timeUp")}</span>
            )}
          </div>
        </div>

        {/* Vote column */}
        <div className="flex flex-col items-center gap-2 shrink-0 w-24">
          <button
            onClick={onVote}
            disabled={voting || proposal.isClosed}
            className={cn(
              "flex flex-col items-center gap-1 px-3 py-2 rounded-md border-2 transition-all",
              proposal.hasVoted
                ? "border-engineering bg-engineering/10 text-engineering"
                : "border-border hover:border-engineering/50 hover:bg-engineering/5",
              proposal.isClosed && "opacity-50 cursor-not-allowed"
            )}
          >
            {voting ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : proposal.hasVoted ? (
              <Check className="h-5 w-5" />
            ) : (
              <ThumbsUp className="h-5 w-5" />
            )}
            <span className="font-mono text-lg font-bold leading-none">{proposal.voteCount}</span>
          </button>
          <span className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">
            {proposal.hasVoted ? t("decisions.voted") : t("decisions.vote")}
          </span>
        </div>
      </div>

      {/* Vote bar */}
      {proposal.isClosed && (
        <div className="mt-4 pt-3 border-t border-border">
          <div className="flex items-center justify-between text-xs text-muted-foreground font-mono mb-1.5">
            <span className="inline-flex items-center gap-1.5">
              <Users className="h-3 w-3" />
              {t("decisions.totalVotes")}: {proposal.voteCount}
            </span>
            {proposal.winner && (
              <span className="inline-flex items-center gap-1 text-engineering">
                <Trophy className="h-3 w-3" />
                {t("decisions.leading")}
              </span>
            )}
          </div>
          <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
            <div
              className={cn("h-full rounded-full transition-all", proposal.winner ? "bg-engineering" : "bg-foreground/40")}
              style={{ width: `${Math.max(5, votePct)}%` }}
            />
          </div>
        </div>
      )}

      {/* Delete button */}
      {canDelete && !proposal.isClosed && (
        <div className="mt-3 pt-3 border-t border-border flex justify-end">
          <Button variant="ghost" size="sm" onClick={onDelete} className="text-destructive hover:text-destructive gap-1.5">
            <Trash2 className="h-3.5 w-3.5" />
            {t("decisions.deleteProposal")}
          </Button>
        </div>
      )}
    </article>
  );
}

function ProposalForm({
  open, onClose, onSaved, t,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  t: (k: string) => string;
}) {
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [category, setCategory] = React.useState("WORKSHOP");
  const [deadline, setDeadline] = React.useState(() => {
    const d = new Date(Date.now() + 7 * 86400000);
    return d.toISOString().slice(0, 10);
  });
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (open) { setTitle(""); setDescription(""); setCategory("WORKSHOP"); }
  }, [open]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/decisions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, category, deadline }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed.");
      toast.success(t("decisions.form.submit"));
      onClose();
      onSaved();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{t("decisions.propose")}</DialogTitle>
          <DialogDescription>{t("decisions.desc")}</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label>{t("decisions.form.title")}</Label>
            <Input
              required
              minLength={3}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t("decisions.form.titlePlaceholder")}
            />
          </div>
          <div className="space-y-1.5">
            <Label>{t("decisions.form.description")}</Label>
            <Textarea
              required
              minLength={10}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t("decisions.form.descriptionPlaceholder")}
              className="min-h-[100px]"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>{t("decisions.form.category")}</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="WORKSHOP">{t("decisions.form.categoryWorkshop")}</SelectItem>
                  <SelectItem value="TALK">{t("decisions.form.categoryTalk")}</SelectItem>
                  <SelectItem value="PROJECT">{t("decisions.form.categoryProject")}</SelectItem>
                  <SelectItem value="EVENT">{t("decisions.form.categoryEvent")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("decisions.form.deadline")}</Label>
              <Input
                type="date"
                required
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                min={new Date().toISOString().slice(0, 10)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>{t("common.cancel")}</Button>
            <Button type="submit" disabled={saving} className="bg-engineering hover:bg-engineering/90">
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
              {t("decisions.form.submit")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
