"use client";

import * as React from "react";
import { Search, X, Github, ArrowUpRight, Filter, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { SectionHeader, TechPill, Reveal, EmptyState, LoadingState } from "@/components/site-primitives";
import { ProjectCard } from "@/components/views/home";
import { useAuth } from "@/components/auth-provider";
import { toast } from "sonner";

interface Project {
  id: string; title: string; slug: string; summary: string; description: string;
  category: string; techStack: string[]; githubUrl: string | null; demoUrl: string | null;
  status: string; featured: boolean; contributors: string[]; coverColor: string | null;
  createdAt: string;
}

const CATEGORIES = ["ALL", "WEB", "AI", "SYSTEMS", "HARDWARE", "MOBILE", "TOOLING"];
const STATUSES = ["ALL", "SHIPPED", "IN_PROGRESS", "CONCEPT"];

export function ProjectsView() {
  const [projects, setProjects] = React.useState<Project[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("ALL");
  const [status, setStatus] = React.useState("ALL");
  const [selected, setSelected] = React.useState<Project | null>(null);

  React.useEffect(() => {
    setLoading(true);
    const ctrl = new AbortController();
    const t = setTimeout(() => {
      const params = new URLSearchParams();
      if (search) params.set("q", search);
      if (category !== "ALL") params.set("category", category);
      if (status !== "ALL") params.set("status", status);
      fetch(`/api/projects?${params.toString()}`, { signal: ctrl.signal })
        .then((r) => r.json())
        .then((d) => { setProjects(d.projects || []); setLoading(false); })
        .catch(() => { if (!ctrl.signal.aborted) setLoading(false); });
    }, 200);
    return () => { ctrl.abort(); clearTimeout(t); };
  }, [search, category, status]);

  return (
    <>
      {/* Hero */}
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label="Portfolio · Engineering"
            title="Projects with real users."
            description="Open-source work shipped by TechHub members. Every project has a public repository, a README, and a working demo where applicable."
          />
        </div>
      </section>

      {/* Filter bar */}
      <section className="sticky top-16 z-30 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search projects, technologies, summaries…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 pr-9"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="flex gap-2 flex-wrap items-center">
              <Filter className="h-3.5 w-3.5 text-muted-foreground hidden sm:block" />
              <FilterChips
                label="Category"
                value={category}
                options={CATEGORIES}
                onChange={setCategory}
              />
              <FilterChips
                label="Status"
                value={status}
                options={STATUSES}
                onChange={setStatus}
              />
            </div>
          </div>
          <div className="mt-2 text-xs text-muted-foreground font-mono">
            {loading ? "loading…" : `${projects.length} project${projects.length === 1 ? "" : "s"}`}
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {loading ? (
            <LoadingState rows={4} />
          ) : projects.length === 0 ? (
            <EmptyState
              icon={<Search className="h-6 w-6" />}
              title="No projects match your filters."
              description="Try removing a filter or searching for something broader — like 'rust' or 'web'."
              action={<Button variant="outline" onClick={() => { setSearch(""); setCategory("ALL"); setStatus("ALL"); }}>Reset filters</Button>}
            />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {projects.map((p, i) => (
                <Reveal key={p.id} delay={(i % 6) * 50}>
                  <button onClick={() => setSelected(p)} className="text-left h-full w-full">
                    <ProjectCard project={p} />
                  </button>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Detail drawer */}
      <ProjectDialog project={selected} onClose={() => setSelected(null)} />
    </>
  );
}

function FilterChips({
  label, value, options, onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto scrollbar-thin">
      <span className="sr-only">{label}</span>
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(opt)}
          className={
            "font-mono text-[11px] tracking-wider uppercase px-2.5 py-1 rounded-sm border transition-colors whitespace-nowrap " +
            (value === opt
              ? "bg-foreground text-background border-foreground"
              : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")
          }
        >
          {opt === "ALL" ? "All" : opt.replace("_", " ")}
        </button>
      ))}
    </div>
  );
}

function ProjectDialog({ project, onClose }: { project: Project | null; onClose: () => void }) {
  const { session } = useAuth();
  const [submitting, setSubmitting] = React.useState(false);
  if (!project) return null;
  const accent = project.coverColor || "#1f3a8a";

  async function expressInterest() {
    if (!session) { toast.error("Sign in to express interest."); return; }
    setSubmitting(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      toast.success("Interest registered. A lead will reach out.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={!!project} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider">
              {project.category}
            </Badge>
            <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider">
              {project.status.replace("_", " ")}
            </Badge>
            {project.featured && (
              <Badge className="font-mono text-[10px] uppercase tracking-wider bg-engineering text-white">
                Featured
              </Badge>
            )}
          </div>
          <DialogTitle className="text-2xl tracking-tight mt-2">{project.title}</DialogTitle>
          <DialogDescription className="text-base text-foreground/80">
            {project.summary}
          </DialogDescription>
        </DialogHeader>

        <div
          className="h-32 rounded-md border border-border relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${accent}18, ${accent}06), var(--secondary)`,
          }}
        >
          <div className="absolute inset-0 bg-engineering-grid-sm opacity-30" />
          <div className="absolute bottom-3 left-4 font-mono text-[10px] tracking-widest uppercase text-foreground/70">
            {project.slug}
          </div>
        </div>

        <div className="space-y-4 text-sm leading-relaxed text-foreground/90">
          <p>{project.description}</p>
        </div>

        <div className="space-y-3">
          <p className="label-mono">Stack</p>
          <div className="flex flex-wrap gap-1.5">
            {project.techStack.map((t) => <TechPill key={t}>{t}</TechPill>)}
          </div>
        </div>

        {project.contributors.length > 0 && (
          <div className="space-y-3">
            <p className="label-mono">Team</p>
            <div className="flex flex-wrap gap-2">
              {project.contributors.map((c) => (
                <span key={c} className="inline-flex items-center gap-2 text-sm border border-border rounded-md px-2.5 py-1.5 bg-secondary/40">
                  <span className="h-5 w-5 rounded-full bg-engineering/20 text-engineering text-[10px] font-mono flex items-center justify-center">
                    {c.split(" ").map((x) => x[0]).slice(0, 2).join("")}
                  </span>
                  {c}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2 pt-3 border-t border-border">
          {project.githubUrl && (
            <Button asChild variant="outline">
              <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                <Github className="mr-2 h-4 w-4" />
                View on GitHub
              </a>
            </Button>
          )}
          {project.demoUrl && (
            <Button asChild>
              <a href={project.demoUrl} target="_blank" rel="noopener noreferrer">
                <ArrowUpRight className="mr-2 h-4 w-4" />
                Live demo
              </a>
            </Button>
          )}
          <Button
            onClick={expressInterest}
            disabled={submitting}
            variant="ghost"
            className="ml-auto"
          >
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "I want to contribute"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
