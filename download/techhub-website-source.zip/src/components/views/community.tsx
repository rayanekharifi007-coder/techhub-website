"use client";

import * as React from "react";
import { Github, Linkedin, Mail, Pin, Megaphone, Users, GitBranch } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { SectionHeader, TechPill, Reveal, LoadingState } from "@/components/site-primitives";

interface Member {
  id: string; name: string; role: string; bio: string | null;
  github: string | null; linkedin: string | null; specialty: string | null;
  avatarUrl: string | null; skills: string[];
  projects: number; eventsAttended: number; createdAt: string;
}
interface Announcement {
  id: string; title: string; body: string; category: string;
  pinned: boolean; createdAt: string;
  author?: { name: string };
}

export function CommunityView() {
  const [members, setMembers] = React.useState<Member[]>([]);
  const [announcements, setAnnouncements] = React.useState<Announcement[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    Promise.all([
      fetch("/api/community").then((r) => r.json()),
      fetch("/api/announcements").then((r) => r.json()),
    ])
      .then(([m, a]) => {
        setMembers(m.members || []);
        setAnnouncements(a.announcements || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const leads = members.filter((m) => m.role === "ADMIN" || m.role === "LEAD");
  const regularMembers = members.filter((m) => m.role === "MEMBER");

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label="Community · The lab"
            title="The people who build, teach, and run TechHub."
            description="A short list of the engineers, designers, and researchers who currently ship in the open under the TechHub banner."
          />
        </div>
      </section>

      {/* Announcements */}
      <section className="py-12 sm:py-16 border-b border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-6">
            <Megaphone className="h-4 w-4 text-engineering" />
            <p className="label-mono">Announcements</p>
          </div>
          {loading ? (
            <LoadingState rows={3} />
          ) : announcements.length === 0 ? (
            <p className="text-sm text-muted-foreground">No announcements right now. Check back soon.</p>
          ) : (
            <div className="grid gap-3">
              {announcements.map((a, i) => (
                <Reveal key={a.id} delay={i * 60}>
                  <article
                    className={
                      "border rounded-md p-5 bg-background " +
                      (a.pinned ? "border-engineering/40 bg-engineering/[0.03]" : "border-border")
                    }
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1.5">
                          {a.pinned && <Pin className="h-3 w-3 text-engineering" />}
                          <TechPill tone="engineering">{a.category}</TechPill>
                          <span className="font-mono text-[10px] text-muted-foreground">
                            {new Date(a.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                          </span>
                          {a.author && <span className="text-xs text-muted-foreground">· {a.author.name}</span>}
                        </div>
                        <h3 className="font-semibold text-base">{a.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{a.body}</p>
                      </div>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Leads */}
      {leads.length > 0 && (
        <section className="py-12 sm:py-16 border-b border-border">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2 mb-6">
              <GitBranch className="h-4 w-4 text-engineering" />
              <p className="label-mono">Leads & admins</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {leads.map((m, i) => (
                <Reveal key={m.id} delay={i * 60}>
                  <MemberCard member={m} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Members */}
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-6">
            <Users className="h-4 w-4 text-engineering" />
            <p className="label-mono">Members · {regularMembers.length}</p>
          </div>
          {loading ? (
            <LoadingState rows={4} />
          ) : regularMembers.length === 0 ? (
            <div className="border border-dashed border-border rounded-md p-10 text-center">
              <p className="text-sm font-medium text-foreground">No member profiles yet.</p>
              <p className="text-sm text-muted-foreground mt-1">
                Once members register, their public profiles will appear here.
              </p>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {regularMembers.map((m, i) => (
                <Reveal key={m.id} delay={(i % 6) * 50}>
                  <MemberCard member={m} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}

function MemberCard({ member }: { member: Member }) {
  const initials = member.name.split(" ").map((n) => n[0]).slice(0, 2).join("");
  return (
    <article className="h-full border border-border rounded-md p-5 bg-background hover:border-foreground/30 transition-colors">
      <div className="flex items-start gap-3">
        <div className="h-11 w-11 rounded-md bg-engineering/15 text-engineering font-mono font-semibold flex items-center justify-center shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-base truncate">{member.name}</h3>
          {member.specialty && (
            <p className="text-xs text-muted-foreground truncate">{member.specialty}</p>
          )}
          <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider mt-1.5">
            {member.role}
          </Badge>
        </div>
      </div>
      {member.bio && <p className="text-sm text-muted-foreground mt-3 leading-relaxed line-clamp-3">{member.bio}</p>}
      {member.skills && member.skills.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-3">
          {member.skills.slice(0, 4).map((s) => <TechPill key={s}>{s}</TechPill>)}
        </div>
      )}
      <div className="mt-4 pt-3 border-t border-border flex items-center justify-between text-xs">
        <div className="flex items-center gap-3 text-muted-foreground font-mono">
          <span>{member.projects} project{member.projects === 1 ? "" : "s"}</span>
          <span>{member.eventsAttended} event{member.eventsAttended === 1 ? "" : "s"}</span>
        </div>
        <div className="flex items-center gap-2">
          {member.github && (
            <a href={`https://github.com/${member.github}`} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground" aria-label="GitHub">
              <Github className="h-3.5 w-3.5" />
            </a>
          )}
          {member.linkedin && (
            <a href={`https://linkedin.com/in/${member.linkedin}`} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground" aria-label="LinkedIn">
              <Linkedin className="h-3.5 w-3.5" />
            </a>
          )}
          <Mail className="h-3.5 w-3.5 text-muted-foreground" />
        </div>
      </div>
    </article>
  );
}
