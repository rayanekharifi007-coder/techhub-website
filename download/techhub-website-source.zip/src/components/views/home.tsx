"use client";

import * as React from "react";
import {
  ArrowRight, Cpu, Code2, GitBranch, Terminal, Sparkles,
  ChevronRight, CircuitBoard, Hammer,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouterStore, navigate } from "@/lib/router";
import { SectionHeader, TechPill, Reveal, BlueprintFrame } from "@/components/site-primitives";
import { TechGallery } from "@/components/tech-gallery";
import { TerminalWidget } from "@/components/terminal-widget";
import { Typewriter } from "@/components/typewriter";
import { Magnetic } from "@/components/magnetic";
import { ParticleConstellation } from "@/components/particle-constellation";
import { TiltCard } from "@/components/tilt-card";
import { useI18n } from "@/components/i18n-provider";

export function HomeView() {
  return (
    <>
      <Hero />
      <MarqueeStrip />
      <FocusPillars />
      <TechGallery />
      <ProcessSection />
      <QuoteSection />
      <NumbersSection />
      <FinalCTA />
    </>
  );
}

function Hero() {
  const { navigate: nav } = useRouterStore();
  const { t } = useI18n();
  return (
    <section className="relative overflow-hidden">
      {/* Engineering grid */}
      <div className="absolute inset-0 bg-engineering-grid opacity-[0.35] pointer-events-none [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />

      {/* Interactive particle constellation */}
      <div className="absolute inset-0 pointer-events-none opacity-60">
        <ParticleConstellation className="w-full h-full" />
      </div>

      {/* Animated gradient mesh — subtle floating blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute top-[10%] right-[5%] w-[400px] h-[400px] rounded-full opacity-20 blur-3xl animate-[float_8s_ease-in-out_infinite]"
          style={{ background: "radial-gradient(circle, rgba(45,156,219,0.3), transparent 70%)" }}
        />
        <div
          className="absolute bottom-[20%] left-[10%] w-[300px] h-[300px] rounded-full opacity-15 blur-3xl animate-[float_10s_ease-in-out_infinite_reverse]"
          style={{ background: "radial-gradient(circle, rgba(99,102,241,0.25), transparent 70%)" }}
        />
      </div>

      {/* Top gradient line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-engineering/40 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-20 pb-24 sm:pt-28 sm:pb-32">
        <div className="grid lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-7 space-y-7">
            <div className="flex items-center gap-3 animate-[fadeInUp_0.6s_ease-out]">
              <span className="inline-flex items-center gap-2 font-mono text-[11px] tracking-widest uppercase text-engineering border border-engineering/30 bg-engineering/5 px-2.5 py-1 rounded-sm shadow-[0_0_15px_-3px_rgba(45,156,219,0.3)]">
                <span className="h-1.5 w-1.5 rounded-full bg-engineering animate-pulse" />
                {t("hero.badge")}
              </span>
            </div>

            <h1 className="font-semibold tracking-tight text-4xl sm:text-5xl lg:text-6xl leading-[1.04] text-foreground animate-[fadeInUp_0.7s_ease-out_0.1s_both]">
              {t("hero.title1")}
              <br />
              <span className="relative inline-block">
                <span className="shimmer-text">{t("hero.title2")}</span>
                <svg
                  className="absolute -bottom-2 left-0 w-full"
                  viewBox="0 0 320 12"
                  preserveAspectRatio="none"
                  aria-hidden="true"
                >
                  <path
                    d="M2 9 Q 80 2, 160 7 T 318 5"
                    stroke="var(--engineering)"
                    strokeWidth="2"
                    fill="none"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
              .
            </h1>

            <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl animate-[fadeInUp_0.8s_ease-out_0.15s_both]">
              <Typewriter text={t("hero.desc")} speed={25} delay={800} />
            </p>

            <div className="flex flex-col sm:flex-row gap-3 animate-[fadeInUp_0.8s_ease-out_0.2s_both]">
              <Magnetic strength={0.25}>
                <Button size="lg" onClick={() => nav("playground")} className="group bg-engineering hover:bg-engineering/90 text-white shadow-[0_0_25px_-5px_rgba(45,156,219,0.6)] hover:shadow-[0_0_35px_-3px_rgba(45,156,219,0.8)] transition-all duration-300 hover:-translate-y-0.5">
                  {t("hero.cta.explore")}
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </Button>
              </Magnetic>
              <Magnetic strength={0.2}>
                <Button size="lg" variant="outline" onClick={() => nav("join")} className="border-engineering/40 text-engineering hover:bg-engineering/5 hover:border-engineering hover:shadow-[0_0_20px_-5px_rgba(45,156,219,0.4)] transition-all duration-300">
                  {t("hero.cta.join")}
                </Button>
              </Magnetic>
            </div>

            <div className="grid grid-cols-3 gap-4 max-w-md pt-6 border-t border-border animate-[fadeInUp_0.8s_ease-out_0.3s_both]">
              {[
                { k: t("hero.stats.disciplines"), v: "5" },
                { k: t("hero.stats.events"), v: "12+" },
                { k: t("hero.stats.members"), v: "—" },
              ].map((s) => (
                <div key={s.k}>
                  <p className="text-2xl font-semibold text-foreground font-mono">{s.v}</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{s.k}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5">
            <TerminalWidget />
          </div>
        </div>
      </div>
    </section>
  );
}

function HeroPanel() {
  // A precise, engineering "schematic" panel — not a stock image.
  return (
    <BlueprintFrame className="relative bg-background border border-border rounded-md overflow-hidden shadow-[0_1px_0_var(--border),0_8px_30px_rgba(0,0,0,0.04)]">
      <div className="border-b border-border bg-secondary/50 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full border border-border bg-background" />
          <span className="h-2.5 w-2.5 rounded-full border border-border bg-background" />
          <span className="h-2.5 w-2.5 rounded-full border border-border bg-background" />
        </div>
        <span className="font-mono text-[10px] tracking-wider uppercase text-muted-foreground">
          ~/techhub/schematic.tsx
        </span>
      </div>
      <div className="p-5 space-y-4">
        <pre className="font-mono text-[12px] leading-relaxed text-foreground/90 overflow-x-auto scrollbar-thin">
{`type Club = {
  name: "TechHub EMSI Fès";
  founded: 2026;
  location: "Fès, Morocco";
  disciplines: [
    "systems",
    "ai",
    "web",
    "hardware",
    "tooling"
  ];
  shipped: Project[];
  events: Event[];
}`.trim()}
        </pre>
        <div className="border-t border-border pt-4 space-y-2">
          {[
            { icon: Cpu, k: "Track", v: "Systems & AI" },
            { icon: GitBranch, k: "Community", v: "discord.gg/xyVtPuuk" },
            { icon: Terminal, k: "Cadence", v: "Weekly build jams" },
          ].map((r) => (
            <div key={r.k} className="flex items-center gap-2.5 text-[13px]">
              <r.icon className="h-3.5 w-3.5 text-engineering" />
              <span className="text-muted-foreground font-mono text-[11px] uppercase tracking-wider w-24">{r.k}</span>
              <span className="text-foreground font-medium">{r.v}</span>
            </div>
          ))}
        </div>
        <div className="border-t border-dashed border-border pt-4 flex items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full bg-engineering" />
          build 0x2024.10 · stable
        </div>
      </div>
    </BlueprintFrame>
  );
}

function MarqueeStrip() {
  const items = [
    "TypeScript", "Rust", "PyTorch", "Next.js", "PostgreSQL", "Kubernetes",
    "React", "ESP32", "Tailwind", "Docker", "Prisma", "Go", "Redis",
  ];
  return (
    <div className="border-y border-border bg-secondary/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3 overflow-hidden">
        <div className="flex items-center gap-8 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
          <div className="flex items-center gap-8 shrink-0 animate-[marquee_28s_linear_infinite]">
            {[...items, ...items].map((it, i) => (
              <span
                key={i}
                className="font-mono text-[12px] tracking-wider uppercase text-muted-foreground inline-flex items-center gap-3"
              >
                <span className="h-1 w-1 bg-engineering/60" />
                {it}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function FocusPillars() {
  const { t } = useI18n();
  const pillars = [
    {
      icon: Hammer,
      title: t("pillar.build"),
      description: t("pillar.build.desc"),
      items: ["Atlas Routing Engine", "Zellige UI", "Argan Board"],
    },
    {
      icon: Sparkles,
      title: t("pillar.teach"),
      description: t("pillar.teach.desc"),
      items: ["Rust for systems", "Algorithm study jams", "Type-safe API design"],
    },
    {
      icon: CircuitBoard,
      title: t("pillar.connect"),
      description: t("pillar.connect.desc"),
      items: ["Hackathon Atlas — 48h", "Founder talks", "Open community"],
    },
  ];

  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeader
            label={t("section.pillars.label")}
            title={t("section.pillars.title")}
            description={t("section.pillars.desc")}
          />
        </Reveal>
        <div className="mt-12 grid gap-px bg-border border border-border rounded-md overflow-hidden md:grid-cols-3">
          {pillars.map((p, i) => (
            <Reveal key={p.title} delay={i * 80}>
              <TiltCard className="h-full bg-background p-7 space-y-5" maxTilt={6}>
                <div className="flex items-center justify-between">
                  <div className="h-10 w-10 rounded-md border border-border bg-secondary/50 flex items-center justify-center">
                    <p.icon className="h-4.5 w-4.5 text-engineering" />
                  </div>
                  <span className="font-mono text-[11px] tracking-widest uppercase text-muted-foreground">
                    0{i + 1}
                  </span>
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold tracking-tight text-foreground">{p.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{p.description}</p>
                </div>
                <ul className="space-y-1.5 pt-2 border-t border-border">
                  {p.items.map((it) => (
                    <li key={it} className="flex items-center gap-2 text-[13px] text-foreground">
                      <span className="h-1 w-1 bg-engineering" />
                      {it}
                    </li>
                  ))}
                </ul>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProcessSection() {
  const { t } = useI18n();
  const steps = [
    { n: "01", title: t("process.step1.title"), description: t("process.step1.body") },
    { n: "02", title: t("process.step2.title"), description: t("process.step2.body") },
    { n: "03", title: t("process.step3.title"), description: t("process.step3.body") },
    { n: "04", title: t("process.step4.title"), description: t("process.step4.body") },
  ];
  return (
    <section className="py-20 sm:py-28 border-t border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeader
            label={t("section.process.label")}
            title={t("section.process.title")}
            description={t("section.process.desc")}
          />
        </Reveal>
        <div className="mt-12 grid gap-px bg-border border border-border rounded-md overflow-hidden sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 80}>
              <div className="bg-background p-6 h-full space-y-3">
                <span className="font-mono text-2xl text-engineering">{s.n}</span>
                <h3 className="font-semibold tracking-tight">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function QuoteSection() {
  const { t } = useI18n();
  const quotes = [
    { q: "The best way to predict the future is to implement it.", a: "— inspired by Alan Kay" },
    { q: "Talk is cheap. Show me the code.", a: "— Linus Torvalds" },
    { q: "Simplicity is the soul of efficiency.", a: "— Austin Freeman" },
    { q: "First, solve the problem. Then write the code.", a: "— John Johnson" },
    { q: "Code is like humor. When you have to explain it, it's bad.", a: "— Cory House" },
    { q: "Make it work, make it right, make it fast.", a: "— Kent Beck" },
    { q: "The function of good software is to make the complex appear simple.", a: "— Grady Booch" },
    { q: "Programs must be written for people to read, and only incidentally for machines to execute.", a: "— Harold Abelson" },
  ];
  const day = Math.floor(Date.now() / 86400000) % quotes.length;
  const quote = quotes[day];

  return (
    <section className="py-20 sm:py-24 border-t border-border">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="text-center space-y-6">
            <p className="label-mono">{t("section.quote.label")}</p>
            <blockquote className="text-2xl sm:text-3xl font-medium tracking-tight text-foreground leading-[1.3] max-w-3xl mx-auto">
              <span className="text-engineering font-mono text-4xl leading-none align-top mr-1">"</span>
              {quote.q}
              <span className="text-engineering font-mono text-4xl leading-none align-bottom ml-1">"</span>
            </blockquote>
            <p className="text-sm text-muted-foreground font-mono">{quote.a}</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function NumbersSection() {
  const { t } = useI18n();
  return (
    <section className="py-20 sm:py-24 border-t border-border bg-secondary/20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 items-center">
          <Reveal>
            <SectionHeader
              label={t("section.principles.label")}
              title={t("section.principles.title")}
              description={t("section.principles.desc")}
            />
          </Reveal>
          <Reveal delay={120}>
            <ol className="space-y-4">
              {[
                { k: t("principle.ship.title"), v: t("principle.ship.body") },
                { k: t("principle.typeSafety.title"), v: t("principle.typeSafety.body") },
                { k: t("principle.accessibility.title"), v: t("principle.accessibility.body") },
                { k: t("principle.document.title"), v: t("principle.document.body") },
              ].map((p, i) => (
                <li key={p.k} className="flex gap-4">
                  <span className="font-mono text-[11px] tracking-widest uppercase text-engineering mt-1 w-6 shrink-0">
                    P0{i + 1}
                  </span>
                  <div>
                    <p className="font-medium text-foreground">{p.k}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed mt-0.5">{p.v}</p>
                  </div>
                </li>
              ))}
            </ol>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  const { t } = useI18n();
  return (
    <section className="py-20 sm:py-28 border-t border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <BlueprintFrame className="relative overflow-hidden rounded-lg border border-border bg-background animate-[glow-pulse_4s_ease-in-out_infinite]">
          <div className="absolute inset-0 bg-engineering-grid opacity-30 [mask-image:radial-gradient(circle_at_center,black_0%,transparent_70%)]" />
          <div className="relative px-6 sm:px-12 py-14 sm:py-20 text-center space-y-6">
            <p className="label-mono">{t("section.cta.label")}</p>
            <h2 className="text-3xl sm:text-5xl font-semibold tracking-tight leading-tight max-w-3xl mx-auto">
              {t("section.cta.title")}
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
              {t("section.cta.desc")}
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
              <Magnetic strength={0.2}>
                <Button size="lg" onClick={() => navigate("join")} className="group bg-engineering hover:bg-engineering/90 text-white shadow-[0_0_25px_-5px_rgba(45,156,219,0.5)] hover:shadow-[0_0_35px_-3px_rgba(45,156,219,0.7)] transition-all duration-300">
                  {t("section.cta.apply")}
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </Button>
              </Magnetic>
              <Magnetic strength={0.15}>
                <Button size="lg" variant="outline" onClick={() => navigate("contact")} className="border-engineering/40 text-engineering hover:bg-engineering/5 hover:border-engineering transition-all duration-300">
                  {t("section.cta.talk")}
                </Button>
              </Magnetic>
            </div>
          </div>
        </BlueprintFrame>
      </div>
    </section>
  );
}

// keep imports used
void Code2;
void ChevronRight;
void TechPill;
