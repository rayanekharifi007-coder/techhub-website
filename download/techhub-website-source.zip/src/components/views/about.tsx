"use client";

import * as React from "react";
import { SectionHeader, TechPill, Reveal, BlueprintFrame } from "@/components/site-primitives";
import { Button } from "@/components/ui/button";
import { navigate } from "@/lib/router";
import {
  Target, Compass, Heart, Shield, ArrowRight, BookOpen, Users, GitBranch, Code2,
} from "lucide-react";
import { useI18n } from "@/components/i18n-provider";

export function AboutView() {
  const { t } = useI18n();
  return (
    <>
      {/* Hero */}
      <section className="relative border-b border-border">
        <div className="absolute inset-0 bg-engineering-grid opacity-30 [mask-image:linear-gradient(to_bottom,black,transparent_70%)]" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
          <div className="grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-7 space-y-5">
              <p className="label-mono">{t("nav.about")} · {t("about.hero.title").split(" ").slice(-2).join(" ")}</p>
              <h1 className="text-4xl sm:text-5xl font-semibold tracking-tight leading-[1.1]">
                {t("about.hero.title")}
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl">
                {t("about.hero.desc")}
              </p>
              <div className="flex flex-wrap gap-2 pt-2">
                <TechPill tone="engineering">{t("about.badge.founded")}</TechPill>
                <TechPill>{t("about.badge.location")}</TechPill>
                <TechPill>{t("about.badge.studentRun")}</TechPill>
                <TechPill>{t("about.badge.openSource")}</TechPill>
              </div>
            </div>
            <div className="lg:col-span-5">
              <BlueprintFrame className="bg-background border border-border rounded-md p-6 space-y-3">
                <p className="font-mono text-[11px] tracking-widest uppercase text-engineering">{t("about.charter")}</p>
                <pre className="font-mono text-[12px] leading-relaxed text-foreground/90 overflow-x-auto scrollbar-thin">
{`mission: "Where Tech Meets Ideas"

principles:
  - ship in the open
  - teach by doing
  - type-safety is a baseline
  - accessibility is not optional

cadence: weekly
admission: open application
review: public, every Friday`}
                </pre>
              </BlueprintFrame>
            </div>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-12">
          <Reveal className="lg:col-span-4">
            <p className="label-mono">{t("about.origin.label")}</p>
            <h2 className="text-2xl font-semibold tracking-tight mt-3">
              {t("about.origin.title")}
            </h2>
          </Reveal>
          <div className="lg:col-span-8 space-y-5 text-[15px] leading-relaxed text-muted-foreground">
            <p>{t("about.story.p1")}</p>
            <p>{t("about.story.p2")}</p>
            <p>{t("about.story.p3")}</p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 sm:py-28 border-t border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeader
              label={t("about.values.label")}
              title={t("about.values.title")}
              description={t("about.values.desc")}
            />
          </Reveal>
          <div className="mt-12 grid gap-px bg-border border border-border rounded-md overflow-hidden md:grid-cols-2">
            {[
              {
                icon: Target,
                title: t("about.value.craft.title"),
                body: t("about.value.craft.body"),
              },
              {
                icon: Compass,
                title: t("about.value.direction.title"),
                body: t("about.value.direction.body"),
              },
              {
                icon: Heart,
                title: t("about.value.teach.title"),
                body: t("about.value.teach.body"),
              },
              {
                icon: Shield,
                title: t("about.value.open.title"),
                body: t("about.value.open.body"),
              },
            ].map((v, i) => (
              <Reveal key={v.title} delay={i * 80}>
                <div className="bg-background p-7 space-y-4 h-full">
                  <div className="flex items-center justify-between">
                    <div className="h-10 w-10 rounded-md border border-border bg-secondary/50 flex items-center justify-center">
                      <v.icon className="h-4 w-4 text-engineering" />
                    </div>
                    <span className="font-mono text-[11px] tracking-widest uppercase text-muted-foreground">
                      V0{i + 1}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold tracking-tight">{v.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{v.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Structure */}
      <section className="py-20 sm:py-28 border-t border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeader
              label={t("about.structure.label")}
              title={t("about.structure.title")}
              description={t("about.structure.desc")}
            />
          </Reveal>
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {[
              {
                role: "ADMIN",
                title: t("about.role.admin.title"),
                count: "2",
                body: t("about.role.admin.body"),
                items: [t("about.charter"), t("admin.tab.applications"), "Discord admin"],
              },
              {
                role: "LEAD",
                title: t("about.role.lead.title"),
                count: "3–5",
                body: t("about.role.lead.body"),
                items: [t("admin.tab.projects"), t("dashboard.profile"), t("learning.tab.tutorials")],
              },
              {
                role: "MEMBER",
                title: t("about.role.member.title"),
                count: "open",
                body: t("about.role.member.body"),
                items: [t("admin.tab.projects"), t("admin.tab.events"), t("learning.tab.tutorials")],
              },
            ].map((r, i) => (
              <Reveal key={r.role} delay={i * 80}>
                <BlueprintFrame className="bg-background border border-border rounded-md p-6 h-full space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] tracking-widest uppercase text-engineering border border-engineering/30 bg-engineering/5 px-2 py-0.5 rounded-sm">
                      {r.role}
                    </span>
                    <span className="font-mono text-xs text-muted-foreground">{r.count}</span>
                  </div>
                  <h3 className="text-lg font-semibold tracking-tight">{r.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{r.body}</p>
                  <ul className="space-y-1.5 pt-3 border-t border-border">
                    {r.items.map((it) => (
                      <li key={it} className="flex items-center gap-2 text-[13px]">
                        <span className="h-1 w-1 bg-engineering" />
                        {it}
                      </li>
                    ))}
                  </ul>
                </BlueprintFrame>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 sm:py-28 border-t border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeader
              label={t("about.timeline.label")}
              title={t("about.timeline.title")}
              description={t("about.timeline.desc")}
            />
          </Reveal>
          <div className="mt-12 relative">
            <div className="absolute left-[7px] sm:left-1/2 top-0 bottom-0 w-px bg-border" />
            <div className="space-y-8">
              {[
                { period: "Septembre", title: t("join.form.fullName").split(" ")[0] + " " + t("admin.tab.applications").toLowerCase(), body: t("about.role.admin.body") },
                { period: "Octobre", title: "Hackathon Atlas", body: t("pillar.connect.desc") },
                { period: "Novembre", title: t("learning.tab.tutorials"), body: t("pillar.teach.desc") },
                { period: "Décembre", title: t("process.step3.title"), body: t("process.step3.body") },
                { period: "Février", title: t("process.step1.title"), body: t("process.step1.body") },
                { period: "Avril", title: "TechTalks", body: t("pillar.connect.desc") },
                { period: "Juin", title: t("about.values.title"), body: t("about.values.desc") },
              ].map((item, i) => (
                <Reveal key={item.period} delay={i * 60}>
                  <div className={`relative grid sm:grid-cols-2 gap-6 ${i % 2 === 0 ? "" : "sm:[direction:rtl]"}`}>
                    <div className={`pl-8 sm:pl-0 ${i % 2 === 0 ? "sm:text-right sm:pr-12" : "sm:pl-12"} [direction:ltr]`}>
                      <span className="font-mono text-[11px] tracking-widest uppercase text-engineering">{item.period}</span>
                      <h3 className="font-semibold text-base mt-1">{item.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{item.body}</p>
                    </div>
                    <div className="hidden sm:block" />
                    <span className="absolute left-0 sm:left-1/2 top-1 h-3.5 w-3.5 -translate-x-1/2 rounded-full border-2 border-engineering bg-background" />
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 sm:py-28 border-t border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { icon: Code2, title: t("about.cta.playground.title"), body: t("about.cta.playground.body"), cta: t("nav.playground"), route: "playground" as const },
              { icon: BookOpen, title: t("about.cta.learn.title"), body: t("about.cta.learn.body"), cta: t("nav.learning"), route: "learning" as const },
              { icon: Users, title: t("about.cta.contact.title"), body: t("about.cta.contact.body"), cta: t("nav.contact"), route: "contact" as const },
            ].map((c) => (
              <button
                key={c.title}
                onClick={() => navigate(c.route)}
                className="group text-left p-6 rounded-md border border-border bg-background hover:border-foreground/30 transition-colors"
              >
                <c.icon className="h-5 w-5 text-engineering" />
                <h3 className="font-semibold mt-4">{c.title}</h3>
                <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{c.body}</p>
                <span className="inline-flex items-center gap-1 text-sm text-foreground mt-4 group-hover:text-engineering transition-colors">
                  {c.cta}
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                </span>
              </button>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button size="lg" onClick={() => navigate("join")}>
              {t("about.cta.apply")}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
