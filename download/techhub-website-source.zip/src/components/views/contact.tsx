"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Clock, ArrowRight, Loader2, CheckCircle2 } from "lucide-react";
import { DiscordIcon } from "@/components/discord-icon";
import { SectionHeader, BlueprintFrame, Reveal, TechPill } from "@/components/site-primitives";
import { useI18n } from "@/components/i18n-provider";
import { toast } from "sonner";

export function ContactView() {
  const { t } = useI18n();
  const [submitting, setSubmitting] = React.useState(false);
  const [submitted, setSubmitted] = React.useState(false);
  const [form, setForm] = React.useState({ name: "", email: "", subject: "", body: "" });

  function set<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not send.");
      setSubmitted(true);
      toast.success("Message sent to emsi.techhub@gmail.com.");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label={t("contact.label")}
            title={t("contact.title")}
            description={t("contact.desc")}
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7">
            {submitted ? (
              <BlueprintFrame className="bg-background border border-border rounded-md p-10 text-center space-y-4">
                <CheckCircle2 className="h-10 w-10 text-engineering mx-auto" />
                <p className="label-mono">{t("contact.success.title")}</p>
                <h2 className="text-2xl font-semibold tracking-tight">{t("contact.success.thanks")}</h2>
                <p className="text-base text-muted-foreground">
                  {t("contact.success.body")}{" "}
                  <a href="mailto:emsi.techhub@gmail.com" className="text-engineering font-medium hover:underline">
                    emsi.techhub@gmail.com
                  </a>
                  . {t("contact.success.reply")}
                </p>
                <div className="text-xs text-muted-foreground font-mono pt-2 border-t border-border">
                  Forwarded to: <span className="text-foreground">emsi.techhub@gmail.com</span>
                </div>
                <Button variant="outline" onClick={() => {
                  setSubmitted(false);
                  setForm({ name: "", email: "", subject: "", body: "" });
                }}>
                  Send another message
                </Button>
              </BlueprintFrame>
            ) : (
              <form onSubmit={submit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="name">{t("contact.form.name")}</Label>
                    <Input id="name" required value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="email">{t("contact.form.email")}</Label>
                    <Input id="email" type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="subject">{t("contact.form.subject")}</Label>
                  <Input id="subject" required value={form.subject} onChange={(e) => set("subject", e.target.value)} placeholder="Partnership, sponsorship, talk proposal…" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="body">{t("contact.form.message")} <span className="text-xs text-muted-foreground font-mono">({form.body.length}/4000)</span></Label>
                  <Textarea
                    id="body" required minLength={10} maxLength={4000}
                    value={form.body}
                    onChange={(e) => set("body", e.target.value)}
                    className="min-h-[180px]"
                    placeholder="What's on your mind?"
                  />
                </div>
                <Button type="submit" disabled={submitting} className="bg-engineering hover:bg-engineering/90">
                  {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
                  {t("contact.form.send")}
                </Button>
              </form>
            )}
          </div>

          <aside className="lg:col-span-5 space-y-4">
            <Reveal>
              <BlueprintFrame className="bg-background border border-border rounded-md p-6 space-y-4">
                <p className="label-mono">Reach us directly</p>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <Mail className="h-4 w-4 text-engineering mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">Email</p>
                      <a href="mailto:emsi.techhub@gmail.com" className="text-muted-foreground hover:text-engineering transition-colors">emsi.techhub@gmail.com</a>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <MapPin className="h-4 w-4 text-engineering mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">Address</p>
                      <p className="text-muted-foreground">EMSI Fès — École Marocaine des Sciences de l'Ingénieur<br />Fès, Morocco</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <Clock className="h-4 w-4 text-engineering mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">Lab hours</p>
                      <p className="text-muted-foreground">Mon–Fri, 16:00 – 20:00<br />Saturdays during hackathons</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <DiscordIcon className="h-4 w-4 text-engineering mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">Discord</p>
                      <a href="https://discord.gg/xyVtPuuk" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-engineering transition-colors">discord.gg/xyVtPuuk</a>
                    </div>
                  </li>
                </ul>
              </BlueprintFrame>
            </Reveal>

            <Reveal delay={100}>
              <div className="border border-dashed border-border rounded-md p-5 bg-secondary/20 space-y-2">
                <p className="label-mono">Note</p>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We are a student-run organization. Replies may take a day or two during exam
                  periods. For sponsorship inquiries, mention <TechPill tone="engineering">SPONSOR</TechPill> in the subject.
                </p>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}
