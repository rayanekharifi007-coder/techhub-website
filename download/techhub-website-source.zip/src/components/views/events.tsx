"use client";

import * as React from "react";
import { CalendarDays, MapPin, Users, Clock, X, CheckCircle2, Loader2, Hourglass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { SectionHeader, TechPill, Reveal, EmptyState, LoadingState } from "@/components/site-primitives";
import { useAuth } from "@/components/auth-provider";
import { navigate } from "@/lib/router";
import { toast } from "sonner";

interface EventItem {
  id: string; title: string; slug: string; description: string; type: string;
  startDate: string; endDate: string; location: string; capacity: number;
  status: string; schedule: { time: string; title: string; speaker: string }[];
  registered: number; coverColor: string | null;
}

const TYPES = ["ALL", "HACKATHON", "WORKSHOP", "TALK", "STUDY_JAM"];

export function EventsView() {
  const [events, setEvents] = React.useState<EventItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [type, setType] = React.useState("ALL");
  const [selected, setSelected] = React.useState<EventItem | null>(null);

  React.useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (type !== "ALL") params.set("type", type);
    fetch(`/api/events?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => { setEvents(d.events || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, [type]);

  const upcoming = events.filter((e) => e.status === "UPCOMING");
  const past = events.filter((e) => e.status === "COMPLETED");

  return (
    <>
      <section className="border-b border-border bg-secondary/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <SectionHeader
            label="Calendar · 2024 / 2025"
            title="Events, hackathons, study jams."
            description="A continuous schedule of build opportunities. Registration is open to all TechHub members. Sign in to register."
          />
          <div className="mt-8 flex gap-2 flex-wrap">
            {TYPES.map((t) => (
              <button
                key={t}
                onClick={() => setType(t)}
                className={
                  "font-mono text-[11px] tracking-wider uppercase px-3 py-1.5 rounded-sm border transition-colors " +
                  (type === t
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40")
                }
              >
                {t === "ALL" ? "All events" : t.replace("_", " ")}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-10">
          <div>
            <p className="label-mono mb-4">Upcoming · {upcoming.length}</p>
            {loading ? (
              <LoadingState rows={3} />
            ) : upcoming.length === 0 ? (
              <EmptyState
                icon={<CalendarDays className="h-6 w-6" />}
                title="No upcoming events match this filter."
                description="Try a different category, or check back soon — we publish new events every week."
              />
            ) : (
              <div className="grid gap-4 lg:grid-cols-2">
                {upcoming.map((e, i) => (
                  <Reveal key={e.id} delay={(i % 4) * 60}>
                    <EventCard event={e} onOpen={() => setSelected(e)} />
                  </Reveal>
                ))}
              </div>
            )}
          </div>

          {past.length > 0 && (
            <div>
              <p className="label-mono mb-4">Past · {past.length}</p>
              <div className="grid gap-4 lg:grid-cols-2 opacity-70">
                {past.map((e, i) => (
                  <Reveal key={e.id} delay={(i % 4) * 60}>
                    <EventCard event={e} onOpen={() => setSelected(e)} />
                  </Reveal>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      <EventDialog event={selected} onClose={() => setSelected(null)} />
    </>
  );
}

function EventCard({ event, onOpen }: { event: EventItem; onOpen: () => void }) {
  const accent = event.coverColor || "#1f3a8a";
  const start = new Date(event.startDate);
  const end = new Date(event.endDate);
  const full = event.registered >= event.capacity;
  const pct = Math.min(100, Math.round((event.registered / event.capacity) * 100));

  return (
    <article
      onClick={onOpen}
      className="group relative h-full rounded-md border border-border bg-background overflow-hidden hover:border-foreground/30 transition-colors cursor-pointer"
    >
      <div
        className="h-24 relative overflow-hidden border-b border-border"
        style={{ background: `linear-gradient(135deg, ${accent}14, ${accent}06), var(--secondary)` }}
      >
        <div className="absolute inset-0 bg-engineering-grid-sm opacity-30" />
        <div className="absolute inset-0 p-4 flex items-end justify-between">
          <div className="flex items-end gap-2 font-mono text-[10px] tracking-widest uppercase text-foreground/70">
            <span>{event.type.replace("_", " ")}</span>
          </div>
          <div className="text-right">
            <p className="font-mono text-2xl font-semibold text-foreground leading-none">
              {start.getDate()}
            </p>
            <p className="font-mono text-[10px] tracking-widest uppercase text-foreground/70 mt-1">
              {start.toLocaleDateString("en-US", { month: "short" })} · {start.getFullYear()}
            </p>
          </div>
        </div>
      </div>

      <div className="p-5 space-y-3">
        <h3 className="font-semibold text-lg tracking-tight group-hover:text-engineering transition-colors">
          {event.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">{event.description}</p>
        <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            {start.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" />
            {event.location}
          </span>
        </div>
        <div className="pt-3 border-t border-border space-y-2">
          <div className="flex items-center justify-between text-[11px] font-mono text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <Users className="h-3 w-3" />
              {event.registered}/{event.capacity}
            </span>
            <span className={full ? "text-destructive" : "text-engineering"}>
              {full ? "WAITLIST" : event.status}
            </span>
          </div>
          <div className="h-1 w-full rounded-full bg-secondary overflow-hidden">
            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: accent }} />
          </div>
        </div>
      </div>
    </article>
  );
}

function EventDialog({ event, onClose }: { event: EventItem | null; onClose: () => void }) {
  const { session } = useAuth();
  const [state, setState] = React.useState<"idle" | "loading" | "registered" | "waitlisted" | "cancelled">("idle");
  React.useEffect(() => { setState("idle"); }, [event?.id]);
  if (!event) return null;
  const accent = event.coverColor || "#1f3a8a";
  const start = new Date(event.startDate);
  const end = new Date(event.endDate);
  const sameDay = start.toDateString() === end.toDateString();
  const full = event.registered >= event.capacity;

  async function register() {
    if (!session) { toast.error("Sign in to register."); navigate("login"); return; }
    setState("loading");
    try {
      const res = await fetch("/api/events/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventId: event!.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not register.");
      setState(data.registration.status === "WAITLIST" ? "waitlisted" : "registered");
      toast.success(data.registration.status === "WAITLIST" ? "Added to waitlist." : "You are registered.");
    } catch (e) {
      toast.error((e as Error).message);
      setState("idle");
    }
  }

  return (
    <Dialog open={!!event} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto scrollbar-thin">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider">
              {event.type.replace("_", " ")}
            </Badge>
            <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider">
              {event.status}
            </Badge>
          </div>
          <DialogTitle className="text-2xl tracking-tight mt-2">{event.title}</DialogTitle>
          <DialogDescription className="text-base text-foreground/80">
            {event.description}
          </DialogDescription>
        </DialogHeader>

        <div
          className="h-24 rounded-md border border-border relative overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${accent}18, ${accent}06), var(--secondary)` }}
        >
          <div className="absolute inset-0 bg-engineering-grid-sm opacity-30" />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
          <InfoBlock label="Starts" value={start.toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })} />
          <InfoBlock label="Ends" value={end.toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })} />
          <InfoBlock label="Location" value={event.location} />
          <InfoBlock label="Capacity" value={`${event.registered}/${event.capacity} ${full ? "(waitlist)" : ""}`} />
        </div>

        {event.schedule && event.schedule.length > 0 && (
          <div className="space-y-3">
            <p className="label-mono">Schedule {sameDay ? "" : "(multi-day)"}</p>
            <ol className="space-y-2">
              {event.schedule.map((s, i) => (
                <li key={i} className="grid grid-cols-[80px_1fr] gap-3 items-start text-sm border-b border-border pb-2">
                  <span className="font-mono text-[11px] text-engineering pt-0.5">{s.time}</span>
                  <div>
                    <p className="text-foreground font-medium">{s.title}</p>
                    {s.speaker && <p className="text-xs text-muted-foreground mt-0.5">{s.speaker}</p>}
                  </div>
                </li>
              ))}
            </ol>
          </div>
        )}

        <div className="flex flex-wrap gap-2 pt-3 border-t border-border">
          {state === "registered" ? (
            <Button disabled className="bg-engineering">
              <CheckCircle2 className="mr-2 h-4 w-4" />
              Registered
            </Button>
          ) : state === "waitlisted" ? (
            <Button disabled>
              <Hourglass className="mr-2 h-4 w-4" />
              On waitlist
            </Button>
          ) : (
            <Button onClick={register} disabled={state === "loading"} className="bg-engineering hover:bg-engineering/90">
              {state === "loading" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {full ? "Join waitlist" : "Register"}
            </Button>
          )}
          <Button variant="outline" onClick={onClose}>
            <X className="mr-2 h-4 w-4" />
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InfoBlock({ label, value }: { label: string; value: string }) {
  return (
    <div className="border border-border rounded-md p-3 bg-secondary/30">
      <p className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">{label}</p>
      <p className="text-sm text-foreground font-medium mt-1">{value}</p>
    </div>
  );
}
