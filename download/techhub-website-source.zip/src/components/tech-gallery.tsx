"use client";

import * as React from "react";
import { Shuffle, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal, TechPill } from "@/components/site-primitives";
import { useI18n } from "@/components/i18n-provider";
import { cn } from "@/lib/utils";

interface GalleryImage {
  url: string;
  alt: string;
  label: string;
  category: string;
  // bento grid span classes
  span: string;
}

const IMAGES: GalleryImage[] = [
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/601916bf8721.png",
    alt: "Code on a dark screen",
    label: "Code",
    category: "Programming",
    span: "md:col-span-2 md:row-span-2",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/98fd2805385f.jpg",
    alt: "Circuit board macro",
    label: "Circuits",
    category: "Hardware",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/33ac3e182634.jpg",
    alt: "Server room with blue lights",
    label: "Servers",
    category: "Infrastructure",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/f33b84dacb6a.jpg",
    alt: "Glowing blue circuit board",
    label: "Silicon",
    category: "Hardware",
    span: "md:col-span-1 md:row-span-2",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a6b0cd9590bb.jpg",
    alt: "Fiber optic cables glowing",
    label: "Fiber",
    category: "Infrastructure",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/1872df55a768.png",
    alt: "Abstract technology network",
    label: "Networks",
    category: "AI & ML",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/4437d3957269.jpg",
    alt: "Microchip processor close up",
    label: "Chips",
    category: "Hardware",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/bc10a8d2d86c.jpg",
    alt: "Developer workspace with code",
    label: "Build",
    category: "Programming",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/940ec359160c.jpeg",
    alt: "Neural network visualization",
    label: "Neural Nets",
    category: "AI & ML",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/c539e2b264c6.jpg",
    alt: "Abstract gradient technology",
    label: "Abstract",
    category: "Design",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/9b540a2536e2.jpg",
    alt: "Glowing circuit pathways",
    label: "Pathways",
    category: "Hardware",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/4fdb7d54c26a.jpg",
    alt: "Fiber optic light strands",
    label: "Optics",
    category: "Infrastructure",
    span: "md:col-span-1 md:row-span-1",
  },
];

// Fallback gradient colors per category (in case images fail to load)
const FALLBACK_COLORS = [
  "#1f3a8a", "#0d4f7c", "#166534", "#7c2d12",
  "#2c5282", "#92400e", "#0f766e", "#3730a3",
];

export function TechGallery() {
  const { t } = useI18n();
  const [order, setOrder] = React.useState<number[]>(() => IMAGES.map((_, i) => i));
  const [shuffling, setShuffling] = React.useState(false);

  function shuffle() {
    setShuffling(true);
    setTimeout(() => {
      const shuffled = [...order];
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      setOrder(shuffled);
      setShuffling(false);
    }, 200);
  }

  return (
    <section className="py-20 sm:py-28 border-t border-border bg-secondary/20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <Reveal>
            <div className="space-y-3">
              <p className="label-mono">{t("gallery.label")}</p>
              <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-foreground leading-tight">
                {t("gallery.title")}
              </h2>
              <p className="text-base text-muted-foreground leading-relaxed max-w-xl">
                {t("gallery.desc")}
              </p>
            </div>
          </Reveal>
          <Button onClick={shuffle} variant="outline" size="sm" className="gap-2 self-start sm:self-end shrink-0" disabled={shuffling}>
            <Shuffle className={cn("h-3.5 w-3.5 transition-transform", shuffling && "animate-spin")} />
            {t("gallery.shuffle")}
          </Button>
        </div>

        {/* Bento grid */}
        <div
          className={cn(
            "grid grid-cols-2 md:grid-cols-4 auto-rows-[140px] sm:auto-rows-[180px] gap-2 sm:gap-3 transition-opacity duration-200",
            shuffling && "opacity-40"
          )}
        >
          {order.map((idx, i) => {
            const img = IMAGES[idx];
            const fallbackColor = FALLBACK_COLORS[idx % FALLBACK_COLORS.length];
            return (
              <div
                key={idx}
                className={cn(
                  "relative rounded-md overflow-hidden border border-border group cursor-pointer transition-all duration-300 hover:border-engineering/60 hover:shadow-[0_0_20px_rgba(45,156,219,0.15)]",
                  img.span
                )}
                style={{ background: fallbackColor + "20" }}
              >
                <img
                  src={img.url}
                  alt={img.alt}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  onError={(e) => {
                    // Hide broken images and show the fallback color
                    (e.target as HTMLImageElement).style.display = "none";
                  }}
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />

                {/* Label */}
                <div className="absolute bottom-0 left-0 right-0 p-3 flex items-end justify-between">
                  <div>
                    <p className="text-white font-semibold text-sm leading-tight">{img.label}</p>
                    <p className="text-white/60 font-mono text-[9px] tracking-wider uppercase mt-0.5">{img.category}</p>
                  </div>
                </div>

                {/* Category pill top-left */}
                <div className="absolute top-2 left-2">
                  <span className="inline-flex items-center gap-1 font-mono text-[8px] tracking-widest uppercase px-1.5 py-0.5 rounded-sm bg-white/10 backdrop-blur-sm text-white/80 border border-white/10">
                    <span className="h-1 w-1 rounded-full" style={{ background: fallbackColor }} />
                    {img.category}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
          <ImageIcon className="h-3.5 w-3.5" />
          <span className="font-mono">{IMAGES.length} images · {t("gallery.hint")}</span>
        </div>
      </div>
    </section>
  );
}
