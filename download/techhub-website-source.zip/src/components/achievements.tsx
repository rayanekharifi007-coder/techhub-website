"use client";

import * as React from "react";
import { toast } from "sonner";
import { Trophy, Sparkles, Zap, Brain, Rocket, Star } from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  check: (state: AchievementState) => boolean;
}

interface AchievementState {
  pagesVisited: Set<string>;
  toolsUsed: number;
  factsViewed: number;
  votesCast: number;
  loginCount: number;
  konamiActivated: boolean;
}

const ACHIEVEMENTS: Achievement[] = [
  { id: "explorer", title: "Explorer", desc: "Visited 5 different pages", icon: Star, check: (s) => s.pagesVisited.size >= 5 },
  { id: "curious", title: "Curious Mind", desc: "Viewed 10 tech facts", icon: Brain, check: (s) => s.factsViewed >= 10 },
  { id: "builder", title: "Builder", desc: "Used 3 playground tools", icon: Zap, check: (s) => s.toolsUsed >= 3 },
  { id: "voter", title: "Democrat", desc: "Cast a vote on the Decision Board", icon: Trophy, check: (s) => s.votesCast >= 1 },
  { id: "member", title: "Member", desc: "Signed in to your account", icon: Rocket, check: (s) => s.loginCount >= 1 },
  { id: "hacker", title: "Hacker", desc: "Found the Konami code easter egg", icon: Sparkles, check: (s) => s.konamiActivated },
  { id: "complete", title: "TechHub Master", desc: "Unlocked all other achievements", icon: Trophy, check: (s) => s.pagesVisited.size >= 5 && s.factsViewed >= 10 && s.toolsUsed >= 3 && s.votesCast >= 1 && s.loginCount >= 1 },
];

const STORAGE_KEY = "techhub-achievements";

export function AchievementSystem() {
  const stateRef = React.useRef<AchievementState>({
    pagesVisited: new Set(),
    toolsUsed: 0,
    factsViewed: 0,
    votesCast: 0,
    loginCount: 0,
    konamiActivated: false,
  });
  const unlockedRef = React.useRef<Set<string>>(new Set());

  // Load saved achievements
  React.useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const ids = JSON.parse(saved) as string[];
        unlockedRef.current = new Set(ids);
      }
    } catch {}
  }, []);

  // Listen for achievement events
  React.useEffect(() => {
    const onEvent = (e: Event) => {
      const detail = (e as CustomEvent).detail as Partial<AchievementState>;
      if (!detail) return;

      if (detail.pagesVisited) {
        detail.pagesVisited.forEach((p) => stateRef.current.pagesVisited.add(p));
      }
      if (detail.toolsUsed !== undefined) stateRef.current.toolsUsed = detail.toolsUsed;
      if (detail.factsViewed !== undefined) stateRef.current.factsViewed = detail.factsViewed;
      if (detail.votesCast !== undefined) stateRef.current.votesCast = detail.votesCast;
      if (detail.loginCount !== undefined) stateRef.current.loginCount = detail.loginCount;
      if (detail.konamiActivated !== undefined) stateRef.current.konamiActivated = detail.konamiActivated;

      // Check for new achievements
      ACHIEVEMENTS.forEach((a) => {
        if (!unlockedRef.current.has(a.id) && a.check(stateRef.current)) {
          unlockedRef.current.add(a.id);
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(unlockedRef.current)));
          } catch {}
          toast.success(`Achievement unlocked: ${a.title}`, {
            description: a.desc,
            icon: <a.icon className="h-4 w-4 text-engineering" />,
            duration: 5000,
          });
        }
      });
    };

    window.addEventListener("techhub-achievement", onEvent as EventListener);
    return () => window.removeEventListener("techhub-achievement", onEvent as EventListener);
  }, []);

  return null;
}

/** Helper to emit achievement events */
export function trackAchievement(data: Partial<AchievementState>) {
  window.dispatchEvent(new CustomEvent("techhub-achievement", { detail: data }));
}
