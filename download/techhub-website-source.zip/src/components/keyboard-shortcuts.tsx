"use client";

import * as React from "react";
import {
  Dialog, DialogContent, DialogTitle,
} from "@/components/ui/dialog";
import { Keyboard } from "lucide-react";

const SHORTCUTS = [
  { keys: ["⌘", "K"], label: "Open command palette", mac: true },
  { keys: ["Ctrl", "K"], label: "Open command palette", mac: false },
  { keys: ["?"], label: "Show this shortcuts dialog", mac: true },
  { keys: ["G", "H"], label: "Go to Home", mac: true },
  { keys: ["G", "A"], label: "Go to About", mac: true },
  { keys: ["G", "P"], label: "Go to Playground", mac: true },
  { keys: ["G", "L"], label: "Go to Learning Hub", mac: true },
  { keys: ["G", "J"], label: "Go to Join Us", mac: true },
  { keys: ["G", "C"], label: "Go to Contact", mac: true },
  { keys: ["T"], label: "Toggle dark / light theme", mac: true },
  { keys: ["Esc"], label: "Close any dialog", mac: true },
];

export function KeyboardShortcuts() {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // ? key
      if (e.key === "?" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        const tag = (e.target as HTMLElement)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-lg" aria-describedby={undefined}>
        <DialogTitle className="sr-only">Keyboard shortcuts</DialogTitle>
        <div className="flex items-center gap-2 mb-4">
          <Keyboard className="h-4 w-4 text-engineering" />
          <h2 className="text-lg font-semibold tracking-tight">Keyboard shortcuts</h2>
        </div>
        <div className="space-y-1.5 max-h-[60vh] overflow-y-auto scrollbar-thin">
          {SHORTCUTS.map((s, i) => (
            <div key={i} className="flex items-center justify-between py-1.5 px-2 rounded-md hover:bg-secondary/50 transition-colors">
              <span className="text-sm text-foreground/80">{s.label}</span>
              <div className="flex items-center gap-1">
                {s.keys.map((k, j) => (
                  <kbd key={j} className="font-mono text-[11px] px-1.5 py-0.5 rounded border border-border bg-secondary text-foreground min-w-[24px] text-center">
                    {k}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3 pt-3 border-t border-border">
          Press <kbd className="font-mono px-1 py-0.5 rounded border border-border bg-secondary">?</kbd> anywhere to open this dialog.
        </p>
      </DialogContent>
    </Dialog>
  );
}
