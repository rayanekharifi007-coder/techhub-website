"use client";

import * as React from "react";
import { Terminal } from "lucide-react";
import { BlueprintFrame } from "@/components/site-primitives";

const LINES = [
  { type: "cmd", text: "whoami" },
  { type: "out", text: "techhub-member" },
  { type: "cmd", text: "cat mission.txt" },
  { type: "out", text: "Where Tech Meets Ideas." },
  { type: "cmd", text: "ls /disciplines" },
  { type: "out", text: "systems/  ai/  web/  hardware/  tooling/" },
  { type: "cmd", text: "npm run build" },
  { type: "out", text: "✓ Compiled successfully in 1.2s" },
  { type: "out", text: "✓ 11 playground tools ready" },
  { type: "out", text: "✓ 71 facts loaded" },
  { type: "out", text: "✓ Deployed to production" },
  { type: "cmd", text: "echo 'Ready to build?'" },
  { type: "out", text: "Ready to build?" },
];

export function TerminalWidget() {
  const [visibleLines, setVisibleLines] = React.useState<number>(0);
  const [currentText, setCurrentText] = React.useState("");
  const containerRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (visibleLines >= LINES.length) {
      // Reset after a pause
      const reset = setTimeout(() => {
        setVisibleLines(0);
        setCurrentText("");
      }, 4000);
      return () => clearTimeout(reset);
    }

    const line = LINES[visibleLines];
    if (line.type === "cmd") {
      // Type out the command character by character
      let i = 0;
      const interval = setInterval(() => {
        i++;
        setCurrentText(line.text.slice(0, i));
        if (i >= line.text.length) {
          clearInterval(interval);
          setTimeout(() => {
            setVisibleLines((v) => v + 1);
            setCurrentText("");
          }, 400);
        }
      }, 50);
      return () => clearInterval(interval);
    } else {
      // Output line — show instantly, then advance
      const timeout = setTimeout(() => {
        setVisibleLines((v) => v + 1);
      }, 600);
      return () => clearTimeout(timeout);
    }
  }, [visibleLines]);

  // Auto-scroll to bottom
  React.useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [visibleLines, currentText]);

  return (
    <BlueprintFrame className="relative bg-[oklch(0.16_0.02_255)] border border-engineering/20 rounded-lg overflow-hidden shadow-[0_0_30px_-8px_rgba(45,156,219,0.3)]">
      {/* Terminal title bar */}
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/10 bg-white/[0.02]">
        <div className="flex gap-1.5">
          <span className="h-3 w-3 rounded-full bg-red-500/70" />
          <span className="h-3 w-3 rounded-full bg-yellow-500/70" />
          <span className="h-3 w-3 rounded-full bg-green-500/70" />
        </div>
        <div className="flex items-center gap-1.5 ml-2 text-white/40">
          <Terminal className="h-3 w-3" />
          <span className="font-mono text-[10px] tracking-wider uppercase">techhub@emsi — zsh</span>
        </div>
      </div>

      {/* Terminal body */}
      <div
        ref={containerRef}
        className="h-[280px] overflow-y-auto scrollbar-thin p-4 font-mono text-[12.5px] leading-relaxed"
      >
        {LINES.slice(0, visibleLines).map((line, i) => (
          <div key={i} className={line.type === "cmd" ? "text-white/90" : "text-engineering/80"}>
            {line.type === "cmd" && <span className="text-green-400/70 mr-1.5">$</span>}
            {line.text}
          </div>
        ))}
        {/* Current typing line */}
        {visibleLines < LINES.length && LINES[visibleLines].type === "cmd" && (
          <div className="text-white/90">
            <span className="text-green-400/70 mr-1.5">$</span>
            {currentText}
            <span className="inline-block w-2 h-4 bg-engineering/70 ml-0.5 animate-pulse" />
          </div>
        )}
        {/* Cursor when waiting */}
        {visibleLines < LINES.length && LINES[visibleLines].type === "out" && (
          <div className="text-engineering/40">
            <span className="inline-block w-2 h-4 bg-engineering/40 ml-0.5 animate-pulse" />
          </div>
        )}
      </div>
    </BlueprintFrame>
  );
}
