"use client";

import { create } from "zustand";

export type Route =
  | "home"
  | "about"
  | "playground"
  | "facts"
  | "learning"
  | "decisions"
  | "join"
  | "contact"
  | "dashboard"
  | "admin"
  | "login";

export const ROUTES: { id: Route; label: string; href: string }[] = [
  { id: "home", label: "Home", href: "#/" },
  { id: "about", label: "About", href: "#/about" },
  { id: "playground", label: "Playground", href: "#/playground" },
  { id: "facts", label: "Facts", href: "#/facts" },
  { id: "learning", label: "Learning Hub", href: "#/learning" },
  { id: "decisions", label: "Decisions", href: "#/decisions" },
  { id: "join", label: "Join Us", href: "#/join" },
  { id: "contact", label: "Contact", href: "#/contact" },
];

interface RouterState {
  route: Route;
  params: URLSearchParams;
  navigate: (route: Route, params?: Record<string, string>) => void;
  initFromHash: () => void;
}

function parseHash(): { route: Route; params: URLSearchParams } {
  if (typeof window === "undefined") return { route: "home", params: new URLSearchParams() };
  const raw = window.location.hash.replace(/^#\/?/, "");
  const [path, query] = raw.split("?");
  const seg = (path || "").split("/")[0]?.toLowerCase() as Route;
  const valid: Route[] = [
    "home", "about", "playground", "facts",
    "learning", "decisions", "join", "contact", "dashboard", "admin", "login",
  ];
  const route: Route = valid.includes(seg) ? seg : "home";
  return { route, params: new URLSearchParams(query || "") };
}

function toHash(route: Route, params?: Record<string, string>): string {
  const q = params ? "?" + new URLSearchParams(params).toString() : "";
  return `#/${route === "home" ? "" : route}${q}`;
}

export const useRouterStore = create<RouterState>((set) => ({
  route: "home",
  params: new URLSearchParams(),
  navigate: (route, params) => {
    if (typeof window !== "undefined") {
      window.location.hash = toHash(route, params);
    }
  },
  initFromHash: () => {
    set(parseHash());
  },
}));

if (typeof window !== "undefined") {
  const apply = () => useRouterStore.getState().initFromHash();
  window.addEventListener("hashchange", apply);
  // initial
  apply();
}

export function navigate(route: Route, params?: Record<string, string>) {
  useRouterStore.getState().navigate(route, params);
}
