// Shared types and client-safe utilities for authentication.
// This file MUST NOT import from "next/headers", "next/server", or any server-only module.

export type SessionRole = "ADMIN" | "LEAD" | "MEMBER";

export interface Session {
  userId: string;
  email: string;
  name: string;
  role: SessionRole;
  avatarUrl?: string | null;
  specialty?: string | null;
}

export function hasAdmin(s: Session | null | undefined): boolean {
  return s?.role === "ADMIN";
}

export function hasLeadOrAbove(s: Session | null | undefined): boolean {
  return s?.role === "ADMIN" || s?.role === "LEAD";
}

/** Client helper: fetch current session via API. */
export async function fetchSession(): Promise<Session | null> {
  try {
    const res = await fetch("/api/auth/me", {
      cache: "no-store",
      credentials: "same-origin",
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data?.user ?? null;
  } catch {
    return null;
  }
}
