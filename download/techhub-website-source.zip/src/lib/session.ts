import "server-only";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

export type { Session, SessionRole } from "@/lib/session-shared";
import type { Session, SessionRole } from "@/lib/session-shared";
export { hasAdmin, hasLeadOrAbove, fetchSession } from "@/lib/session-shared";

const COOKIE = "th_session";
const SESSION_TTL_DAYS = 14;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const verify = scryptSync(password, salt, 64).toString("hex");
  try {
    return timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(verify, "hex"));
  } catch {
    return false;
  }
}

export async function createSession(userId: string): Promise<void> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
  await db.session.create({ data: { token, userId, expiresAt } });
  const c = await cookies();
  c.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession(): Promise<void> {
  const c = await cookies();
  const token = c.get(COOKIE)?.value;
  if (token) {
    await db.session.deleteMany({ where: { token } }).catch(() => {});
  }
  c.delete(COOKIE);
}

export async function readServerSession(): Promise<Session | null> {
  const c = await cookies();
  const token = c.get(COOKIE)?.value;
  if (!token) return null;
  const row = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });
  if (!row || row.expiresAt < new Date()) {
    if (row) await db.session.delete({ where: { id: row.id } }).catch(() => {});
    return null;
  }
  return {
    userId: row.user.id,
    email: row.user.email,
    name: row.user.name,
    role: row.user.role as SessionRole,
    avatarUrl: row.user.avatarUrl,
    specialty: row.user.specialty,
  };
}

export async function requireUser(): Promise<Session> {
  const s = await readServerSession();
  if (!s) throw new Error("UNAUTHORIZED");
  return s;
}

export async function requireAdmin(): Promise<Session> {
  const s = await requireUser();
  if (s.role !== "ADMIN") throw new Error("FORBIDDEN");
  return s;
}

export async function requireLeadOrAbove(): Promise<Session> {
  const s = await requireUser();
  if (s.role !== "ADMIN" && s.role !== "LEAD") throw new Error("FORBIDDEN");
  return s;
}
