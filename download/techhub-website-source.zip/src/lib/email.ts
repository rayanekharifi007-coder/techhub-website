import "server-only";
import nodemailer from "nodemailer";

/**
 * Email sending utility.
 * Uses environment variables for SMTP configuration.
 * If SMTP is not configured, falls back to a test account (Ethereal Email).
 * In production, set these env vars:
 *   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
 */

const CLUB_EMAIL = "emsi.techhub@gmail.com";

let transporter: nodemailer.Transporter | null = null;

async function getTransporter(): Promise<nodemailer.Transporter> {
  if (transporter) return transporter;

  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : 587;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (host && user && pass) {
    transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
    });
  } else {
    // Fallback: use a test account (Ethereal) — emails are captured but not actually sent.
    // In production, configure SMTP env vars to send real emails.
    const testAccount = await nodemailer.createTestAccount();
    transporter = nodemailer.createTransport({
      host: "smtp.ethereal.email",
      port: 587,
      secure: false,
      auth: { user: testAccount.user, pass: testAccount.pass },
    });
  }

  return transporter;
}

export interface SendEmailParams {
  to: string;
  subject: string;
  text: string;
  html?: string;
  replyTo?: string;
}

export async function sendEmail(params: SendEmailParams): Promise<{ success: boolean; previewUrl?: string; error?: string }> {
  try {
    const transport = await getTransporter();
    const from = process.env.SMTP_FROM || `"TechHub EMSI Fès" <${CLUB_EMAIL}>`;

    const info = await transport.sendMail({
      from,
      to: params.to,
      subject: params.subject,
      text: params.text,
      html: params.html || params.text.replace(/\n/g, "<br>"),
      replyTo: params.replyTo,
    });

    // If using Ethereal test account, return the preview URL
    const previewUrl = nodemailer.getTestMessageUrl(info);
    return { success: true, previewUrl: previewUrl ? String(previewUrl) : undefined };
  } catch (error) {
    console.error("Email send error:", error);
    return { success: false, error: (error as Error).message };
  }
}

export { CLUB_EMAIL };
